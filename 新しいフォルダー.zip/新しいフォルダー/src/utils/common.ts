import type { AxiosResponse } from "axios";

//現在の年度から次15年を返す
export const getCurrentYear = () =>
  Array.from({ length: 15 }, (value, index) => {
    const year = new Date().getFullYear() + index;

    return {
      value: year,
      label: String(year),
    };
  });

/** 按分率を小数第3位まで表示する（値が無い場合は空欄）
 *  ※一覧の列のrenderで使用する */
export const renderAnbunRate = (value: number | null) => (value == null ? "" : value.toFixed(3));

/** Content-Dispositionヘッダーからダウンロードファイル名を取り出す。
 *  RFC5987形式(filename*=UTF-8''...)を優先し、無ければ従来のfilename=を使う */
const getFileNameFromHeader = (contentDisposition?: string): string => {
  if (!contentDisposition) {
    return "";
  }

  // filename*=UTF-8''  の場合
  const encoded = /filename\*=UTF-8''([^;]+)/i.exec(contentDisposition);
  if (encoded) {
    return decodeURIComponent(encoded[1]);
  }

  // filename=　の場合
  const plain = /filename="?([^";]+)"?/i.exec(contentDisposition);
  if (plain) {
    return decodeURIComponent(plain[1].replace(/\+/g, "%20"));
  }

  return "";
};

/** ファイルダウンロード系API（responseType:"blob"で受け取ったレスポンス）を
 *  ブラウザのダウンロードとして保存する共通処理。
 *
 *  BEはエラー時にファイルではなくJSON（CommonResponse）を返すため、
 *  その場合はダウンロードせずメッセージを戻り値で返し、呼び出し側でエラー表示させる。
 *
 *  @param res axiosのレスポンス（responseType:"blob"で取得したもの）
 *  @param defaultFileName Content-Dispositionが無い場合に使うファイル名
 *  @returns 成功時はnull、ダウンロードできなかった場合はその理由メッセージ */
export const saveBlobResponse = async (
  res: AxiosResponse<Blob>,
  defaultFileName: string,
): Promise<string | null> => {
  const blob = res.data;

  // 中身が無い（BE未実装・該当データ無し等）場合は空ファイルを保存させない
  if (!blob || blob.size === 0) {
    return "出力対象のデータがありません";
  }

  // JSONが返っている場合はファイルではなくエラーレスポンス
  if (blob.type.includes("application/json")) {
    const text = await blob.text();
    try {
      return JSON.parse(text)?.message ?? text;
    } catch {
      return text;
    }
  }

  const fileName =
    getFileNameFromHeader(res.headers?.["content-disposition"] as string) || defaultFileName;

  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  // 生成したObjectURLはメモリに残り続けるため、ダウンロード開始後に解放する
  window.URL.revokeObjectURL(url);

  return null;
};
