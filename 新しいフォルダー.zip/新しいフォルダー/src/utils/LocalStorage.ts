const LocalStorage = {
  set: (key: string, value: string) => {
    if (typeof window !== "undefined") {
      localStorage.setItem(key, value);
    }
  },

  get: (key: string): any => {
    if (typeof window === "undefined") {
      return "";
    }
    const itemValue = window.localStorage.getItem(key);
    try {
      return itemValue && JSON.parse(itemValue);
    } catch {
      return itemValue;
    }
  },

  remove: (key: string) => {
    if (typeof window !== "undefined") {
      localStorage.removeItem(key);
    }
  },

  clear: () => {
    if (typeof window !== "undefined") {
      localStorage.clear();
    }
  },
};

export default LocalStorage;
