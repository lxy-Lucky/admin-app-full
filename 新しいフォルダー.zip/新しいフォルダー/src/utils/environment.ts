//#HB server test

export const NEXT_PUBLIC_HOST = process.env.NEXT_PUBLIC_HOST;
export const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_API_URL;
export const NEXT_PUBLIC_API_URL_PREVIEW = process.env.NEXT_PUBLIC_API_URL_PREVIEW;

export const NEXT_PUBLIC_PARENT_DOMAIN = process.env.NEXT_PUBLIC_PARENT_DOMAIN;

export const NEXT_PUBLIC_BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH;
export const NEXT_PUBLIC_SECRET_KEY = process.env.NEXT_PUBLIC_SECRET_KEY;
export const NEXT_PUBLIC_ACTIVE_THREE_POINT = (() => {
  return process.env.NEXT_PUBLIC_ACTIVE_THREE_POINT === "true";
})();
