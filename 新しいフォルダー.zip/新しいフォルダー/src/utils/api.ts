import { ELocalStorgeKey, SESSION_INVALID_CODES } from "@/constants/common";
import axios from "axios";
import Cookies from "js-cookie";
import {
  NEXT_PUBLIC_HOST,
  NEXT_PUBLIC_API_URL,
  NEXT_PUBLIC_API_URL_PREVIEW,
  NEXT_PUBLIC_PARENT_DOMAIN,
} from "./environment";

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

//　ログイン後、保存されたトークンを自動的にHTTPリクエストへ付ける
api.interceptors.request.use(
  (config) => {
    const token = Cookies.get(ELocalStorgeKey.TOKEN);
    if (token) {
      config.headers.Authorization = `${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error),
);

// JWT削除
// 設定時にdomainを指定しているため、削除時も同じdomainを指定しないとhttps環境で削除されない
export const removeToken = () => {
  Cookies.remove(ELocalStorgeKey.TOKEN, {
    domain: checkHostAccessMoreDetail().parent_domain,
  });
  Cookies.remove(ELocalStorgeKey.TOKEN);
};

// セッション無効化（多重ログイン・タイムアウト・利用停止）時の共通処理
// ログイン画面へ
const redirectToLogin = () => {
  removeToken();
  // axiosインターセプタはコンポーネント外のためuseRouterは使えない。またセッション無効時は画面状態を残さないようフルリロードで遷移させる
  // eslint-disable-next-line @next/next/no-location-assign-relative-destination
  window.location.href = "/";
};

// レスポンス
api.interceptors.response.use(
  (response) => {
    if (response.data) {
      const data = response.data;

      // BE側は多重ログイン等を検知した場合もHTTPステータスは200で返すため、
      // codeで判定してログイン画面へ遷移させる（後勝ちで無効化された旧セッション側がここに入る）
      if (data?.code !== undefined && SESSION_INVALID_CODES.includes(String(data.code))) {
        redirectToLogin();
        return Promise.reject(new Error(data.message));
      }

      const parentDomain = checkHostAccessMoreDetail().parent_domain;
      const token = Cookies.get(ELocalStorgeKey.TOKEN);
      const responToken = response?.headers?.authorization || "";
      if (responToken && (!token || token !== responToken)) {
        Cookies.set(ELocalStorgeKey.TOKEN, responToken, {
          domain: parentDomain,
        });
      }
    }
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      redirectToLogin();
    }

    return Promise.reject(error);
  },
);

export default api;

export const checkHostAccessMoreDetail = () => {
  const globalEnv = {
    host: NEXT_PUBLIC_HOST,
    api: NEXT_PUBLIC_API_URL,
    api_preview: NEXT_PUBLIC_API_URL_PREVIEW,
    parent_domain: NEXT_PUBLIC_PARENT_DOMAIN,
  };
  return globalEnv;
};
