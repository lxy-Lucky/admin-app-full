export const ROUTES = {
  LOGIN: "/",
  TOP: "/top",
  USERLIST: "/user",
  USERADD: "/user/add",
  USERUPDATE: "/user/update",
  ADJUSTCODELIST: "/adjust-code",
  ADJUSTCODEADD: "/adjust-code/add",
  ADJUSTCODEUPDATE: "/adjust-code/update",
  JUKIDBLIST: "/juki-db",
  SCHOOL_AREA_INFO_LIST: "/school-area-info",
  SCHOOLLIST: "/school",
  GAKUSEKI_DB: "/gakuseki-db",
  FUMEI_AREA_LIST: "/fumei-area",

  //幼児数1次集計
  INFANT_SUMMARY1: "/infant-summary1",

  //幼児数2次集計
  INFANT_SUMMARY2: "/infant-summary2",

  // 2次集計（特調校按分登録）
  TOKUCHOUKOU_ANBUN_TOROKU: "/tokuchoukou-anbun-toroku",

  // 常態化した指定地区外の按分人数設定
  INFANT_ROUTINE_ANBUN: "/infant-routine-anbun",

  // 3次集計実行
  INFANT_SUMMARY3: "/infant-summary3",

  // 幼児集計表（増減率表・就学率表）
  INFANT_SUMMARY_RATES: "/infant-summary-rates",

  //児童・生徒・学級数
  ELEM_JSH_STUDENT_CLASS: "/elem-jsh-student-class",

  //小学校増減率表（採用率修正）
  ELEM_CHANGE_RATES: "/elem-change-rates",

  //中学校増減率表（採用率修正）
  JHS_CHANGE_RATES: "/jhs-change-rates",
} as const;
