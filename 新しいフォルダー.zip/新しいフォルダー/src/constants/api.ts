export const API_PATH = {
  HOME: "/",

  //ログイン
  LOGIN: "/auth/login",

  //ユーザー
  USER_ADD: "/user/add",
  USER_LIST: "/user/list",
  USER_DETAIL: "/user/detail",
  USER_UPDATE: "/user/update",
  USER_DELETE: "/user/delete",

  //調整コード
  ADJUSTCODE_LIST: "/adjust_code/list",
  ADJUSTCODE_DETAIL: "/adjust_code/detail",
  ADJUSTCODE_ADD: "/adjust_code/add",
  ADJUSTCODE_UPDATE: "/adjust_code/update",
  ADJUSTCODE_DELETE: "/adjust_code/delete",
  ADJUSTCODE_DOWNLOAD: "/adjust_code/download",

  //住基DB
  JUKI_DB_LIST: "/juki_db/list",
  JUKI_DB_IMPORT: "juki_db/import",

  //学区域情報
  SCHOOL_AREA_INFO_LIST: "/school_area_info/list",
  SCHOOL_AREA_INFO_IMPORT: "/school_area_info/import",

  //学校コード
  SCHOOL_CODE_LIST: "/master/school_code/list",
  SCHOOL_CODE_IMPORT: "/master/school_code/import",

  WARD_CODE_LIST: "/master/code/ward/list",
  // 学籍DB
  GAKUSEKI_DB_IMPORT_EXECUTE: "/gakuseki_db_import_excute",
  GAKUSEKI_DB_IMPORT_INFO: "/gakuseki_db_import_info",
  GAKUSEKI_DB_LIST: "/gakuseki_db_list",
  // 学区域不明児
  FUMEI_AREA_EXECUTE_INFO: "/infant/fumei_area_execute_info",
  FUMEI_AREA_EXECUTE: "/infant/fumei_area_execute",
  FUMEI_AREA_LIST_PRINT: "/infant/fumei_area_list_print",

  // 入力票登録情報
  FUMEI_AREA_INPUT_EXECUTE_INFO: "/infant/summary_1_execute_info",
  FUMEI_AREA_INPUT_EXECUTE: "/infant/summary_1_execute",
  FUMEI_AREA_INPUT_LIST_PRINT: "/infant/summary_1_list_print",

  // 2次集計実行
  INFANT_SUMMARY2_EXECUTE_INFO: "/infant/summary_2_execute_info",
  INFANT_SUMMARY2_EXECUTE: "/infant/summary_2_execute",
  INFANT_SUMMARY2_LIST_PRINT: "/infant/summary_2_list_print",

  //特調校按分登録
  TOKUCHOU_ANBUN_TOROKU_LIST: "/infant/anbun_list",
  TOKUCHOU_ANBUN_TOROKU_INFO: "/infant/anbun_info",
  TOKUCHOU_ANBUN_TOROKU_PRINT: "/infant/anbun_print",
  TOKUCHOU_ANBUN_TOROKU_REGISTER: "/infant/anbun_register",

  //常態化した指定地区外の按分人数設定
  INFANT_ROUTINE_ANBUN_LIST: "/infant/routine_anbun_list",
  INFANT_ROUTINE_ANBUN_INFO: "/infant/routine_anbun_info",
  INFANT_ROUTINE_ANBUN_PRINT: "/infant/routine_anbun_print",
  INFANT_ROUTINE_ANBUN_REGISTER: "/infant/routine_anbun_register",

  // 3次集計実行
  INFANT_SUMMARY3_EXECUTE_INFO: "/infant/summary_3_execute_info",
  INFANT_SUMMARY3_EXECUTE: "/infant/summary_3_execute",
  INFANT_SUMMARY3_LIST_PRINT: "/infant/summary_3_list_print",

  //幼児集計表（増減率表・就学率表）
  INFANT_SUMMARY_CHANGE_RATE_LIST: "/infant/summary_change_rates_list",
  INFANT_SUMMARY_ENROLMENT_RATE_LIST: "/infant/summary_enrolment_rates_list",
  INFANT_SUMMARY_CHANGE_RATE_PRINT: "/infant/summary_change_rates_print",
  INFANT_SUMMARY_CHANGE_RATE_UPDATE: "/infant/summary_change_rates_update",
  INFANT_SUMMARY_ENROLMENT_RATE_LIST_PRINT: "/infant/summary_enrolment_rates_print",
  INFANT_SUMMARY_ENROLMENT_RATE_UPDATE: "/infant/summary_enrolment_rates_update",
  INFANT_SUMMARY_CHANGE_RATE_EXECUTE: "/infant/summary_change_rates_execute",
  INFANT_SUMMARY_ENROLMENT_RATE_EXECUTE: "/infant/summary_enrolment_rates_execute",
  INFANT_SUMMARY_CHANGE_RATE_EXECUTE_INFO: "/infant/summary_change_rates_execute_info",
  INFANT_SUMMARY_ENROLMENT_RATE_EXECUTE_INFO: "/infant/summary_enrolment_rates_execute_info",

  //児童・生徒・学級数
  ELEM_STUDENTS_CLASSES_DATA_LIST: "/elem_child_class_data_list",
  JHS_STUDENTS_CLASSES_DATA_LIST: "/jhs_child_class_data_list",
  JHS_ELEM_STUDENTS_CLASSES_DATA_IMPORT: "/elem_jhs/child_class_data_import",

  //小学校推計 採用率修正（小学校増減率表・各率登録印刷・将来推計印刷）
  ELEM_CHANGE_RATE_LIST: "/elem_change_rates_list",
  ELEM_CHANGE_RATE_UPDATE: "/elem_change_rates_update",
  ELEM_INFANT_RATE_INFO_PRINT: "/elem_infant_rate_info_print",
  ELEM_NEXT6Y_FORECAST_PRINT: "/elem_next6y_forecast_print",

  //中学校推計 採用率修正（中学校増減率表）
  JHS_CHANGE_RATE_LIST: "/jhs_change_rates_list",
  JHS_CHANGE_RATE_UPDATE: "/jhs_change_rates_update",
};

export default API_PATH;
