export const VALIDATION_MESSAGE = {
  REQUIRED_FIELD: "※この項目は必須です",
  REQUIRED_FILE: "ファイルを選択してくだいさい",
  EMAIL_FORMAT: "E-mailの形式が正しくありません。",
  FILE_SIZE_ERROR: "ファイルサイズは100MB以下にしてください。",
};

export const ERROR_MESSAGE = {
  // 集計未実行時に一覧上部へ表示する文言
  NOT_EXECUTED_MESSAGE: "集計が実行されていません",
  FUMEI_INPUT_NOT_EXECUTED_MESSAGE: "学区域不明児集計が未実施です\n先に、集計処理を行ってください",
  ANBURITSU_NOT_EXECUTED_MESSAGE:
    "按分率の集計ができませんでした。学籍DB（小学生）。および、学区域情報の登録を行ってください",
};
