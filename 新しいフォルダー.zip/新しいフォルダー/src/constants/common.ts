import { ROUTES } from "@/constants/routes";

export const PagePaths: Record<string, string> = {
  [ROUTES.TOP]: "トップ",
  [ROUTES.USERLIST]: "マスタ管理　＞　ユーザー ＞ 一覧",
  [ROUTES.USERADD]: "マスタ管理　＞　ユーザー ＞　登録",
  [ROUTES.USERUPDATE]: "マスタ管理　＞　ユーザー ＞　詳細",
  [ROUTES.ADJUSTCODELIST]: "幼児数集計 ＞　調整コード　＞　一覧",
  [ROUTES.ADJUSTCODEADD]: "幼児数集計 ＞　調整コード　＞　登録",
  [ROUTES.ADJUSTCODEUPDATE]: "幼児数集計 ＞　調整コード　＞　詳細",
  [ROUTES.JUKIDBLIST]: "マスタ管理　＞　住基DB",
  [ROUTES.SCHOOL_AREA_INFO_LIST]: "マスタ管理　＞　学区域情報",
  [ROUTES.SCHOOLLIST]: "マスタ管理　＞　学校マスタ",
  [ROUTES.GAKUSEKI_DB]: "マスタ管理　＞　学籍DB",
  [ROUTES.FUMEI_AREA_LIST]: "幼児数集計 ＞　学区域不明児",
  [ROUTES.INFANT_SUMMARY1]: "幼児数集計 ＞　学区域不明児 入力票取込",
  [ROUTES.INFANT_SUMMARY2]: "幼児数集計 ＞　2次集計実行",
  [ROUTES.TOKUCHOUKOU_ANBUN_TOROKU]: "幼児数集計 ＞　2次集計（特調校按分登録）",
  [ROUTES.INFANT_SUMMARY3]: "幼児数集計 ＞　3次集計実行",
  [ROUTES.INFANT_ROUTINE_ANBUN]: "幼児数集計 ＞　常態化した指定地区外の按分人数設定",
  [ROUTES.INFANT_SUMMARY_RATES]: "幼児数集計 ＞　幼児集計表出力",
  [ROUTES.ELEM_JSH_STUDENT_CLASS]: "小学校推計 ＞　児童生徒学級数",
};

// LocalStorage Key Enum
export enum ELocalStorgeKey {
  TRANSLATIONS_KEY = "translations",
  TOKEN = "yce_tkn",
  USER_INFO = "user_info",
  FITLER = "filter",
  REAL_DOMAIN = "real_domain",
}

// APIレスポンスのMessageLevel　Enum
export enum MessageLevel {
  INFO = "INFO",
  WARN = "WARN",
  ERROR = "ERROR",
}

// APIレスポンス
export type CommonResponse = {
  code: string;
  message: string;
  msg_level: string;
  info: any;
};

// セッション無効化を示すAPIレスポンスコード（BE側 MessageCode と対応）
// ・LOGIN_TIMEOUT: 一定時間操作がなかったことによるタイムアウト
// ・LOGIN_DUP_LOGIN: 他端末からの後勝ちログインによる多重ログイン検知
// ・USER_LOCKED: ユーザー利用停止
// BE側はこれらのケースでもHTTPステータスは200で返すため、codeで判定する必要がある
export const SESSION_INVALID_CODES = ["-102", "-103", "-990000010007"];

export const MAX_LENGTH = {
  MAX_LENGTH_12: 12,
  MAX_LENGTH_40: 40,
  MAX_LENGTH_500: 500,
};

export const CONFIRM_MESSAGE = {
  UPDATE_MSG: "入力した内容で保存しますか？",
  DELETE_MSG: "このデータを削除しますか？",
  EXECUTE_MSG: "実行してよろしいでしょうか？",
};
