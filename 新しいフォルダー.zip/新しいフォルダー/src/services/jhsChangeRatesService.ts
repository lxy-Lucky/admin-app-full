import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { JhsChangeRateReqInfo, JhsChangeRateUpdateReqInfo } from "@/app/jhs-change-rates/type";

/** 中学校増減率表を取得*/
export const getJhsChangeRateList = (req: JhsChangeRateReqInfo) => {
  return api.post(API_PATH.JHS_CHANGE_RATE_LIST, req);
};

/** 中学校増減率表の修正登録（採用率・その他率・備考）*/
export const updateJhsChangeRateList = (req: JhsChangeRateUpdateReqInfo) => {
  return api.post(API_PATH.JHS_CHANGE_RATE_UPDATE, req);
};
