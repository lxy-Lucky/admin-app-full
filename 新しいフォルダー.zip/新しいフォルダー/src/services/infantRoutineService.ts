import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { AnbunRegisterReqInfo, AnbunRequestInfo } from "@/app/tokuchoukou-anbun-toroku/type";

/** 按分率リスト取得（list_flg：""=自動集計結果リスト、"1"=登録済みリスト）
 *  ※データが無い場合はinfoにnullが返る */
export const getAnbunList = (req: AnbunRequestInfo) => {
  return api.post(API_PATH.INFANT_ROUTINE_ANBUN_LIST, req);
};

/** 按分率登録 実行情報取得（登録日・登録者）
 *  ※未登録の場合はinfoにnullが返る */
export const getAnbunInfo = (req: AnbunRegisterReqInfo) => {
  return api.post(API_PATH.INFANT_ROUTINE_ANBUN_INFO, req);
};

/** 按分率登録（取込Excelファイルの実績入力表を、対象年度の按分人数として登録）
 *  multipart/form-data形式で、JSONデータ（data）とExcelファイル（file）を送信する */
export const register = (req: FormData) => {
  return api.post(API_PATH.INFANT_ROUTINE_ANBUN_REGISTER, req, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

/** 不明児集計児 印刷（印刷）
 *  ファイルを受け取るためresponseTypeにblobを指定する */
export const listPrint = (req: AnbunRequestInfo) => {
  return api.post<Blob>(API_PATH.INFANT_ROUTINE_ANBUN_PRINT, req, {
    responseType: "blob",
  });
};
