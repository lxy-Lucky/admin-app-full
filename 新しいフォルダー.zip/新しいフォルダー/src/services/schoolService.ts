import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { SchoolListReqInfo } from "@/app/school/type";

export const list = (req: SchoolListReqInfo) => {
  return api.post(API_PATH.SCHOOL_CODE_LIST, req);
};

// 学校コード対応表（Excel）取込
export const excelImport = (req: FormData) => {
  return api.post(API_PATH.SCHOOL_CODE_IMPORT, req, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};
