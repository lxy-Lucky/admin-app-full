import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { InfantSummary2ReqInfo } from "@/app/infant-summary2/type";

/** 幼児数2次 集計実行情報の取得
 *  ※未集計の場合はinfoにnullが返る */
export const executeInfo = (req: InfantSummary2ReqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY2_EXECUTE_INFO, req);
};

/** 幼児数2次 集計実行
 *  1次集計結果と採用按分率から2次集計結果を作成し、登録する（対象年度のデータを洗替） */
export const execute = (req: InfantSummary2ReqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY2_EXECUTE, req);
};

/** 幼児数2次リストのExcel出力（印刷）
 *  ファイルを受け取るためresponseTypeにblobを指定する */
export const listPrint = (req: InfantSummary2ReqInfo) => {
  return api.post<Blob>(API_PATH.INFANT_SUMMARY2_LIST_PRINT, req, {
    responseType: "blob",
  });
};
