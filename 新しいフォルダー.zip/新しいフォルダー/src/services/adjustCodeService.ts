import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { CodeAdjustInfoReq } from "@/app/adjust-code/type";

export const add = (req: FormData) => {
  return api.post(API_PATH.ADJUSTCODE_ADD, req, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

export const list = (req: CodeAdjustInfoReq) => {
  return api.post(API_PATH.ADJUSTCODE_LIST, req);
};

export const detail = (req: CodeAdjustInfoReq) => {
  return api.post(API_PATH.ADJUSTCODE_DETAIL, req);
};

export const update = (req: FormData) => {
  return api.post(API_PATH.ADJUSTCODE_UPDATE, req, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

export const deleteAdjustCode = (req: CodeAdjustInfoReq) => {
  return api.post(API_PATH.ADJUSTCODE_DELETE, req);
};

export const download = (req: CodeAdjustInfoReq) => {
  return api.post(API_PATH.ADJUSTCODE_DOWNLOAD, req);
};
