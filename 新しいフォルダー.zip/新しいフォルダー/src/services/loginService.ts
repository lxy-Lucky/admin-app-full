import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { log } from "console";
import { LoginReqInfo } from "@/app/type";

export const login = (req: LoginReqInfo) => {
  return api.post(API_PATH.LOGIN, req);
};
