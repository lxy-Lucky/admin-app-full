import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { SchoolAreaInfoReqInfo } from "@/app/school-area-info/type";

export const excelImport = (req: FormData) => {
  return api.post(API_PATH.SCHOOL_AREA_INFO_IMPORT, req, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

export const list = (req: SchoolAreaInfoReqInfo) => {
  return api.post(API_PATH.SCHOOL_AREA_INFO_LIST, req);
};
