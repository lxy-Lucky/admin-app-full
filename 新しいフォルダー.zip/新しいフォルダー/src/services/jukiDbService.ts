import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { JukiDBReqInfo } from "@/app/juki-db/type";

export const csvImport = (req: FormData) => {
  return api.post(API_PATH.JUKI_DB_IMPORT, req, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

export const list = (req: JukiDBReqInfo) => {
  return api.post(API_PATH.JUKI_DB_LIST, req);
};
