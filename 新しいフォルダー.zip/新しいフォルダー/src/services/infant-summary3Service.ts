import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { reqInfo } from "@/app/infant-summary3/type";

/** 幼児数3次 集計実行情報の取得
 *  ※未集計の場合はinfoにnullが返る */
export const executeInfo = (req: reqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY3_EXECUTE_INFO, req);
};

/** 幼児数3次 集計実行*/
export const execute = (req: reqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY3_EXECUTE, req);
};

/** 幼児数3次リストのExcel出力（印刷）
 *  ファイルを受け取るためresponseTypeにblobを指定する */
export const listPrint = (req: reqInfo) => {
  return api.post<Blob>(API_PATH.INFANT_SUMMARY3_LIST_PRINT, req, {
    responseType: "blob",
  });
};
