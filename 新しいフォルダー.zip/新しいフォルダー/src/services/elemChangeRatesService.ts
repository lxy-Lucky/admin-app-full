import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { ElemChangeRateReqInfo, ElemChangeRateUpdateReqInfo } from "@/app/elem-change-rates/type";

/** 小学校増減率表を取得*/
export const getElemChangeRateList = (req: ElemChangeRateReqInfo) => {
  return api.post(API_PATH.ELEM_CHANGE_RATE_LIST, req);
};

/** 小学校増減率表の修正登録（採用率・その他率・備考）*/
export const updateElemChangeRateList = (req: ElemChangeRateUpdateReqInfo) => {
  return api.post(API_PATH.ELEM_CHANGE_RATE_UPDATE, req);
};

/** 幼児・就学・小学校増減率 登録内容Excel出力（各率登録印刷）
 *  ファイルを受け取るためresponseTypeにblobを指定する */
export const elemInfantRateInfoPrint = (req: ElemChangeRateReqInfo) => {
  return api.post<Blob>(API_PATH.ELEM_INFANT_RATE_INFO_PRINT, req, {
    responseType: "blob",
  });
};

/** 児童6年先推計Excel出力（将来推計印刷）
 *  ファイルを受け取るためresponseTypeにblobを指定する */
export const elemNext6yForecastPrint = (req: ElemChangeRateReqInfo) => {
  return api.post<Blob>(API_PATH.ELEM_NEXT6Y_FORECAST_PRINT, req, {
    responseType: "blob",
  });
};
