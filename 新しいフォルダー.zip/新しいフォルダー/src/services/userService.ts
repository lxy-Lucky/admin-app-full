import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { UserRequestInfo } from "@/app/user/type";

export const add = (req: UserRequestInfo) => {
  return api.post(API_PATH.USER_ADD, req);
};

export const list = () => {
  return api.post(API_PATH.USER_LIST);
};

export const detail = (req: UserRequestInfo) => {
  return api.post(API_PATH.USER_DETAIL, req);
};

export const update = (req: UserRequestInfo) => {
  return api.post(API_PATH.USER_UPDATE, req);
};

export const deleteUser = (req: UserRequestInfo) => {
  return api.post(API_PATH.USER_DELETE, req);
};
