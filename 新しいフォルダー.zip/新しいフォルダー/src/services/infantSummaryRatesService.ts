import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { AnbunRegisterReqInfo, AnbunRequestInfo } from "@/app/tokuchoukou-anbun-toroku/type";
import { ChangeRateUpdateReqInfo, EnrolRateUpdateReqInfo } from "@/app/infant-summary-rates/type";

/**幼児集計 増減率表を取得*/
export const getSummaryChangeRateList = (req: AnbunRequestInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY_CHANGE_RATE_LIST, req);
};

/**幼児集計 就学率表を取得*/
export const getSummaryEnrollRateList = (req: AnbunRequestInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY_ENROLMENT_RATE_LIST, req);
};

/** 増減率表の集計を実施*/
export const executeChangeRate = (req: AnbunRegisterReqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY_CHANGE_RATE_EXECUTE, req);
};

/** 就学率表の集計を実施*/
export const executeEnrollRate = (req: AnbunRegisterReqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY_ENROLMENT_RATE_EXECUTE, req);
};

/** 増減率表の集計実行情報（集計実行日・集計実行者）を取得*/
export const executeChangeRateInfo = (req: AnbunRegisterReqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY_CHANGE_RATE_EXECUTE_INFO, req);
};

/** 就学率表の集計実行情報（集計実行日・集計実行者）を取得*/
export const executeEnrollRateInfo = (req: AnbunRegisterReqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY_ENROLMENT_RATE_EXECUTE_INFO, req);
};

/** 増減率表の修正登録（採用率・その他率・備考）*/
export const updateChangeRateList = (req: ChangeRateUpdateReqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY_CHANGE_RATE_UPDATE, req);
};

/** 就学率表の修正登録（採用率・その他率・備考）*/
export const updateEnrollRateList = (req: EnrolRateUpdateReqInfo) => {
  return api.post(API_PATH.INFANT_SUMMARY_ENROLMENT_RATE_UPDATE, req);
};

/** 増減率表 印刷（印刷）
 *  ファイルを受け取るためresponseTypeにblobを指定する */
export const changeRateListPrint = (req: AnbunRequestInfo) => {
  return api.post<Blob>(API_PATH.INFANT_SUMMARY_CHANGE_RATE_PRINT, req, {
    responseType: "blob",
  });
};

/** 就学率表 印刷（印刷）
 *  ファイルを受け取るためresponseTypeにblobを指定する */
export const enrollRateListPrint = (req: AnbunRequestInfo) => {
  return api.post<Blob>(API_PATH.INFANT_SUMMARY_ENROLMENT_RATE_LIST_PRINT, req, {
    responseType: "blob",
  });
};
