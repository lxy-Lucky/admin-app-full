import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { GakusekiDbImportInfoReqInfo, GakusekiDbListReqInfo } from "@/app/gakuseki-db/type";

/** 学籍DB リスト取得（年度・学籍区分で抽出、ページ分のみ返却） */
export const list = (req: GakusekiDbListReqInfo) => {
  return api.post(API_PATH.GAKUSEKI_DB_LIST, req);
};

/** 学籍DB Excel取込
 *  ※form-data形式（data：JSON、file：Excelファイル）で送信する */
export const excelImport = (req: FormData) => {
  return api.post(API_PATH.GAKUSEKI_DB_IMPORT_EXECUTE, req, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

/** 学籍DB 区ごとの取込状況取得（小学生・中学生） */
export const importInfo = (req: GakusekiDbImportInfoReqInfo) => {
  return api.post(API_PATH.GAKUSEKI_DB_IMPORT_INFO, req);
};
