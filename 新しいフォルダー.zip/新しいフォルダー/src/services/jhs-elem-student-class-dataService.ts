import { StudentClassDataReqInfo } from "@/app/elem-jsh-student-class/type";
import API_PATH from "@/constants/api";
import api from "@/utils/api";

// 児童・学級表を取得
export const getElemStudentClassList = (req: StudentClassDataReqInfo) => {
  return api.post(API_PATH.ELEM_STUDENTS_CLASSES_DATA_LIST, req);
};

// 生徒・学級表を取得
export const getJhsStudentClassList = (req: StudentClassDataReqInfo) => {
  return api.post(API_PATH.JHS_STUDENTS_CLASSES_DATA_LIST, req);
};

//ファイルインポート
export const studentClassDataImport = (req: FormData) => {
  return api.post(API_PATH.JHS_ELEM_STUDENTS_CLASSES_DATA_IMPORT, req, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};
