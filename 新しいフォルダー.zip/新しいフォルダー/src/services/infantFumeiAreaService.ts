import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { FumeiAreaReqInfo } from "@/app/fumei-area/type";

/** 学区域不明児 集計実行情報・不明児リストの取得
 *  ※未集計の場合はinfoにnullが返る */
export const executeInfo = (req: FumeiAreaReqInfo) => {
  return api.post(API_PATH.FUMEI_AREA_EXECUTE_INFO, req);
};

/** 学区域不明児 集計実行
 *  ※必須マスタ（住基DB・学区域情報）が未登録の場合はmsg_level=WARNで中断される */
export const execute = (req: FumeiAreaReqInfo) => {
  return api.post(API_PATH.FUMEI_AREA_EXECUTE, req);
};

/** 学区域不明児リストのExcel出力（印刷）
 *  ファイルを受け取るためresponseTypeにblobを指定する */
export const listPrint = (req: FumeiAreaReqInfo) => {
  return api.post<Blob>(API_PATH.FUMEI_AREA_LIST_PRINT, req, {
    responseType: "blob",
  });
};
