import api from "@/utils/api";
import { API_PATH } from "@/constants/api";
import { FumeiAreaInputReqInfo } from "@/app/infant-summary1/type";

/** 学区域不明児 入力票 集計実行情報・不明児リストの取得
 *  ※未集計の場合はinfoにnullが返る */
export const executeInfo = (req: FumeiAreaInputReqInfo) => {
  return api.post(API_PATH.FUMEI_AREA_INPUT_EXECUTE_INFO, req);
};

/** 学区域不明児 入力票 集計実行
 *  ※必須マスタ（住基DB・学区域情報）が未登録の場合はmsg_level=WARNで中断される */
export const execute = (req: FormData) => {
  return api.post(API_PATH.FUMEI_AREA_INPUT_EXECUTE, req, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

/** 学区域不明児 入力票リストのExcel出力（印刷）
 *  ファイルを受け取るためresponseTypeにblobを指定する */
export const listPrint = (req: FumeiAreaInputReqInfo) => {
  return api.post<Blob>(API_PATH.FUMEI_AREA_INPUT_LIST_PRINT, req, {
    responseType: "blob",
  });
};
