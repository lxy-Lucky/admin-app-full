import api from "@/utils/api";
import { API_PATH } from "@/constants/api";

export const list = () => {
  return api.post(API_PATH.WARD_CODE_LIST, {});
};
