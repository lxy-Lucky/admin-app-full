import { NextRequest, NextResponse } from "next/server";

import { API_PATH } from "./constants/api";
import { ROUTES } from "./constants/routes";

export function middleware(request: NextRequest) {
  const { pathname, searchParams } = request.nextUrl;

  const token = request.cookies.get("yce_tkn")?.value;

  // 未ログインユーザーがログイン画面以外にアクセスした場合
  if (
    !token &&
    pathname !== API_PATH.HOME &&
    !pathname.startsWith("/_next") &&
    !pathname.startsWith("/api") &&
    !pathname.startsWith("/images") &&
    !pathname.startsWith("/icons") &&
    !pathname.startsWith("/logo_pdbplatform.png")
  ) {
    const url = new URL(API_PATH.HOME, request.url);

    url.search = searchParams.toString();

    return NextResponse.redirect(url);
  }

  // ログイン済みユーザーがログイン画面にアクセスした場合
  if (token && pathname === API_PATH.HOME) {
    return NextResponse.redirect(new URL(ROUTES.TOP, request.url));
  }

  return NextResponse.next();
}
