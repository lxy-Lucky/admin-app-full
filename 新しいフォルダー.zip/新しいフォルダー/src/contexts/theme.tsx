"use client";

import { ConfigProvider } from "antd";
import React from "react";
import { ThemeProvider as StyledThemeProvider } from "styled-components";

export const theme = {
  colors: {
    absolute_white: "#ffffff",
    absolute_black: "#242424",
    light_blue1: "#ecf3ff",
    light_blue2: "#839bfc",
    light_blue3: "#d6dfeb",
    light_blue4: "#5176ae",
    strong_blue1: "#006ed2",
    strong_blue2: "#4d90fd",
    strong_blue3: "#1677ff",
    strong_blue4: "#004aad",
    light_gray1: "#f7f7f7",
    light_gray2: "#f2f2f2",
    light_gray3: "#ededed",
    light_gray4: "#cccccc50",
    light_gray5: "#d8d8d8",
    light_gray6: "#cdc6c6",
    light_gray7: "#b9b9b9",
    light_gray8: "#f7f9fc",
    strong_gray1: "#8c8c8c",
    strong_gray2: "#7f7f7f",
    strong_gray3: "#595959",
    strong_gray4: "#444746",
    strong_gray5: "#999999",
    light_pink1: "#fd6698",
    light_pink2: "#f9598e",
    dark_pink: "#b04167",
    danger: "#d93025",
    warning1: "#f8b407",
    warning2: "#ebb203",
    success1: "#a0c358",
    success2: "#82a143",
    importing: "#F3C04A",
    light_yellow1: "#fff59d",
  },
  fontSizes: {
    micro: "7px",
    semi_extra_small: "9px",
    extra_small: "10px",
    small: "12px",
    semi_base: "13px",
    base: "14px",
    medium: "16px",
    semi_large: "18px",
    large: "20px",
    extra_large: "24px",
    extra_large_2: "28px",
    huge: "30px",
    huge_2: "38px",
    gigantic: "40px",
    colossal: "45px",
  },
  boxShadows: {
    light_gray: "rgba(99, 99, 99, 0.2)",
    strong_gray: "rgba(0, 0, 0, 0.3)",
    strong_gray1: "rgba(60, 64, 67, 0.3)",
    strong_gray2: "rgba(60, 64, 67, 0.15)",
    light_blue: "rgba(5, 145, 255, 0.1)",
  },
  fontWeights: {
    thin: 300,
    normal: 400,
    light_bold: 500,
    semi_bold: 600,
    bold: 700,
  },
};

const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  return (
    <StyledThemeProvider theme={theme}>
      <ConfigProvider
        theme={{
          components: {
            Select: {
              zIndexPopup: 800,
            },
          },
        }}
      >
        {children}
      </ConfigProvider>
    </StyledThemeProvider>
  );
};

export type KproTheme = typeof theme;

declare module "styled-components" {
  // eslint-disable-next-line @typescript-eslint/no-empty-interface
  export interface DefaultTheme extends KproTheme {}
}

export default ThemeProvider;
