import {
  AdoptRateKbn,
  RateListInfo,
  RateUpdateReqInfo,
  RateUpdateValues,
} from "@/components/RateTable/type";

export type AnbunRequestInfo = {
  /** 対象年度 */
  year: number;
  /** リスト区分（""=自動集計結果リスト、"1"=登録済みリスト） */
  list_flg?: string;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

/** 按分率登録・実行情報取得のリクエスト情報 */
export type AnbunRegisterReqInfo = {
  /** 対象年度 */
  year: number;
};

/** 按分率登録の実行情報（按分率登録・実行情報取得のレスポンス情報）
 *  ※未登録の場合はinfo=nullが返る */
export type AnbunExecuteInfo = {
  /** 対象年度 */
  year: number;
  /** 更新日時（＝按分率登録日。BEは「yyyy/MM/dd HH:mm:ss」形式で返す） */
  update_date: string;
  /** 更新者ID */
  update_user_id: string;
  /** 更新者名（＝按分率登録者） */
  update_user_nm: string;
};

/** 増減率表リストの1行 */
export type InfantChangeRates = {
  /** 増減率表データID（画面には出さない） */
  infant_change_rates_id: string;
  /** 区コード */
  ward_code: string;
  /** 学校コード（4桁） */
  school_code_pre: string;
  /** 学校コード（国指定） */
  school_code: string;
  /** 学校名 */
  school_nm: string;

  /** 昨年度0～4歳児（前年度データが無い学校はnull） */
  last_year_age_0: number | null;
  last_year_age_1: number | null;
  last_year_age_2: number | null;
  last_year_age_3: number | null;
  last_year_age_4: number | null;
  /** 昨年度計（0～4歳児） */
  last_year_total: number | null;

  /** 今年度1～5歳児 */
  this_year_age_1: number | null;
  this_year_age_2: number | null;
  this_year_age_3: number | null;
  this_year_age_4: number | null;
  this_year_age_5: number | null;
  /** 今年度計（1～5歳児） */
  this_year_total: number | null;

  /** 増減率（4年前～今年） */
  change_rate_4y_ago: number | null;
  change_rate_3y_ago: number | null;
  change_rate_2y_ago: number | null;
  change_rate_1y_ago: number | null;
  change_rate_this_year: number | null;

  /** 2年平均 */
  avg2_change_rate: number | null;
  /** その他率（画面で手入力した率） */
  misc_change_rate: number | null;
  /** 3年平均 */
  avg3_change_rate: number | null;
  /** 5年平均 */
  avg5_change_rate: number | null;
  /** 前年採用率 */
  last_year_rate: number | null;
  /** 本年採用率（ラジオボタンで選択した率の値） */
  this_year_rate: number | null;
  /** 採用率区分（未選択の場合はnull） */
  adopt_rate_kbn: AdoptRateKbn | null;
  /** 備考 */
  note: string | null;
};

/** 増減率表リスト取得のレスポンス情報（info） */
export type InfantChangeRatesInfo = RateListInfo<InfantChangeRates>;

/** 就学率表リストの1行 */
export type EnrolRateList = {
  /** 就学率表データID（画面には出さない） */
  infant_enrolment_rates_id: string;
  /** 区コード */
  ward_code: string;
  /** 学校コード（4桁） */
  school_code_pre: string;
  /** 学校コード（国指定） */
  school_code: string;
  /** 学校名 */
  school_nm: string;
  /** 昨年度5歳児 */
  count_age_5: number | null;
  /** 今年度小1 */
  students_1: number | null;
  /** 就学率（4年前） */
  enrol_rate_4y_ago: number | null;
  /** 就学率（3年前） */
  enrol_rate_3y_ago: number | null;
  /** 就学率（2年前） */
  enrol_rate_2y_ago: number | null;
  /** 就学率（1年前） */
  enrol_rate_1y_ago: number | null;
  /** 就学率（今年） */
  enrol_rate_this_year: number | null;
  /** 2年平均 */
  avg2_enrol_rate: number | null;
  /** その他率（画面で手入力した率） */
  misc_enrol_rate: number | null;
  /** 3年平均 */
  avg3_enrol_rate: number | null;
  /** 5年平均 */
  avg5_enrol_rate: number | null;
  /** 前年採用率 */
  last_year_rate: number | null;
  /** 本年採用率（ラジオボタンで選択した率の値） */
  this_year_rate: number | null;
  /** 採用率区分（未選択の場合はnull） */
  adopt_rate_kbn: AdoptRateKbn | null;
  /** 備考 */
  note: string | null;
};

/** 増減率表 修正登録のリクエスト情報 */
export type ChangeRateUpdateReqInfo = RateUpdateReqInfo<
  RateUpdateValues & {
    /** 増減率表データID */
    infant_change_rates_id: string;
    /** その他率（画面の入力値。採用率区分が「その他」の場合は本年採用率にもなる） */
    misc_change_rate: number | null;
  }
>;

/** 就学率表 修正登録のリクエスト情報 */
export type EnrolRateUpdateReqInfo = RateUpdateReqInfo<
  RateUpdateValues & {
    /** 就学率表データID */
    infant_enrolment_rates_id: string;
    /** その他率（画面の入力値。採用率区分が「その他」の場合は本年採用率にもなる） */
    misc_enrol_rate: number | null;
  }
>;

/** 就学率表リスト取得のレスポンス情報（info） */
export type EnrolRateListInfo = RateListInfo<EnrolRateList>;
