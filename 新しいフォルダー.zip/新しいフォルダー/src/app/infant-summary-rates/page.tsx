"use client";

import { useEffect, useState } from "react";
import { Radio, Select } from "antd";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import Button from "@/components/Button/page";
import Dialog from "@/components/Modal/Dialog";
import { CommonResponse, CONFIRM_MESSAGE, MessageLevel } from "@/constants/common";
import {
  changeRateListPrint,
  enrollRateListPrint,
  executeChangeRate,
  executeEnrollRate,
  executeChangeRateInfo,
  executeEnrollRateInfo,
} from "@/services/infantSummaryRatesService";
import { getCurrentYear, saveBlobResponse } from "@/utils/common";
import {
  ConditionPanel,
  ExecuteInfoText,
  ExecuteRow,
  ListToolbar,
  PanelHeader,
  PrintBar,
  ResultKbnRow,
  YearRow,
} from "./styles";
import { AnbunExecuteInfo, AnbunRegisterReqInfo, AnbunRequestInfo } from "./type";
import { RateTableWrapper } from "@/components/RateTable/styles";
import {
  INFANT_CHANGE_RATE_TABLE,
  INFANT_ENROL_RATE_TABLE,
} from "@/components/RateTable/rateTableDefs";
import { useRateTable } from "@/components/RateTable/useRateTable";

//（ラジオボタンの値）
const CHANGE_RATE = "1"; // 増減率表
const ATTENDANCE_RATE = "2"; // 就学率表

/** 幼児集計表出力） */
export default function InfantSummaryRates() {
  const [year, setYear] = useState<number>(new Date().getFullYear());
  // 集計実行情報（集計実行日・集計実行者）。未実行の場合はnull
  const [registerInfo, setRegisterInfo] = useState<AnbunExecuteInfo | null>(null);
  // 集計実行の実行確認ダイアログ表示
  const [exeConfirmDialogOpen, setExeConfirmDialogOpen] = useState(false);
  // 修正登録の確認ダイアログ表示
  const [updateConfirmDialogOpen, setUpdateConfirmDialogOpen] = useState(false);
  // 「集計結果詳細」エリアの折りたたみ
  const [panelCollapsed, setPanelCollapsed] = useState(true);

  // 取り込み完了ダイアログ表示
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  const [resultKbn, setResultKbn] = useState(CHANGE_RATE);

  //現在の年度を取得
  const yearOptions = getCurrentYear();

  // 表示中の一覧（増減率表／就学率表）
  const isChangeRate = resultKbn === CHANGE_RATE;
  const table = isChangeRate ? INFANT_CHANGE_RATE_TABLE : INFANT_ENROL_RATE_TABLE;

  // 表示中の一覧の取得・修正登録（増減率表・就学率表・小学校増減率表で共通の処理）
  const rateTable = useRateTable(table, year);
  const { setErrMsg, setWarnMsg, setIsLoading, clearMessage, isLoading, hasListData } = rateTable;

  // 選択中の表（増減率表／就学率表）の集計実行情報（集計実行日・集計実行者）を取得する
  const fetchExecuteInfo = () => {
    const req: AnbunRegisterReqInfo = {
      year: year,
    };

    (isChangeRate ? executeChangeRateInfo(req) : executeEnrollRateInfo(req))
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          // 未実行の場合はinfo=null（WARN）
          setRegisterInfo(data.info ?? null);
        } else {
          setRegisterInfo(null);
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setRegisterInfo(null);
        setErrMsg(err.message);
      });
  };

  // 初期表示および年度・結果区分の変更時に集計実行情報を取得する
  useEffect(() => {
    fetchExecuteInfo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, resultKbn]);

  // 結果区分（増減率表／就学率表）変更
  const onChangeResultKbn = (value: string) => {
    rateTable.prepareReload();
    // 集計実行情報は表ごとに別のため、取得完了まで切替前の表の情報を残さない
    setRegisterInfo(null);
    setResultKbn(value);
  };

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    rateTable.prepareReload();
    setRegisterInfo(null);
    setYear(value);
  };

  // 集計実行（実行確認ダイアログの「実行」ボタン）
  // 選択中の表（増減率表／就学率表）だけを集計する
  const onExecute = () => {
    clearMessage();
    setIsLoading(true);
    setExeConfirmDialogOpen(false);

    const req: AnbunRegisterReqInfo = {
      year: year,
    };

    (isChangeRate ? executeChangeRate(req) : executeEnrollRate(req))
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO) {
          // 集計成功。レスポンスの実行情報で集計実行日・集計実行者を更新する
          // （一覧は完了ダイアログを閉じた後に取得し直す）
          setRegisterInfo(data.info ?? null);
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else if (data?.msg_level === MessageLevel.WARN) {
          // 学籍DB（小学生）が未登録のため集計されていない
          setWarnMsg(data?.message);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 修正登録ボタン。入力漏れがあれば確認ダイアログを出さずにエラーを表示する
  const onClickUpdate = () => {
    if (rateTable.validateUpdate()) {
      setUpdateConfirmDialogOpen(true);
    }
  };

  // 修正登録（確認ダイアログの「登録」ボタン）
  // 表示中の一覧（増減率表／就学率表）の、表示中ページの全行の採用率・その他率・備考を送る
  const onUpdate = () => {
    setUpdateConfirmDialogOpen(false);
    rateTable.update((message) => {
      // 一覧（更新日・更新者を含む）は完了ダイアログを閉じた後に取得し直す
      setCompleteMsg(message);
      setCompleteDialogOpen(true);
    });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    //一覧を取得し直す
    rateTable.reload();
  };

  // 増減率表印刷ボタン（増減率表のExcel出力）
  const onPrintChangeList = () => {
    clearMessage();
    setIsLoading(true);

    const req: AnbunRequestInfo = {
      year: year,
    };

    changeRateListPrint(req)
      .then(async (res) => {
        // ファイルを受け取れなかった場合は理由がメッセージとして返るため、エラー表示する
        const failedMsg = await saveBlobResponse(res, `幼児集計_増減率表_${year}.xlsx`);

        if (failedMsg) {
          setErrMsg(failedMsg);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 就学率表印刷ボタン（就学率表のExcel出力）
  const onPrintAttandanceList = () => {
    clearMessage();
    setIsLoading(true);

    const req: AnbunRequestInfo = {
      year: year,
    };

    enrollRateListPrint(req)
      .then(async (res) => {
        // ファイルを受け取れなかった場合は理由がメッセージとして返るため、エラー表示する
        const failedMsg = await saveBlobResponse(res, `幼児集計_就学率表_${year}.xlsx`);

        if (failedMsg) {
          setErrMsg(failedMsg);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <>
            <ConditionPanel>
              <PanelHeader
                $collapsed={panelCollapsed}
                onClick={() => setPanelCollapsed((prev) => !prev)}
              >
                <span className="arrow">{panelCollapsed ? "▼" : "▲"}</span>
                <span>集計結果詳細</span>
              </PanelHeader>
              {!panelCollapsed && (
                <>
                  <YearRow>
                    <Select
                      style={{ width: 120 }}
                      placeholder="年を選択してください"
                      options={yearOptions}
                      value={year}
                      onChange={onChangeYear}
                    />
                    <span>年度</span>
                  </YearRow>

                  <ExecuteRow>
                    <Button
                      type="primary"
                      onClick={() => {
                        clearMessage();
                        setExeConfirmDialogOpen(true);
                      }}
                      disabled={isLoading}
                    >
                      集計実行
                    </Button>

                    {/* 集計済みの場合のみ、集計実行日・集計実行者を表示する */}
                    {registerInfo && (
                      <ExecuteInfoText>
                        {/* BEは「yyyy/MM/dd HH:mm:ss」形式で返すため、時分秒までそのまま表示する */}
                        <span>集計実行日：{registerInfo.update_date}</span>
                        <span>集計実行者：{registerInfo.update_user_nm}</span>
                      </ExecuteInfoText>
                    )}

                    {/* 表示中の一覧（増減率表／就学率表）の最終更新日・更新者を、集計実行情報の右隣に表示する */}
                    {rateTable.updateInfo?.update_date && (
                      <ExecuteInfoText>
                        <span>更新日：{rateTable.updateInfo.update_date}</span>
                        <span>更新者：{rateTable.updateInfo.update_user_nm}</span>
                      </ExecuteInfoText>
                    )}
                  </ExecuteRow>

                  <ResultKbnRow>
                    {/* 一覧の表示切替用 */}
                    <Radio.Group
                      value={resultKbn}
                      onChange={(e) => onChangeResultKbn(e.target.value)}
                    >
                      <Radio value={CHANGE_RATE}>増減率表</Radio>
                      <Radio value={ATTENDANCE_RATE}>就学率表</Radio>
                    </Radio.Group>
                  </ResultKbnRow>
                </>
              )}
              <PrintBar>
                {/* 集計結果が無い状態では出力対象が無いため押せないようにする */}

                <Button
                  type="primary"
                  onClick={onPrintChangeList}
                  disabled={isLoading || !hasListData}
                >
                  増減率表印刷
                </Button>
                <Button
                  type="primary"
                  onClick={onPrintAttandanceList}
                  disabled={isLoading || !hasListData}
                >
                  就学率表印刷
                </Button>
              </PrintBar>
            </ConditionPanel>

            {/* 一覧(ListArea)の外に置き、一覧をスクロールしても見えなくならないようにする */}
            <ListToolbar>
              {/* 画面で選択した採用率・その他率・備考を登録する（表示中の一覧の、表示中のページ分） */}
              <Button type="primary" onClick={onClickUpdate} disabled={isLoading || !hasListData}>
                修正登録
              </Button>
            </ListToolbar>
          </>
        }
        errorMessage={rateTable.errMsg}
        warnMessage={rateTable.warnMsg}
      >
        <RateTableWrapper>
          {/* 表を切り替えると列・行のキーも変わるため、表ごとに別のテーブルとして描画する */}
          <CustomTable
            key={resultKbn}
            columns={rateTable.columns}
            dataSource={rateTable.list}
            rowKey={table.rowKey}
            pagination
            stickyHeader
            loading={isLoading}
            size="middle"
            current={rateTable.currentPage}
            pageSize={rateTable.pageSize}
            total={rateTable.totalRecord}
            onPaginationChange={rateTable.onPaginationChange}
          />
        </RateTableWrapper>
      </ListPageLayout>

      {/* 集計実行の実行確認ダイアログ */}
      <Dialog
        mode="import"
        open={exeConfirmDialogOpen}
        onClose={() => setExeConfirmDialogOpen(false)}
        onConfirm={onExecute}
        confirmText="実行"
        showCancel={true}
      >
        {/* 選択中の表に上書きされるデータがある場合は、修正登録した内容も含めて作り直す（洗替）ことを伝える
            ※集計実行情報の有無ではなく、実際にデータがあるかで判断する（実行済みでも0件の場合は上書きされるものが無い） */}
        {rateTable.totalRecord > 0 && (
          <p>
            既に{isChangeRate ? "増減率表" : "就学率表"}は集計実行済みです。
            <br />
            再実行すると、修正登録した採用率・その他率・備考を含め、既存の
            {isChangeRate ? "増減率表" : "就学率表"}のデータが上書きされます。
          </p>
        )}
        <p>{CONFIRM_MESSAGE.EXECUTE_MSG}</p>
      </Dialog>

      {/* 修正登録の確認ダイアログ */}
      <Dialog
        mode="import"
        open={updateConfirmDialogOpen}
        onClose={() => setUpdateConfirmDialogOpen(false)}
        onConfirm={onUpdate}
        confirmText="登録"
        showCancel={true}
      >
        <p>{CONFIRM_MESSAGE.UPDATE_MSG}</p>
      </Dialog>

      {/* 登録完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
