export type AnbunRequestInfo = {
  /** 対象年度 */
  year: number;
  /** リスト区分（""=自動集計結果リスト、"1"=登録済みリスト） */
  list_flg?: string;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

export type AnbunAutoCalculateList = {
  /** 指定校コード */
  shiteikou_code: string;
  /** 指定校名 */
  shiteikou_nm: string;
  /** 指定校在籍人数1年生 */
  shiteikou_cnt_g1: number;
  /** 指定校在籍人数2年生 */
  shiteikou_cnt_g2: number;
  /** 指定校在籍人数3年生 */
  shiteikou_cnt_g3: number;
  /** 指定校在籍人数4年生 */
  shiteikou_cnt_g4: number;
  /** 指定校在籍人数5年生 */
  shiteikou_cnt_g5: number;
  /** 指定校在籍人数6年生 */
  shiteikou_cnt_g6: number;
  /** 指定校在籍人数合計*/
  shiteikou_cnt_total: number;
  /** 受入校コード*/
  ukeirekou_code: string;
  /** 受入校名*/
  ukeirekou_nm: string;
  /** 受入校在籍人数1年生*/
  ukeirekou_cnt_g1: number;
  /* 受入校在籍人数2年生 */
  ukeirekou_cnt_g2: number;
  /* 受入校在籍人数3年生 */
  ukeirekou_cnt_g3: number;
  /** 受入校在籍人数4年生 */
  ukeirekou_cnt_g4: number;
  /** 受入校在籍人数5年生 */
  ukeirekou_cnt_g5: number;
  /** 受入校在籍人数6年生 */
  ukeirekou_cnt_g6: number;
  /** 受入校在籍人数合計*/
  ukeirekou_cnt_total: number;
  /** 受入校②コード（受入校が1校の場合はnull。以下、受入校②の項目はすべて同様） */
  ukeirekou2_code: string | null;
  /** 受入校②名 */
  ukeirekou2_nm: string | null;
  /** 受入校②在籍人数1年生 */
  ukeirekou2_cnt_g1: number | null;
  /** 受入校②在籍人数2年生 */
  ukeirekou2_cnt_g2: number | null;
  /** 受入校②在籍人数3年生 */
  ukeirekou2_cnt_g3: number | null;
  /** 受入校②在籍人数4年生 */
  ukeirekou2_cnt_g4: number | null;
  /** 受入校②在籍人数5年生 */
  ukeirekou2_cnt_g5: number | null;
  /** 受入校②在籍人数6年生 */
  ukeirekou2_cnt_g6: number | null;
  /** 受入校②在籍人数合計 */
  ukeirekou2_cnt_total: number | null;
  /** 受入校② 当年按分率 */
  anbun2_rate_this_year: number | null;
  /** 受入校② 1年前採用按分率 */
  anbun2_rate_1_year_ago: number | null;
  /** 受入校② 2年前採用按分率 */
  anbun2_rate_2_year_ago: number | null;
  /** 受入校② 3年前採用按分率 */
  anbun2_rate_3_year_ago: number | null;
  /** 受入校② 直近3年平均按分率 */
  anbun2_rate_avg_3year: number | null;
  /** 当年按分率（全学年0人の場合はnull） */
  anbun_rate_this_year: number | null;
  /** 1年前採用按分率（未登録の場合はnull） */
  anbun_rate_1_year_ago: number | null;
  /** 2年前採用按分率（未登録の場合はnull） */
  anbun_rate_2_year_ago: number | null;
  /** 3年前採用按分率（未登録の場合はnull） */
  anbun_rate_3_year_ago: number | null;
  /** 直近3年平均按分率（当年＋1年前＋2年前のうち、値がある年度の平均） */
  anbun_rate_avg_3year: number | null;
};

/** 按分率リスト取得のレスポンス情報（info）
 *  ※データが無い場合（学籍DB・学区域情報が未登録）はinfo=nullが返る */
export type AnbunListInfo = {
  /** ページサイズ（0=全件） */
  page_size: number;
  /** 現在表示ページ */
  current_page: number;
  /** 総件数 */
  total_size: number;
  /** 按分率リスト */
  return_list: AnbunAutoCalculateList[];
};

/** 按分率登録・実行情報取得のリクエスト情報 */
export type AnbunRegisterReqInfo = {
  /** 対象年度 */
  year: number;
};

/** 按分率登録の実行情報（按分率登録・実行情報取得のレスポンス情報）
 *  ※未登録の場合はinfo=nullが返る */
export type AnbunExecuteInfo = {
  /** 対象年度 */
  year: number;
  /** 更新日時（＝按分率登録日。BEは「yyyy/MM/dd HH:mm:ss」形式で返す） */
  update_date: string;
  /** 更新者ID */
  update_user_id: string;
  /** 更新者名（＝按分率登録者） */
  update_user_nm: string;
};
