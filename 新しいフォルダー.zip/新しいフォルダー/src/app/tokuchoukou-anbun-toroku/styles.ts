import styled from "styled-components";

// 操作エリア全体（セクション見出し＋年度／集計実行／集計実行情報）
export const ConditionPanel = styled.div`
  border: 1px solid ${(props) => props.theme.colors.light_gray6};
  border-radius: 4px;
  background: ${(props) => props.theme.colors.light_gray8};
  padding: 12px 16px;
`;

// セクション見出し（▼集計結果詳細）
export const PanelHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 12px;
  font-size: ${(props) => props.theme.fontSizes.base};
  font-weight: ${(props) => props.theme.fontWeights.semi_bold};
  color: ${(props) => props.theme.colors.absolute_black};
  cursor: pointer;
`;

// 年度選択行
export const YearRow = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  color: ${(props) => props.theme.colors.absolute_black};
`;

// 集計実行ボタンと集計実行情報を左右に並べる行
export const ExecuteRow = styled.div`
  display: flex;
  align-items: center;
  gap: 24px;
  flex-wrap: wrap;
`;

// 集計実行日・集計実行者の表示
export const ExecuteInfoText = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: ${(props) => props.theme.fontSizes.base};
  color: ${(props) => props.theme.colors.absolute_black};
`;

// 一覧直前の印刷ボタン行（右寄せ）
export const PrintBar = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: 12px;
`;

export const ResultKbnRow = styled.div`
  margin-top: 12px;
`;
