"use client";

import { useEffect, useMemo, useState } from "react";
import { Radio, Select } from "antd";
import type { ColumnsType } from "antd/es/table";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import { numberSorter, sorter } from "@/components/Table/utils";
import Button from "@/components/Button/page";
import Dialog from "@/components/Modal/Dialog";
import { CommonResponse, CONFIRM_MESSAGE, MessageLevel } from "@/constants/common";
import {
  getAnbunInfo,
  getAnbunList,
  listPrint,
  register,
} from "@/services/tokuchoukou-anbun-torokuService";
import { usePagination } from "@/components/Table/pagination";
import { getCurrentYear, renderAnbunRate, saveBlobResponse } from "@/utils/common";
import {
  ConditionPanel,
  ExecuteInfoText,
  ExecuteRow,
  PanelHeader,
  PrintBar,
  ResultKbnRow,
  YearRow,
} from "./styles";
import {
  AnbunAutoCalculateList,
  AnbunExecuteInfo,
  AnbunListInfo,
  AnbunRegisterReqInfo,
  AnbunRequestInfo,
} from "./type";
import { ERROR_MESSAGE } from "@/constants/message";

// 結果区分（ラジオボタンの値）
const RESULT_KBN_AUTO = "1"; // 自動集計結果
const RESULT_KBN_REGISTERED = "2"; // 登録済み按分率

// リスト区分（BEへのリクエスト値）
const LIST_FLG_AUTO = ""; // 自動集計結果リスト
const LIST_FLG_REGISTERED = "1"; // 登録済みリスト

// 学校の種類（BEの項目名の接頭辞）
type SchoolKind = "shiteikou" | "ukeirekou" | "ukeirekou2";
// 按分率の種類（BEの項目名の接頭辞。anbun=受入校①、anbun2=受入校②）
type AnbunRateKind = "anbun" | "anbun2";

/** 受入校②が無い（受入校が1校の区域）行か判定する */
const isNoUkeirekou2 = (record: AnbunAutoCalculateList) => record.ukeirekou2_code == null;

/** 学校名・学校＃の列を生成する
 *  ※受入校②の学校名・学校＃は、受入校②が無い行では対象外のため「-」を表示する */
const createSchoolColumns = (
  kind: SchoolKind,
  nameTitle: string,
): ColumnsType<AnbunAutoCalculateList> => {
  const renderSchool = (value: string | null, record: AnbunAutoCalculateList) =>
    kind === "ukeirekou2" && isNoUkeirekou2(record) ? "-" : value;

  return [
    {
      title: nameTitle,
      dataIndex: `${kind}_nm`,
      key: `${kind}_nm`,
      width: 160,
      sorter: sorter(`${kind}_nm`),
      render: renderSchool,
    },
    {
      title: "学校＃",
      dataIndex: `${kind}_code`,
      key: `${kind}_code`,
      width: 80,
      sorter: sorter(`${kind}_code`),
      render: renderSchool,
    },
  ];
};

/** 学年別人数の表示
 *  ※受入校②の人数は、受入校②が無い行では対象外のため「-」を表示する */
const renderGradeCount =
  (kind: SchoolKind) => (value: number | null, record: AnbunAutoCalculateList) =>
    kind === "ukeirekou2" && isNoUkeirekou2(record) ? "-" : value;

/** 1年～6年の在籍人数＋合計の列を生成する（指定校・受入校①・受入校②で同じ並びのため） */
const createGradeCountColumns = (kind: SchoolKind): ColumnsType<AnbunAutoCalculateList> => [
  ...[1, 2, 3, 4, 5, 6].map((grade) => ({
    title: `${grade}年`,
    dataIndex: `${kind}_cnt_g${grade}`,
    key: `${kind}_cnt_g${grade}`,
    width: 70,
    sorter: numberSorter(`${kind}_cnt_g${grade}`),
    render: renderGradeCount(kind),
  })),
  {
    title: "合計",
    dataIndex: `${kind}_cnt_total`,
    key: `${kind}_cnt_total`,
    width: 80,
    sorter: numberSorter(`${kind}_cnt_total`),
    render: renderGradeCount(kind),
  },
];

/** 按分率の列（当年・3年平均・採用按分率（対象年度の3年前～1年前））を生成する
 *  （受入校①・受入校②で同じ並びのため）
 *  ※受入校②の按分率は、受入校②が無い行では対象外のため「-」を表示する */
const createAnbunRateColumns = (
  kind: AnbunRateKind,
  year: number,
): ColumnsType<AnbunAutoCalculateList> =>
  [
    { title: "当年按分率", field: `${kind}_rate_this_year` },
    { title: "3年平均", field: `${kind}_rate_avg_3year` },
    { title: `${year - 3}年度`, field: `${kind}_rate_3_year_ago` },
    { title: `${year - 2}年度`, field: `${kind}_rate_2_year_ago` },
    { title: `${year - 1}年度`, field: `${kind}_rate_1_year_ago` },
  ].map(({ title, field }) => ({
    title,
    dataIndex: field,
    key: field,
    width: 110,
    sorter: numberSorter(field),
    render: (value: number | null, record: AnbunAutoCalculateList) =>
      kind === "anbun2" && isNoUkeirekou2(record) ? "-" : renderAnbunRate(value),
  }));

/** 2次集計（特調校按分登録） */
export default function TokuchoukouAnbunTorokuPage() {
  const [year, setYear] = useState<number>(new Date().getFullYear());
  // 按分率リスト。データが無い場合は空配列
  const [anbunList, setAnbunList] = useState<AnbunAutoCalculateList[]>([]);
  // 按分率登録の実行情報（登録日・登録者）。未登録の場合はnull
  const [registerInfo, setRegisterInfo] = useState<AnbunExecuteInfo | null>(null);
  // 按分率登録の実行確認ダイアログ表示
  const [exeConfirmDialogOpen, setExeConfirmDialogOpen] = useState(false);

  const [errMsg, setErrMsg] = useState("");
  // 集計未実行など、エラーではないが利用者に対応を促すメッセージ（msg_level=WARN相当）
  const [warnMsg, setWarnMsg] = useState("");
  // 初期表示時に必ず集計実行情報を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(false);

  // 取り込み完了ダイアログ表示
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  const [resultKbn, setResultKbn] = useState(RESULT_KBN_AUTO);

  // 集計結果詳細の折りたたみ状態
  const [executeAreaFolded, setExecutedAreaFolded] = useState(true);

  //現在の年度を取得
  const yearOptions = getCurrentYear();

  // ページネーション（BE側でページ分のみ返却されるため、ページ状態をここで管理する）
  const {
    currentPage,
    pageSize,
    totalRecord,
    setCurrentPage,
    setTotalRecord,
    handlePaginationChange,
  } = usePagination({});

  // 横形式の一覧：指定校 → 受入校① → 受入校② → 受入校①の按分率 → 受入校②の按分率
  const columns = useMemo<ColumnsType<AnbunAutoCalculateList>>(
    () => [
      {
        title: "指定校",
        children: [
          ...createSchoolColumns("shiteikou", "指定校名"),
          ...createGradeCountColumns("shiteikou"),
        ],
      },
      {
        title: "受入校①",
        children: [
          ...createSchoolColumns("ukeirekou", "受入校名"),
          ...createGradeCountColumns("ukeirekou"),
        ],
      },
      {
        title: "受入校②",
        children: [
          ...createSchoolColumns("ukeirekou2", "受入校名"),
          ...createGradeCountColumns("ukeirekou2"),
        ],
      },
      {
        title: "受入校① 按分率",
        children: createAnbunRateColumns("anbun", year),
      },
      {
        title: "受入校② 按分率",
        children: createAnbunRateColumns("anbun2", year),
      },
    ],
    [year],
  );

  //画面に表示されるメッセージをクリア
  const clearMessage = () => {
    setErrMsg("");
    setWarnMsg("");
  };

  // 按分率リスト取得（結果区分に応じて、自動集計結果／登録済み按分率を取得する）
  // ※ローディング開始・メッセージのクリアは呼び出し側で行う
  const fetchList = (page: number, size: number) => {
    const isAuto = resultKbn === RESULT_KBN_AUTO;
    const req: AnbunRequestInfo = {
      year: year,
      list_flg: isAuto ? LIST_FLG_AUTO : LIST_FLG_REGISTERED,
      current_page: page,
      page_size: size,
    };

    // ※データが無い場合（自動集計：学籍DB・学区域情報が未登録、登録済み：按分率が未登録）はWARN（info=null）が返る
    return getAnbunList(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          // データが無い（学籍DB・学区域情報が未登録）場合はinfo=null
          const info: AnbunListInfo | null = data.info ?? null;

          setAnbunList(info?.return_list ?? []);
          // 総件数（データ無しの場合は0件）
          setTotalRecord(info?.total_size ?? 0);
          // データ無し（info=null）の場合のみ注意メッセージを表示する
          setWarnMsg(info ? "" : data?.message || ERROR_MESSAGE.ANBURITSU_NOT_EXECUTED_MESSAGE);
        } else {
          // エラー時は前回の一覧・件数を残さない
          setAnbunList([]);
          setTotalRecord(0);
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setAnbunList([]);
        setTotalRecord(0);
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 按分率登録の実行情報（登録日・登録者）取得
  // ※未登録の場合はinfo=null（WARN）が返るため、登録日・登録者を非表示にする（メッセージは表示しない）
  const fetchRegisterInfo = (targetYear: number) => {
    const req: AnbunRegisterReqInfo = {
      year: targetYear,
    };

    getAnbunInfo(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setRegisterInfo(data.info ?? null);
        } else {
          setRegisterInfo(null);
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setRegisterInfo(null);
        setErrMsg(err.message);
      });
  };

  // テーブル表示用データ（行キーを付与）
  const tableData = useMemo(
    () =>
      anbunList.map((item, index) => ({
        ...item,
        rowKey: index,
      })),
    [anbunList],
  );

  // 初期表示および年度・結果区分の変更時に按分率リストを取得する
  // （メッセージのクリア・ローディング開始は各イベントハンドラで行うため、ここでは取得のみを行う）
  useEffect(() => {
    fetchList(currentPage, pageSize);
    // ページの変更はonPaginationChangeで取得するため、ここでは年度・結果区分の変更時のみ実行する
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, resultKbn]);

  // 初期表示および年度変更時に按分率登録の実行情報を取得する
  useEffect(() => {
    fetchRegisterInfo(year);
  }, [year]);

  // 結果区分（自動集計結果／登録済み按分率）変更
  const onChangeResultKbn = (value: string) => {
    clearMessage();
    setIsLoading(true);
    setCurrentPage(1);
    setResultKbn(value);
  };

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    clearMessage();
    setIsLoading(true);
    // 年度が変わると件数も変わるため、1ページ目から表示し直す
    setCurrentPage(1);
    setYear(value);
  };

  // ページ番号・ページサイズ変更時はBEから該当ページを取得し直す
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      clearMessage();
      setIsLoading(true);
      fetchList(nextPage, nextSize);
    });
  };

  // 按分率登録（実行確認ダイアログの「実行」ボタン）
  const onExecute = () => {
    clearMessage();
    setIsLoading(true);
    setExeConfirmDialogOpen(false);

    const req: AnbunRegisterReqInfo = {
      year: year,
    };

    register(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO) {
          // 登録成功。レスポンスの実行情報で登録日・登録者を更新する
          // （一覧は完了ダイアログを閉じた後に取得し直す）
          setRegisterInfo(data.info ?? null);
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else if (data?.msg_level === MessageLevel.WARN) {
          // 学籍DB・学区域情報が未登録のため登録されていない
          setWarnMsg(data?.message);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    //按分率リスト取得
    clearMessage();
    setIsLoading(true);
    fetchList(currentPage, pageSize);
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ConditionPanel>
            <PanelHeader onClick={() => setExecutedAreaFolded((prev) => !prev)}>
              <span>{executeAreaFolded ? "▼" : "▲"}</span>
              <span>集計結果詳細</span>
            </PanelHeader>

            {!executeAreaFolded && (
              <div>
                <YearRow>
                  <Select
                    style={{ width: 120 }}
                    placeholder="年を選択してください"
                    options={yearOptions}
                    value={year}
                    onChange={onChangeYear}
                  />
                  <span>年度</span>
                </YearRow>

                <ExecuteRow>
                  <Button
                    type="primary"
                    onClick={() => setExeConfirmDialogOpen(true)}
                    // 自動集計結果が表示されている場合のみ登録できる
                    disabled={isLoading || resultKbn !== RESULT_KBN_AUTO || tableData.length === 0}
                  >
                    按分率登録
                  </Button>

                  {/* 按分率登録済みの場合のみ、登録日・登録者を表示する */}
                  {registerInfo && (
                    <ExecuteInfoText>
                      {/* BEは「yyyy/MM/dd HH:mm:ss」形式で返すため、時分秒までそのまま表示する */}
                      <span>登録日：{registerInfo.update_date}</span>
                      <span>登録者：{registerInfo.update_user_nm}</span>
                    </ExecuteInfoText>
                  )}
                </ExecuteRow>

                <ResultKbnRow>
                  {/* 一覧の表示切替用 */}
                  <Radio.Group
                    value={resultKbn}
                    onChange={(e) => onChangeResultKbn(e.target.value)}
                  >
                    <Radio value={RESULT_KBN_AUTO}>自動集計結果</Radio>
                    <Radio value={RESULT_KBN_REGISTERED}>登録済み按分率</Radio>
                  </Radio.Group>
                </ResultKbnRow>
              </div>
            )}
          </ConditionPanel>
        }
        errorMessage={errMsg}
        warnMessage={warnMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={tableData}
          rowKey="rowKey"
          pagination
          stickyHeader
          loading={isLoading}
          size="middle"
          current={currentPage}
          pageSize={pageSize}
          total={totalRecord}
          onPaginationChange={onPaginationChange}
        />
      </ListPageLayout>

      {/* 按分率登録の実行確認ダイアログ */}
      <Dialog
        mode="import"
        open={exeConfirmDialogOpen}
        onClose={() => setExeConfirmDialogOpen(false)}
        onConfirm={onExecute}
        confirmText="実行"
        showCancel={true}
      >
        <p>{CONFIRM_MESSAGE.EXECUTE_MSG}</p>
      </Dialog>

      {/* 登録完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
