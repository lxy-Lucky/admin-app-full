/** 学籍区分（BE: GakusekiDbService の GAKUSEKI_KBN_～ と対応） */
export const GAKUSEKI_KBN = {
  ELEMENTARY: "1", // 小学校
  JUNIOR_HIGH: "2", // 中学校
} as const;

export type GakusekiKbn = (typeof GAKUSEKI_KBN)[keyof typeof GAKUSEKI_KBN];

/** 取込状況の文言（BE: GakusekiDbService の RESULT_～ と対応） */
export const IMPORT_RESULT = {
  IMPORTED: "取込済",
  NOT_IMPORTED: "未取込",
} as const;

/** /gakuseki_db_import_excute のリクエスト（form-dataの「data」部分） */
export type GakusekiDbImportReqInfo = {
  /** 対象年度 */
  year: number;
  /** 学籍区分：1=小学校、2=中学校 */
  gakuseki_kbn: GakusekiKbn;
};

/** /gakuseki_db_import_info のリクエスト */
export type GakusekiDbImportInfoReqInfo = {
  /** 対象年度 */
  year: number;
};

/** /gakuseki_db_list のリクエスト */
export type GakusekiDbListReqInfo = {
  /** 対象年度 */
  year: number;
  /** 学籍区分：1=小学校、2=中学校 */
  gakuseki_kbn: GakusekiKbn;
  /** ページサイズ（一覧における1ページの表示件数） */
  page_size: number;
  /** 現在表示ページ */
  current_page: number;
};

/** 学籍DBリストの1件（BE: GakusekiDbInfoDto） */
export type GakusekiDbInfo = {
  /** 年度 */
  year: number;
  /** 区コード　例：00 */
  ward_code: string;
  /** 区名　例：鶴見区 */
  ward_nm: string | null;
  /** 町コード　例：032 */
  town_code: string | null;
  /** 字コード　例：00 */
  aza_code: string | null;
  /** 番地コード　例：00004 */
  banchi_code_1: string;
  banchi_code_2: string;
  banchi_code_3: string;
  banchi_code_4: string;
  /** 学籍区分：1=小学校、2=中学校 */
  gakuseki_kbn: GakusekiKbn;
  /** 年齢 */
  age: number | null;
  /** 学年 */
  grade: number | null;
  /** 指定校コード　例：00104 */
  shiteikou_code: string | null;
  /** 氏名 */
  person_name: string | null;
  /** 区町字番地住所 */
  address_detail: string | null;
  /** 方書 */
  katagaki: string | null;
  /** 区域区分 */
  area_kbn: string | null;
};

/** 一覧のソート対象項目 */
export enum SORT_TYPE {
  WARD_CODE = "ward_code",
  WARD_NM = "ward_nm",
  SHITEIKOU_CODE = "shiteikou_code",
  GRADE = "grade",
  AGE = "age",
  PERSON_NAME = "person_name",
  ADDRESS_DETAIL = "address_detail",
  KATAGAKI = "katagaki",
  AREA_KBN = "area_kbn",
  TOWN_CODE = "town_code",
  AZA_CODE = "aza_code",
  BANCHI_CODE_1 = "banchi_code_1",
  BANCHI_CODE_2 = "banchi_code_2",
  BANCHI_CODE_3 = "banchi_code_3",
  BANCHI_CODE_4 = "banchi_code_4",
}

/** 区ごとの取込状況（BE: GakusekiDbImportWardDto） */
export type GakusekiDbImportWard = {
  /** 区コード　例：00 */
  ward_code: string;
  /** 区名　例：鶴見区 */
  ward_nm: string;
  /** 取込状況：取込済／未取込 */
  result: string;
};

/** 学籍区分ごとの取込情報（BE: GakusekiDbImportKbnInfoDto） */
export type GakusekiDbImportKbnInfo = {
  /** 取込完了フラグ：1=全区域取込完了 */
  complate_flg: string;
  /** 区ごとの取込状況リスト */
  result_list: GakusekiDbImportWard[];
};

/** /gakuseki_db_import_info のレスポンスinfo（BE: GakusekiDbImportInfoDto） */
export type GakusekiDbImportInfo = {
  /** 小学生取込情報 */
  elem_info: GakusekiDbImportKbnInfo;
  /** 中学生取込情報 */
  jhs_info: GakusekiDbImportKbnInfo;
};
