"use client";

import { useEffect, useMemo, useState } from "react";
import { Radio, Select, type UploadFile } from "antd";
import type { ColumnsType } from "antd/es/table";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import { numberSorter, sorter } from "@/components/Table/utils";
import { usePagination } from "@/components/Table/pagination";
import Button from "@/components/Button/page";
import CsvImportModal from "@/components/Modal/ImportModal/ImportModal";
import Dialog from "@/components/Modal/Dialog";
import { CommonResponse, MessageLevel } from "@/constants/common";
import { excelImport, importInfo, list } from "@/services/gakusekiDbService";
import { getCurrentYear } from "@/utils/common";
import {
  CompactTableWrapper,
  ConditionPanel,
  ImportRow,
  PanelHeader,
  StatusColumn,
  StatusItem,
  StatusRow,
  YearSelect,
} from "./styles";
import {
  GAKUSEKI_KBN,
  GakusekiDbImportInfo,
  GakusekiDbImportKbnInfo,
  GakusekiDbImportReqInfo,
  GakusekiDbInfo,
  GakusekiDbListReqInfo,
  GakusekiKbn,
  IMPORT_RESULT,
  SORT_TYPE,
} from "./type";

// 学籍区分の表示名（取込ダイアログの文言に使用する）
const GAKUSEKI_KBN_LABEL: Record<GakusekiKbn, string> = {
  [GAKUSEKI_KBN.ELEMENTARY]: "小学校",
  [GAKUSEKI_KBN.JUNIOR_HIGH]: "中学校",
};

// 学籍区分ラジオボタンの選択肢（画面上部・取込ダイアログで共通）
const GAKUSEKI_KBN_OPTIONS = [GAKUSEKI_KBN.ELEMENTARY, GAKUSEKI_KBN.JUNIOR_HIGH].map((kbn) => ({
  value: kbn,
  label: GAKUSEKI_KBN_LABEL[kbn],
}));

/** マスタ管理 ＞ 学籍DB */
export default function GakusekiDbPage() {
  const [year, setYear] = useState<number>(new Date().getFullYear());
  // 画面上部の学籍区分（一覧の表示切替用。取込対象の区分とは別に管理する）
  const [listGakusekiKbn, setListGakusekiKbn] = useState<GakusekiKbn>(GAKUSEKI_KBN.ELEMENTARY);
  // 取込ダイアログで選択する取込対象の学籍区分（初期値：小学校）
  const [importGakusekiKbn, setImportGakusekiKbn] = useState<GakusekiKbn>(GAKUSEKI_KBN.ELEMENTARY);
  // 区ごとの取込状況（小学生・中学生）。取得前はnull
  const [importStatus, setImportStatus] = useState<GakusekiDbImportInfo | null>(null);
  // 取込状況の折りたたみ状態（一覧の表示領域を確保するため、初期表示は折りたたむ）
  const [statusCollapsed, setStatusCollapsed] = useState(true);
  // 学籍DBリスト（表示中のページ分のみ）
  const [gakusekiList, setGakusekiList] = useState<GakusekiDbInfo[]>([]);
  const [errMsg, setErrMsg] = useState("");
  // 初期表示時に必ず取込状況・一覧を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(true);
  const [isListLoading, setIsListLoading] = useState(true);
  // データ取込（Excel取込）用ダイアログの開閉状態・取込処理中フラグ
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  // 取込完了報告ダイアログ
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  const yearOptions = getCurrentYear();

  //ファイルアプロードモデルを初期化するため
  const [importDialogKey, setImportDialogKey] = useState(0);

  // ページネーション（BE側でページ分のみ返却されるため、ページ状態をここで管理する）
  const {
    currentPage,
    pageSize,
    totalRecord,
    setCurrentPage,
    setTotalRecord,
    handlePaginationChange,
  } = usePagination({
    initialPage: 1,
    initialPageSize: 1000,
  });

  const columns = useMemo<ColumnsType<GakusekiDbInfo>>(
    () => [
      {
        title: "区コード",
        dataIndex: "ward_code",
        key: "ward_code",
        width: 90,
        sorter: sorter(SORT_TYPE.WARD_CODE),
      },
      {
        title: "区名",
        dataIndex: "ward_nm",
        key: "ward_nm",
        width: 100,
        sorter: sorter(SORT_TYPE.WARD_NM),
      },
      {
        title: "指定校コード",
        dataIndex: "shiteikou_code",
        key: "shiteikou_code",
        width: 120,
        sorter: sorter(SORT_TYPE.SHITEIKOU_CODE),
      },
      {
        title: "学年",
        dataIndex: "grade",
        key: "grade",
        width: 70,
        sorter: numberSorter(SORT_TYPE.GRADE),
      },
      {
        title: "年齢",
        dataIndex: "age",
        key: "age",
        width: 70,
        sorter: numberSorter(SORT_TYPE.AGE),
      },
      {
        title: "氏名",
        dataIndex: "person_name",
        key: "person_name",
        width: 160,
        sorter: sorter(SORT_TYPE.PERSON_NAME),
      },
      {
        title: "住所",
        dataIndex: "address_detail",
        key: "address_detail",
        width: 220,
        sorter: sorter(SORT_TYPE.ADDRESS_DETAIL),
      },
      {
        title: "方書",
        dataIndex: "katagaki",
        key: "katagaki",
        width: 200,
        sorter: sorter(SORT_TYPE.KATAGAKI),
      },
      {
        title: "区域区分",
        dataIndex: "area_kbn",
        key: "area_kbn",
        width: 90,
        sorter: sorter(SORT_TYPE.AREA_KBN),
      },
      {
        title: "町コード",
        dataIndex: "town_code",
        key: "town_code",
        width: 90,
        sorter: sorter(SORT_TYPE.TOWN_CODE),
      },
      {
        title: "字コード",
        dataIndex: "aza_code",
        key: "aza_code",
        width: 90,
        sorter: sorter(SORT_TYPE.AZA_CODE),
      },
      {
        title: "番地コード1",
        dataIndex: "banchi_code_1",
        key: "banchi_code_1",
        width: 120,
        sorter: sorter(SORT_TYPE.BANCHI_CODE_1),
      },
      {
        title: "番地コード2",
        dataIndex: "banchi_code_2",
        key: "banchi_code_2",
        width: 120,
        sorter: sorter(SORT_TYPE.BANCHI_CODE_2),
      },
      {
        title: "番地コード3",
        dataIndex: "banchi_code_3",
        key: "banchi_code_3",
        width: 120,
        sorter: sorter(SORT_TYPE.BANCHI_CODE_3),
      },
      {
        title: "番地コード4",
        dataIndex: "banchi_code_4",
        key: "banchi_code_4",
        width: 120,
        sorter: sorter(SORT_TYPE.BANCHI_CODE_4),
      },
    ],
    [],
  );

  // 学籍DBリストには一意キーが無いため、表示順のindexを行キーとして付与する
  const tableData = useMemo(
    () =>
      gakusekiList.map((item, index) => ({
        ...item,
        rowKey: index,
      })),
    [gakusekiList],
  );

  // 区ごとの取込状況取得
  // ※ローディング開始・メッセージのクリアは呼び出し側で行う
  const fetchImportInfo = (targetYear: number) => {
    importInfo({ year: targetYear })
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setImportStatus(data.info ?? null);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 学籍DBリスト取得（年度・学籍区分で抽出）
  // ※ローディング開始・メッセージのクリアは呼び出し側で行う
  const fetchList = (targetYear: number, kbn: GakusekiKbn, page: number, size: number) => {
    const req: GakusekiDbListReqInfo = {
      year: targetYear,
      gakuseki_kbn: kbn,
      page_size: size,
      current_page: page,
    };

    list(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setGakusekiList(data.info?.return_list ?? []);
          // 全ページ分の総件数
          setTotalRecord(data.info?.total_size ?? 0);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsListLoading(false);
      });
  };

  // 初期表示および年度変更時に取込状況・一覧（1ページ目）を取得する
  useEffect(() => {
    fetchImportInfo(year);
    fetchList(year, listGakusekiKbn, 1, pageSize);
    // 学籍区分・ページの変更は各イベントハンドラで取得するため、ここでは年度変更時のみ実行する
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year]);

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    setErrMsg("");
    setImportStatus(null);
    setIsLoading(true);
    setIsListLoading(true);
    // 年度が変わると件数も変わるため、1ページ目から表示し直す
    setCurrentPage(1);
    setYear(value);
  };

  // 一覧の学籍区分（小学校／中学校）切替。1ページ目から取得し直す
  const onChangeListKbn = (kbn: GakusekiKbn) => {
    setErrMsg("");
    setIsListLoading(true);
    setListGakusekiKbn(kbn);
    setCurrentPage(1);
    fetchList(year, kbn, 1, pageSize);
  };

  // ページ番号・ページサイズ変更時はBEから該当ページを取得し直す
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      setErrMsg("");
      setIsListLoading(true);
      fetchList(year, listGakusekiKbn, nextPage, nextSize);
    });
  };

  // データ取込（Excel取込）実行
  const onImport = (files: UploadFile[]) => {
    // 前回取込失敗時のエラーメッセージが残っていればクリアする
    setErrMsg("");
    setIsImporting(true);

    // multipart/form-data形式でJSONデータ(data)とExcelファイル(file)を送信する
    const req: GakusekiDbImportReqInfo = {
      year: year,
      gakuseki_kbn: importGakusekiKbn,
    };
    const formData = new FormData();
    formData.append("data", new Blob([JSON.stringify(req)], { type: "application/json" }));

    files.forEach((file) => {
      if (file.originFileObj) {
        formData.append("file", file.originFileObj);
      }
    });

    excelImport(formData)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else {
          setCompleteMsg(data?.message);
          setCompleteDialogOpen(true);
          //setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setImportDialogOpen(false);
        setIsImporting(false);
      });
  };

  // 取込ダイアログを開く。取込対象の学籍区分は毎回「小学校」から選択し直してもらう
  const openImportDialog = () => {
    setImportGakusekiKbn(GAKUSEKI_KBN.ELEMENTARY);
    setImportDialogOpen(true);
  };

  // 取込完了報告ダイアログを閉じる。取込結果を反映するため取込状況・一覧（1ページ目）を取得し直す
  const closeCompleteDialog = () => {
    setCompleteDialogOpen(false);
    setIsLoading(true);
    setIsListLoading(true);
    setCurrentPage(1);
    fetchImportInfo(year);
    setImportDialogKey((prev) => prev + 1); //ファイルアプロードモデルを初期化する
    fetchList(year, listGakusekiKbn, 1, pageSize);
  };

  // 学籍区分ごとの取込状況（区ごとに「区名：取込済／未取込」を表示する）
  const renderStatusColumn = (title: string, kbnInfo?: GakusekiDbImportKbnInfo) => (
    <StatusColumn>
      <span>{title}</span>
      {(kbnInfo?.result_list ?? []).map((ward) => (
        <StatusItem key={ward.ward_code} $imported={ward.result === IMPORT_RESULT.IMPORTED}>
          {ward.ward_nm}：{ward.result}
        </StatusItem>
      ))}
    </StatusColumn>
  );

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ConditionPanel>
            <PanelHeader onClick={() => setStatusCollapsed((prev) => !prev)}>
              <span>学籍DB取込状況</span>
              <span className="arrow">{statusCollapsed ? "▼" : "▲"}</span>
            </PanelHeader>

            {/* 区ごとの取込状況（区の数だけ行が増えるため、折りたためるようにする） */}
            {!statusCollapsed && (
              <StatusRow>
                {renderStatusColumn("<小学生>", importStatus?.elem_info)}
                {renderStatusColumn("<中学生>", importStatus?.jhs_info)}
              </StatusRow>
            )}

            <ImportRow>
              <YearSelect>
                <Select
                  style={{ width: 120 }}
                  placeholder="年を選択してください"
                  options={yearOptions}
                  value={year}
                  onChange={onChangeYear}
                />
                <span>年度</span>
              </YearSelect>

              {/* 一覧の表示切替用 */}
              <Radio.Group
                value={listGakusekiKbn}
                onChange={(e) => onChangeListKbn(e.target.value)}
                options={GAKUSEKI_KBN_OPTIONS}
                disabled={isListLoading}
              />

              <Button type="primary" onClick={openImportDialog} disabled={isLoading}>
                データ取込
              </Button>
            </ImportRow>
          </ConditionPanel>
        }
        errorMessage={errMsg}
      >
        {/* 行の高さを詰めて表示件数を増やす（この画面のみの指定） */}
        <CompactTableWrapper>
          <CustomTable
            columns={columns}
            dataSource={tableData}
            rowKey="rowKey"
            pagination
            stickyHeader
            loading={isListLoading}
            size="middle"
            current={currentPage}
            pageSize={pageSize}
            total={totalRecord}
            onPaginationChange={onPaginationChange}
          />
        </CompactTableWrapper>
      </ListPageLayout>

      {/* データ取込（Excel取込）ダイアログ */}
      <CsvImportModal
        key={importDialogKey}
        open={importDialogOpen}
        accept=".xlsx"
        onClose={() => setImportDialogOpen(false)}
        onMultiFileImport={onImport}
        maxUploadFileCount={18}
        inOperation={isImporting}
      >
        <p>
          【{year}年度】の【学籍DBファイル（{GAKUSEKI_KBN_LABEL[importGakusekiKbn]}）（xlsx）】
          <br />
          を選択してください
          <br />
          ※ファイル内の区の取込済みデータは削除されます
        </p>
        <br />
        {/* 取込対象の学籍区分（リクエストのgakuseki_kbnに使用する） */}
        <Radio.Group
          value={importGakusekiKbn}
          onChange={(e) => setImportGakusekiKbn(e.target.value)}
          options={GAKUSEKI_KBN_OPTIONS}
          disabled={isImporting}
        />
        <br />
        <br />
      </CsvImportModal>

      {/* 取込完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeCompleteDialog} confirmText="OK">
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
