"use client";
import { useEffect } from "react";
import AppLayout from "@/components/AppLayout/page";

export default function TopPage() {
  useEffect(() => {});
  return (
    <AppLayout>
      <div></div>
    </AppLayout>
  );
}
