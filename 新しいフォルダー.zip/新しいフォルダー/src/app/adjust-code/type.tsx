import { UploadFile } from "antd";

export type CodeAdjustInfo = {
  year: string;
  data_nm: string;
  file_nm_org: string;
  note: string;
  update_user_nm: string;
  update_date: string;
  adjust_code_info_id: string;
};

export type CodeAdjustInfoReq = {
  adjust_code_info_id: string;
  year: number;
  data_nm: string;
  file_nm: UploadFile;
  note: string;
};

export enum SORT_TYPE {
  DATA_NM = "data_nm",
  FILE_NM_ORG = "file_nm_org",
  UPDATE_USER_NM = "update_user_nm",
  UPDATE_DATE = "update_date",
}

export type FormDatas = {
  year: string;
  data_nm: string;
  file_nm: UploadFile[];
  note: string;
};
