"use client";
import { ColumnsType } from "antd/es/table";
import { SORT_TYPE, CodeAdjustInfo, CodeAdjustInfoReq } from "./type";
import { sorter } from "@/components/Table/utils";
import AppLayout from "@/components/AppLayout/page";
import { TableWrapper } from "@/app/styles";
import Button from "@/components/Button/page";
import CustomTable from "@/components/Table/page";
import { ROUTES } from "@/constants/routes";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { CommonResponse, MessageLevel } from "@/constants/common";
import { download, list } from "@/services/adjustCodeService";
import Link from "next/link";
import { Select, UploadFile } from "antd";
import { DownloadOutlined, FileOutlined } from "@ant-design/icons";
import { ButtonWrapper, ContentWrapper } from "./styles";
import { getCurrentYear } from "@/utils/common";

export default function adjustCodeList() {
  const router = useRouter();
  const [adjustCode, setAjustCode] = useState<CodeAdjustInfo[]>([]);
  const [errMsg, setErrMsg] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const [year, setYear] = useState<number>(new Date().getFullYear());

  const yearOptions = getCurrentYear();

  const columns: ColumnsType<CodeAdjustInfo> = [
    {
      title: "利用中",
      dataIndex: "user_id",
      key: "user_id",
      //sorter: sorter(SORT_TYPE.),
    },
    {
      title: "ファイル名",
      dataIndex: "file_nm_org",
      key: "file_nm_org",
      sorter: sorter(SORT_TYPE.FILE_NM_ORG),
      render: (value: string, record: CodeAdjustInfo) => (
        <div>
          <Link
            href={ROUTES.ADJUSTCODEUPDATE}
            onClick={() => {
              sessionStorage.setItem("adjust_code_id", record.adjust_code_info_id);
            }}
          >
            {value}
          </Link>
          {/* <FileOutlined style={{ marginLeft: 10 }} onClick={() => handleDownload(record.adjust_code_info_id)}/> */}
          <span
            style={{
              position: "relative",
              display: "inline-block",
              width: 20,
              height: 20,
              cursor: "pointer",
              marginLeft: 10,
            }}
            onClick={() => handleDownload(record.adjust_code_info_id)}
          >
            <FileOutlined
              style={{
                fontSize: 20,
              }}
            />

            <DownloadOutlined
              style={{
                position: "absolute",
                left: 5,
                top: 5,
                fontSize: 10,
              }}
            />
          </span>
        </div>
      ),
    },

    {
      title: "データ名",
      dataIndex: "data_nm",
      key: "data_nm",
      sorter: sorter(SORT_TYPE.DATA_NM),
    },

    {
      title: "備考",
      dataIndex: "note",
      key: "note",
    },
    {
      title: "更新者",
      dataIndex: "update_user_nm",
      key: "update_user_nm",
      sorter: sorter(SORT_TYPE.UPDATE_USER_NM),
    },
    {
      title: "更新日",
      dataIndex: "update_date",
      key: "update_date",
      sorter: sorter(SORT_TYPE.UPDATE_DATE),
    },
    {
      title: "",
      dataIndex: "adjust_code_info_id",
      key: "adjust_code_info_id",
    },
  ];

  //登録ボタン
  const registUser = () => {
    router.replace(ROUTES.ADJUSTCODEADD);
  };

  //リスト取得
  useEffect(() => {
    if (year === undefined) {
      return;
    }
    setIsLoading(true);
    const req: CodeAdjustInfoReq = {
      year: year,
      adjust_code_info_id: "",
      file_nm: {} as UploadFile,
      data_nm: "",
      note: "",
    };
    list(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setAjustCode(data.info?.return_list);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        console.log("API FINALLY");
        setIsLoading(false);
      });
  }, [year]);

  // ファイルダウンロード
  const handleDownload = async (adjust_code_id: string) => {
    const req: CodeAdjustInfoReq = {
      year: 0,
      adjust_code_info_id: adjust_code_id,
      file_nm: {} as UploadFile,
      data_nm: "",
      note: "",
    };
    setIsLoading(true);

    download(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setAjustCode(data.info?.return_list);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        console.log("API FINALLY");
        setIsLoading(false);
      });
  };

  return (
    <AppLayout>
      <ContentWrapper>
        <ButtonWrapper>
          <Select
            style={{ width: 200 }}
            placeholder="年を選択してください"
            options={yearOptions}
            value={year}
            onChange={(value) => setYear(value)}
          />
          <Button
            type="primary"
            onClick={() => {
              registUser();
            }}
          >
            新規登録
          </Button>
        </ButtonWrapper>
        <div className="err-msg-div">
          <span className="mess-error">{errMsg}</span>
        </div>
        <TableWrapper>
          <CustomTable
            columns={columns}
            dataSource={adjustCode}
            rowKey="adjust_code_info_id"
            pagination={false}
          />
        </TableWrapper>
      </ContentWrapper>
    </AppLayout>
  );
}
