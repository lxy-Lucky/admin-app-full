"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout/page";
import Button from "@/components/Button/page";
import { Form, FormItem, CustomeTextArea } from "@/app/adjust-code/add/styles";
import { useForm } from "react-hook-form";
import { VALIDATION_MESSAGE } from "@/constants/message";
import { FormDatas, CodeAdjustInfo, CodeAdjustInfoReq } from "@/app/adjust-code/type";
import { deleteAdjustCode, detail, update } from "@/services/adjustCodeService";
import {
  CommonResponse,
  CONFIRM_MESSAGE,
  ELocalStorgeKey,
  MAX_LENGTH,
  MessageLevel,
} from "@/constants/common";
import { ButtonWrapper, ContentWrapper, TextAreaWrapper, UpdateInfoAreaWrapper } from "./styles";
import { ROUTES } from "@/constants/routes";
import { useRouter } from "next/navigation";
import TextAreaCustom from "@/components/TextArea/page";
import { Spin, UploadFile } from "antd";
import LocalStorage from "@/utils/LocalStorage";
import Dialog from "@/components/Modal/Dialog";
import FileUploader from "@/components/FileUploader/page";
import { DeleteMessage } from "@/components/Icons/styles";
import DeleteIcon from "@/components/Icons/DeleteIcon";

export default function DetailPage() {
  const router = useRouter();
  //ユーザーID
  const [isLoading, setIsLoading] = useState(false);
  const [errMsg, setErrMsg] = useState("");
  const [data, setData] = useState<CodeAdjustInfo>();
  const [registData, setRegistData] = useState<FormData>();
  const [id, setAdjustCodeId] = useState("");
  const {
    control,
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors },
  } = useForm<FormDatas>({
    mode: "onSubmit",
    shouldFocusError: true,
    reValidateMode: "onSubmit",
  });

  //エラーメッセージ表示
  const displayError = Object.values(errors)[0]?.message || errMsg;
  const loginUserInfo = LocalStorage.get(ELocalStorgeKey.USER_INFO);
  const loginUserId = loginUserInfo?.user_id;
  const adminPermission = loginUserInfo?.admin_permission;
  const [deleteConfDialogOpen, setDeleteConfDialogOpen] = useState(false);
  const [updateConfDialogOpen, setUpdateConfDialogOpen] = useState(false);
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);
  const [completeMsg, setCompleteMsg] = useState("");

  // 修正処理
  const onSubmit = (formDatas: FormDatas) => {
    //フォームデータセット
    createRequestData(formDatas);

    // 修正確認ダイアログ開く
    setUpdateConfDialogOpen(true);
  };

  // 修正確認OKの場合、修正処理
  const handleUpdate = () => {
    if (!registData) return;

    // 修正確認ダイアログ閉じる
    setUpdateConfDialogOpen(false);
    setIsLoading(true);
    //リクエスト作成

    //APIリクエスト
    update(registData)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setCompleteDialogOpen(true);
          sessionStorage.setItem("adjust_code_id", data.info.adjust_code_info_id);
          setCompleteMsg(data.message);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //削除
  const handleDelete = () => {
    setDeleteConfDialogOpen(false);
    setIsLoading(true);

    //リクエスト作成
    const req: CodeAdjustInfoReq = {
      ...emptyRequest,
      adjust_code_info_id: id,
    };

    //APIリクエスト
    deleteAdjustCode(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.ERROR) {
          setErrMsg(data?.message);
        } else {
          setCompleteDialogOpen(true);
          setCompleteMsg(data.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //詳細
  useEffect(() => {
    const id = sessionStorage.getItem("adjust_code_id");

    if (id) {
      setAdjustCodeId(id);
    }
    setIsLoading(true);
    //リクエスト作成
    const req: CodeAdjustInfoReq = {
      ...emptyRequest,
      adjust_code_info_id: id!,
    };

    //API
    detail(req)
      .then((res) => {
        const data: CommonResponse = res.data;
        //const userInfo = data?.info;

        if (data?.msg_level === MessageLevel.ERROR) {
          setErrMsg(data?.message);
        } else {
          setData(data.info);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);

  //APIユーザーデータを画面上セット
  useEffect(() => {
    if (data) {
      reset({
        //adjust_code_info_id: id,
        year: data.year,
        file_nm: [{ name: data.file_nm_org }],
        data_nm: data.data_nm,
        note: data.note,
      });
    }
  }, [data, reset]);

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    router.replace(ROUTES.ADJUSTCODEUPDATE);
  };

  //フォームデータからAPIリクエストオブジェクト変換
  const createRequestData = (formDatas: FormDatas) => {
    const formData = new FormData();

    formData.append(
      "data",
      new Blob(
        [
          JSON.stringify({
            adjust_code_info_id: id,
            year: formDatas.year,
            data_nm: formDatas.data_nm,
            note: formDatas.note,
          }),
        ],
        { type: "application/json" },
      ),
    );
    const file = formDatas.file_nm?.[0].originFileObj ?? null;

    if (file) {
      formData.append("file", file);
    }

    setRegistData(formData);
  };

  //
  const emptyRequest: CodeAdjustInfoReq = {
    adjust_code_info_id: id,
    year: 0,
    file_nm: {} as UploadFile,
    data_nm: "",
    note: "",
  };

  return (
    <Spin classNames={{ root: "spin_loading" }} spinning={isLoading} style={{ maxHeight: "unset" }}>
      <AppLayout>
        {data && (
          <UpdateInfoAreaWrapper>
            <label htmlFor="update_user_nm">修正者：{data?.update_user_nm}</label>
            <br />
            <label htmlFor="update_date">修正日：{data?.update_date}</label>
          </UpdateInfoAreaWrapper>
        )}
        <ContentWrapper>
          <Form
            onSubmit={handleSubmit(
              //APIエラークリア
              onSubmit,
              () => {
                setErrMsg("");
              },
            )}
            className="form"
          >
            <div className="err-msg-div">
              {displayError && <span className="mess-error">{displayError as string}</span>}
            </div>
            <FormItem>
              {/* 年度 */}
              <div className="label">
                <label htmlFor="year">
                  年度<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <input
                  id="year"
                  type="text"
                  maxLength={MAX_LENGTH.MAX_LENGTH_12}
                  {...register("year", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.year ? "error" : ""}
                />
              </div>
            </FormItem>

            {/* ファイル */}
            <FormItem>
              <div className="label">
                <label htmlFor="user_name">
                  ファイル<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <FileUploader name="file_nm" control={control} accept=".csv" maxCount={1} />
              </div>
            </FormItem>

            {/* データ名 */}
            <FormItem>
              <div className="label">
                <label htmlFor="data_nm">
                  データ名<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <input
                  id="data_nm"
                  type="text"
                  {...register("data_nm", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.data_nm ? "error" : ""}
                />
              </div>
            </FormItem>

            {/* 備考 */}
            <FormItem>
              <div className="label">
                <label htmlFor="note">備考</label>
              </div>

              <div className="input">
                <TextAreaCustom
                  name={"note"}
                  control={control}
                  value={watch("note") || ""}
                  maxLength={MAX_LENGTH.MAX_LENGTH_500}
                />
              </div>
            </FormItem>
            <ButtonWrapper>
              <Button type="primary" typeButton="green" htmlType="submit" disabled={isLoading}>
                修正
              </Button>
              <Button
                type="primary"
                typeButton="gray"
                htmlType="button"
                className="right-align-btn"
                onClick={() => setDeleteConfDialogOpen(true)}
                disabled={id === loginUserId || adminPermission === "0"}
              >
                削除
              </Button>
            </ButtonWrapper>
          </Form>

          {/* 修正確認ダイアログ */}
          <Dialog
            mode="update"
            open={updateConfDialogOpen}
            onClose={() => setUpdateConfDialogOpen(false)}
            onConfirm={handleUpdate}
            confirmText="OK"
            cancelText="キャンセル"
            showCancel={true}
          >
            <p>{CONFIRM_MESSAGE.UPDATE_MSG}</p>
          </Dialog>

          {/* 削除確認ダイアログ */}
          <Dialog
            mode="delete"
            open={deleteConfDialogOpen}
            onClose={() => setDeleteConfDialogOpen(false)}
            onConfirm={handleDelete}
            confirmText="削除"
            cancelText="キャンセル"
            showCancel={true}
          >
            <DeleteMessage>
              <DeleteIcon size={26} />
              <span>{CONFIRM_MESSAGE.DELETE_MSG}</span>
            </DeleteMessage>
          </Dialog>

          {/* 処理完了ダイアログ */}
          <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
            {completeMsg}
          </Dialog>
        </ContentWrapper>
      </AppLayout>
    </Spin>
  );
}
