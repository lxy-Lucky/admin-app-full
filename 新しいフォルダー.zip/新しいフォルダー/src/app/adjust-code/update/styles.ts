import styled from "styled-components";

export const ContentWrapper = styled.div`
  min-width: 30%;
  width: 30%;
  margin: 0 auto;
`;

export const ButtonWrapper = styled.div`
  margin-top: 20px;
  display: flex;
  justify-content: space-between;
`;

export const TextAreaWrapper = styled.div`
  width: 100%;
`;

export const UpdateInfoAreaWrapper = styled.div`
  width: fit-content;
  margin-left: auto;
  text-align: left;
  padding: 20px 20px 0px 0px;
`;
