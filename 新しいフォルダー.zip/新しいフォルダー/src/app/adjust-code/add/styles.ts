import TextArea from "antd/es/input/TextArea";
import styled from "styled-components";

export const RegitButton = styled.div`
  margin-top: 20px;
`;

export const ContentWrapper = styled.div`
  min-width: 30%;
  width: 30%;
  margin: 0 auto;
  padding-top: 20px;
`;

export const Form = styled.form`
  background: ${(props) => props.theme.colors.light_gray1};
  padding: 20px;
  border-radius: 10px;
`;
export const FormItem = styled.div`
  display: flex;
  width: 100%;
  margin-top: 20px;
  .label {
    width: 150px;
    min-width: 150px;
  }

  .input {
    flex: 1;
    min-wdith: 20px;
  }
  .input input[type="text"] {
    width: 100%;
    height: 40px;
    font-size: ${(props) => props.theme.fontSizes.semi_large};
    border: 2px solid ${(props) => props.theme.colors.light_gray4};
    background-color: ${(props) => props.theme.colors.absolute_white};
    border-radius: 5px;
    padding: 10px 50px 13px 10px;
    box-sizing: border-box;
    &:hover,
    &:focus {
      border: 2px solid ${(props) => props.theme.colors.strong_blue2};
      outline: none !important;
    }
  }

  .input input[type="text"]:disabled {
    background-color: ${(props) => props.theme.colors.light_gray3};
  }
`;

export const CustomeTextArea = styled(TextArea)`
  width: 100%;
  box-sizing: border-box;
  border: 2px solid ${(props) => props.theme.colors.light_gray4};
`;
