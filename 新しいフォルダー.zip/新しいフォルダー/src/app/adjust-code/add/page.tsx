"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout/page";
import { RegitButton, ContentWrapper, Form, FormItem, CustomeTextArea } from "./styles";
import Button from "@/components/Button/page";
import { ROUTES } from "@/constants/routes";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { VALIDATION_MESSAGE } from "@/constants/message";
import { CodeAdjustInfo, FormDatas, CodeAdjustInfoReq } from "../type";
import { add } from "@/services/adjustCodeService";
import { CommonResponse, MAX_LENGTH, MessageLevel } from "@/constants/common";
import TextAreaCustom from "@/components/TextArea/page";
import { Spin } from "antd";
import Dialog from "@/components/Modal/Dialog";
import FileUploader from "@/components/FileUploader/page";

export default function AdjustCodeAddPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [errMsg, setErrMsg] = useState("");
  const {
    register,
    handleSubmit,
    watch,
    control,
    formState: { errors },
  } = useForm<FormDatas>({
    mode: "onSubmit",
    shouldFocusError: true,
    reValidateMode: "onSubmit",
  });

  //エラーメッセージ表示
  const displayError = Object.values(errors)[0]?.message || errMsg;
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);
  const [registData, setRegistData] = useState<FormData>();

  // 登録処理
  const onSubmit = (formDatas: FormDatas) => {
    //フォームデータセット
    const req = createRequestData(formDatas);

    setIsLoading(true);

    add(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setCompleteMsg(data.message);
          sessionStorage.setItem("adjust_code_id", data.info.adjust_code_info_id);
          setCompleteDialogOpen(true);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //フォームデータからAPIリクエストオブジェクト変換
  const createRequestData = (formDatas: FormDatas): FormData => {
    const formData = new FormData();

    formData.append(
      "data",
      new Blob(
        [
          JSON.stringify({
            adjust_code_info_id: "",
            year: formDatas.year,
            data_nm: formDatas.data_nm,
            note: formDatas.note,
          }),
        ],
        { type: "application/json" },
      ),
    );
    const file = formDatas.file_nm?.[0].originFileObj;

    formData.append("file", file!);

    return formData;
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    router.replace(ROUTES.ADJUSTCODEUPDATE);
  };

  useEffect(() => {});
  return (
    <Spin classNames={{ root: "spin_loading" }} spinning={isLoading} style={{ maxHeight: "unset" }}>
      <AppLayout>
        <ContentWrapper>
          <Form
            onSubmit={handleSubmit(
              //APIエラークリア
              onSubmit,
              () => {
                setErrMsg("");
              },
            )}
            className="form"
          >
            <div className="err-msg-div">
              {displayError && <span className="mess-error">{displayError as string}</span>}
            </div>
            <FormItem>
              {/* 年度 */}
              <div className="label">
                <label htmlFor="year">
                  年度<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <input
                  id="year"
                  type="text"
                  maxLength={MAX_LENGTH.MAX_LENGTH_12}
                  {...register("year", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.year ? "error" : ""}
                />
              </div>
            </FormItem>

            {/* ファイル */}
            <FormItem>
              <div className="label">
                <label htmlFor="user_name">
                  ファイル<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <FileUploader name="file_nm" control={control} accept="*" maxCount={1} />
              </div>
            </FormItem>

            {/* データ名 */}
            <FormItem>
              <div className="label">
                <label htmlFor="data_nm">
                  データ名<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <input
                  id="data_nm"
                  type="text"
                  {...register("data_nm", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.data_nm ? "error" : ""}
                />
              </div>
            </FormItem>

            {/* 備考 */}
            <FormItem>
              <div className="label">
                <label htmlFor="note">備考</label>
              </div>

              <div className="input">
                <TextAreaCustom
                  name={"note"}
                  control={control}
                  value={watch("note") || ""}
                  maxLength={MAX_LENGTH.MAX_LENGTH_500}
                />
              </div>
            </FormItem>

            <RegitButton>
              <Button type="primary" htmlType="submit" disabled={isLoading}>
                登録
              </Button>
            </RegitButton>
          </Form>

          {/* 登録完了報告ダイアログ */}
          <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
            <p>{completeMsg}</p>
          </Dialog>
        </ContentWrapper>
      </AppLayout>
    </Spin>
  );
}
