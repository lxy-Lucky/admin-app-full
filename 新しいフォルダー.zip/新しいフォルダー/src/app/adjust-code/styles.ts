import styled from "styled-components";

export const ButtonWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
`;

export const ContentWrapper = styled.div`
  width: 80%;
  margin: 0 auto;
  padding-top: 20px;
`;
