import { UploadFile } from "antd";

export type JukiDBInfo = {
  // 住民種別：1=日本人、2=外国人
  residents_kbn: string;

  // 市区町村コード
  abr_ward_code: string;

  // 生年月日
  date_of_birth: string;

  // 市区群町名
  juki_address_nm: string;

  // 町字
  juki_aza_nm: string;

  // 番地号表記
  banchigou: string;

  // 方書
  katagaki: string;

  // 町字コード
  abr_machiaza_code: string;

  // 番地枝番数値
  banchi_branch_num: string;
};

export type JukiDBReqInfo = {
  year: number;
  page_size: number;
  current_page: number;
};

export enum SORT_TYPE {
  RESIDENTS_KBN = "residents_kbn",

  // 市区町村コード
  ABR_WARD_CODE = "abr_ward_code",

  // 生年月日
  DOB = "date_of_birth",

  // 市区群町名
  JUKI_ADDRESS_NM = "juki_address_nm",

  // 町字
  JUKI_AZA_NM = "juki_aza_nm",

  // 番地号表記
  BANCHIGOU = "banchigou",

  // 方書
  KATAGAKI = "katagaki",

  // 町字コード
  ABR_MACHIAZA_CODE = "abr_machiaza_code",

  // 番地枝番数値
  BANCHI_BRANCH_NUM = "banchi_branch_num",
}

export type FormDatas = {
  year: string;
  file_nm: UploadFile[];
};
