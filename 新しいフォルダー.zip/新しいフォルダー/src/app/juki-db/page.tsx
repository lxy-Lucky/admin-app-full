"use client";
import { ColumnsType } from "antd/es/table";
import { FormDatas, JukiDBInfo, JukiDBReqInfo, SORT_TYPE } from "./type";
import { sorter } from "@/components/Table/utils";
import AppLayout from "@/components/AppLayout/page";
import Button from "@/components/Button/page";
import CustomTable from "@/components/Table/page";
import { ROUTES } from "@/constants/routes";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { CommonResponse, MessageLevel } from "@/constants/common";
import { csvImport, list } from "@/services/jukiDbService";
import { Select, UploadFile } from "antd";
import { ButtonWrapper } from "./styles";
import { getCurrentYear } from "@/utils/common";
import Dialog from "@/components/Modal/Dialog";
import { Form, useForm } from "react-hook-form";
import FileUploader from "@/components/FileUploader/page";
import CsvImportModal from "@/components/Modal/ImportModal/ImportModal";
import ListPageLayout from "@/components/ListPageLayout/page";
import { usePagination } from "@/components/Table/pagination";

export default function jukiDataList() {
  const router = useRouter();
  const [jukiDbInfoList, setjukiDbInfoList] = useState<JukiDBInfo[]>([]);
  const [errMsg, setErrMsg] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [csvDialogOpen, setCsvDialogOpen] = useState(false);
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  const [year, setYear] = useState<number>(new Date().getFullYear());

  //ページネーション
  const { currentPage, pageSize, totalRecord, setTotalRecord, handlePaginationChange } =
    usePagination({
      initialPage: 1,
      initialPageSize: 1000,
    });

  const {
    formState: { errors },
  } = useForm<FormDatas>({
    //mode: 'onSubmit',
    shouldFocusError: true,
    reValidateMode: "onSubmit",
  });
  const columns: ColumnsType<JukiDBInfo> = [
    {
      title: "住民種別",
      dataIndex: "residents_kbn",
      key: "residents_kbn",
      width: 100,
      sorter: sorter(SORT_TYPE.RESIDENTS_KBN),
    },
    {
      title: "市区町村#",
      dataIndex: "abr_ward_code",
      key: "abr_ward_code",
      width: 120,
      sorter: sorter(SORT_TYPE.ABR_WARD_CODE),
    },

    {
      title: "生年月日",
      dataIndex: "date_of_birth",
      key: "date_of_birth",
      width: 120,
      sorter: sorter(SORT_TYPE.DOB),
    },

    {
      title: "市区群町名",
      dataIndex: "juki_address_nm",
      key: "juki_address_nm",
      width: 160,
      sorter: sorter(SORT_TYPE.JUKI_ADDRESS_NM),
    },
    {
      title: "町字",
      dataIndex: "juki_aza_nm",
      key: "juki_aza_nm",
      width: 140,
      sorter: sorter(SORT_TYPE.JUKI_AZA_NM),
    },
    {
      title: "番地号表記",
      dataIndex: "banchigou",
      key: "banchigou",
      width: 140,
      sorter: sorter(SORT_TYPE.BANCHIGOU),
    },
    {
      title: "方書",
      dataIndex: "katagaki",
      key: "katagaki",
      width: 140,
      sorter: sorter(SORT_TYPE.KATAGAKI),
    },
    {
      title: "町字コード",
      dataIndex: "abr_machiaza_code",
      key: "abr_machiaza_code",
      width: 120,
      sorter: sorter(SORT_TYPE.ABR_MACHIAZA_CODE),
    },
    {
      title: "番地枝番数値",
      dataIndex: "banchi_branch_num",
      key: "banchi_branch_num",
      width: 140,
      sorter: sorter(SORT_TYPE.BANCHI_BRANCH_NUM),
    },
  ];

  //csvインポートボタン
  const onCsvImport = (file: UploadFile) => {
    setIsImporting(true);

    const formData = new FormData();

    formData.append(
      "data",
      new Blob(
        [
          JSON.stringify({
            year: year,
          }),
        ],
        { type: "application/json" },
      ),
    );

    formData.append("file", file.originFileObj!);

    csvImport(formData)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        console.log("API FINALLY");
        setCsvDialogOpen(false);
        setIsImporting(false);
      });
  };

  //リスト取得
  useEffect(() => {
    //住基データリスト取得
    getList(pageSize, currentPage);
  }, [year]);

  const getList = (size: number, page: number) => {
    if (year === undefined) {
      return;
    }
    setIsLoading(true);
    const req: JukiDBReqInfo = {
      year: year,
      current_page: page,
      page_size: size,
    };
    list(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          //キー追加
          const jukiInfoList: JukiDBInfo[] = data.info?.return_list;
          const tableData = jukiInfoList.map((item, index) => ({
            ...item,
            rowKey: index,
          }));

          setjukiDbInfoList(tableData);
          setTotalRecord(data.info?.total_size);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        console.log("API FINALLY");
        setIsLoading(false);
      });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    //住基データリスト取得
    getList(pageSize, currentPage);
    router.replace(ROUTES.JUKIDBLIST);
  };

  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      getList(nextSize, nextPage);
    });
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ButtonWrapper>
            <Select
              style={{ width: 200 }}
              placeholder="年を選択してください"
              options={getCurrentYear()}
              value={year}
              onChange={(value) => setYear(value)}
            />
            <Button
              type="primary"
              onClick={() => {
                setCsvDialogOpen(true);
              }}
            >
              データ取込
            </Button>
          </ButtonWrapper>
        }
        errorMessage={errMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={jukiDbInfoList}
          rowKey="rowKey"
          pagination={true}
          stickyHeader
          loading={isLoading}
          size="middle"
          current={currentPage}
          pageSize={pageSize}
          total={totalRecord}
          onPaginationChange={onPaginationChange}
        />
      </ListPageLayout>

      <CsvImportModal
        open={csvDialogOpen}
        accept=".csv"
        onClose={() => setCsvDialogOpen(false)}
        onImport={onCsvImport}
        inOperation={isImporting}
      >
        <p>
          【{year}年度】の【住民基本台帳ファイル（CSV）】
          <br />
          を選択してください
          <br />
          ※取込済みのデータは削除されます
        </p>
        <br />
      </CsvImportModal>

      {/* 登録完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
