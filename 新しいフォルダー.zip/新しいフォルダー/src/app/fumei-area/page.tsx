"use client";

import { useEffect, useMemo, useState } from "react";
import { Select } from "antd";
import type { ColumnsType } from "antd/es/table";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import { numberSorter, sorter } from "@/components/Table/utils";
import Button from "@/components/Button/page";
import Dialog from "@/components/Modal/Dialog";
import { CommonResponse, CONFIRM_MESSAGE, MessageLevel } from "@/constants/common";
import { execute, executeInfo, listPrint } from "@/services/infantFumeiAreaService";
import { usePagination } from "@/components/Table/pagination";
import { getCurrentYear, saveBlobResponse } from "@/utils/common";
import {
  ConditionPanel,
  ExecuteInfoText,
  ExecuteRow,
  PanelHeader,
  PrintBar,
  YearRow,
} from "./styles";
import { FumeiAreaDetail, FumeiAreaExecuteInfo, FumeiAreaReqInfo, SORT_TYPE } from "./type";

// 集計未実行時に一覧上部へ表示する文言
// （APIがメッセージを返さなかった場合のフォールバックとして使用する）
const NOT_EXECUTED_MESSAGE = "集計が実行されていません";

/** 幼児数集計 ＞ 学区域不明児 */
export default function FumeiAreaListPage() {
  const [year, setYear] = useState<number>(new Date().getFullYear());
  // 集計実行情報（集計実行日・集計実行者・不明児リスト）。未集計の場合はnull
  const [fumeiInfo, setFumeiInfo] = useState<FumeiAreaExecuteInfo | null>(null);
  const [errMsg, setErrMsg] = useState("");
  // 集計未実行など、エラーではないが利用者に対応を促すメッセージ（msg_level=WARN相当）
  const [warnMsg, setWarnMsg] = useState("");
  // 初期表示時に必ず集計実行情報を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(true);
  // 必須マスタ未登録ダイアログ（集計実行の中断理由をBEのメッセージそのままで表示する）
  const [masterDialogOpen, setMasterDialogOpen] = useState(false);
  const [masterDialogMsg, setMasterDialogMsg] = useState("");
  // 実行確認ダイアログを表示
  const [exeConfirmDialogOpen, setExeConfirmDialogOpen] = useState(false);

  // 取り込み完了ダイアログ表示
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  // 集計結果詳細の折りたたみ状態
  const [executeAreaFolded, setExecutedAreaFolded] = useState(true);

  const yearOptions = getCurrentYear();

  // ページネーション（BE側でページ分のみ返却されるため、ページ状態をここで管理する）
  const {
    currentPage,
    pageSize,
    totalRecord,
    setCurrentPage,
    setTotalRecord,
    handlePaginationChange,
  } = usePagination({
    initialPage: 1,
    initialPageSize: 1000,
  });

  const columns = useMemo<ColumnsType<FumeiAreaDetail>>(
    () => [
      {
        title: "氏名",
        dataIndex: "person_name",
        key: "person_name",
        width: 160,
        sorter: sorter(SORT_TYPE.PERSON_NAME),
      },
      {
        title: "年齢",
        dataIndex: "age",
        key: "age",
        width: 55,
        sorter: numberSorter(SORT_TYPE.AGE),
      },
      /*
      {
        title: "住民種別",
        dataIndex: "residents_kbn_view",
        key: "residents_kbn_view",
        width: 80,
        sorter: sorter(SORT_TYPE.RESIDENTS_KBN_VIEW),
      },
      */
      {
        title: "生年月日",
        dataIndex: "date_of_birth",
        key: "date_of_birth",
        width: 100,
        sorter: sorter(SORT_TYPE.DATE_OF_BIRTH),
      },
      {
        title: "区名",
        dataIndex: "ward_nm",
        key: "ward_nm",
        width: 80,
        sorter: sorter(SORT_TYPE.WARD_NM),
      },
      {
        title: "町字名",
        dataIndex: "juki_aza_nm",
        key: "juki_aza_nm",
        width: 150,
        sorter: sorter(SORT_TYPE.JUKI_AZA_NM),
      },
      {
        title: "番地号",
        dataIndex: "banchigou",
        key: "banchigou",
        width: 140,
        sorter: sorter(SORT_TYPE.BANCHIGOU),
      },
      {
        title: "方書",
        dataIndex: "katagaki",
        key: "katagaki",
        width: 150,
        sorter: sorter(SORT_TYPE.KATAGAKI),
      },
      {
        title: "番地枝番",
        dataIndex: "banchi_branch_num",
        key: "banchi_branch_num",
        width: 120,
        sorter: sorter(SORT_TYPE.BANCHI_BRANCH_NUM),
      },
      {
        title: "学区域不明理由",
        dataIndex: "fumei_reason",
        key: "fumei_reason",
        width: 200,
        sorter: sorter(SORT_TYPE.FUMEI_REASON),
      },
    ],
    [],
  );

  // 不明児リストには一意キーが無いため、表示順のindexを行キーとして付与する
  const tableData = useMemo(
    () =>
      (fumeiInfo?.fumei_list ?? []).map((item, index) => ({
        ...item,
        rowKey: index,
      })),
    [fumeiInfo],
  );

  // 集計実行情報取得。infoがnullの場合は未集計のため、一覧上部に注意メッセージを表示する
  // ※ローディング開始・メッセージのクリアは呼び出し側（イベントハンドラ）で行う
  const fetchExecuteInfo = (targetYear: number, page: number, size: number) => {
    setIsLoading(true);
    const req: FumeiAreaReqInfo = {
      year: targetYear,
      current_page: page,
      page_size: size,
    };

    return executeInfo(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          const info: FumeiAreaExecuteInfo | null = data.info ?? null;

          setFumeiInfo(info);
          // 全ページ分の総件数（未集計の場合は0件）
          setTotalRecord(info?.total_size ?? 0);
          // 未集計（info=null）の場合のみ注意メッセージを表示する
          setWarnMsg(info ? "" : data?.message || NOT_EXECUTED_MESSAGE);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 初期表示および年度変更時に集計実行情報を取得する
  // （初期表示時点でisLoading=true・メッセージ無しのため、ここでは取得のみを行う）
  useEffect(() => {
    fetchExecuteInfo(year, currentPage, pageSize);
    // ページ番号・ページサイズの変更はonPaginationChangeで取得するため、ここでは年度変更時のみ実行する
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year]);

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    setErrMsg("");
    setWarnMsg("");
    setIsLoading(true);
    // 年度が変わると件数も変わるため、1ページ目から表示し直す
    setCurrentPage(1);
    setYear(value);
  };

  // ページ番号・ページサイズ変更時はBEから該当ページを取得し直す
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      setErrMsg("");
      setIsLoading(true);
      fetchExecuteInfo(year, nextPage, nextSize);
    });
  };

  // 集計実行ボタン
  const onExecute = () => {
    // 前回の集計実行・印刷で表示されたままのエラーメッセージをクリアする
    setErrMsg("");
    setIsLoading(true);
    setExeConfirmDialogOpen(false);

    const req: FumeiAreaReqInfo = {
      year: year,
    };

    execute(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO) {
          // 集計成功。集計実行日・実行者・一覧を反映するため、1ページ目から取得し直す
          // （ローディング解除はfetchExecuteInfo側で行う）
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else if (data?.msg_level === MessageLevel.WARN) {
          // 必須マスタ（住基DB・学区域情報）未登録のため集計は中断されている。
          // どのマスタが未登録かはBEのメッセージに含まれるため、そのまま表示する
          setMasterDialogMsg(data?.message);
          setMasterDialogOpen(true);
        } else {
          setErrMsg(data?.message);
        }

        setIsLoading(false);
      })
      .catch((err) => {
        setErrMsg(err.message);
        setIsLoading(false);
      });
  };

  // 印刷ボタン（学区域不明児リストのExcel出力）
  const onPrint = () => {
    setErrMsg("");
    setIsLoading(true);

    const req: FumeiAreaReqInfo = {
      year: year,
    };

    listPrint(req)
      .then(async (res) => {
        // ファイルを受け取れなかった場合は理由がメッセージとして返るため、エラー表示する
        const failedMsg = await saveBlobResponse(res, `学区域不明児一覧_${year}.xlsx`);

        if (failedMsg) {
          setErrMsg(failedMsg);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    setCurrentPage(1);
    fetchExecuteInfo(year, 1, pageSize);
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ConditionPanel>
            <PanelHeader onClick={() => setExecutedAreaFolded((prev) => !prev)}>
              <span>{executeAreaFolded ? "▼" : "▲"}</span>
              <span>集計結果詳細</span>
            </PanelHeader>

            {!executeAreaFolded && (
              <div>
                <YearRow>
                  <Select
                    style={{ width: 120 }}
                    placeholder="年を選択してください"
                    options={yearOptions}
                    value={year}
                    onChange={onChangeYear}
                  />
                  <span>年度</span>
                </YearRow>

                <ExecuteRow>
                  <Button
                    type="primary"
                    onClick={() => setExeConfirmDialogOpen(true)}
                    disabled={isLoading}
                  >
                    集計実行
                  </Button>

                  {/* 集計済みの場合のみ、集計実行日・集計実行者を表示する */}
                  {fumeiInfo && (
                    <ExecuteInfoText>
                      {/* BEは「yyyy/MM/dd HH:mm:ss」形式で返すため、時分秒までそのまま表示する */}
                      <span>集計実行日：{fumeiInfo.update_date}</span>
                      <span>集計実行者：{fumeiInfo.update_user_nm}</span>
                    </ExecuteInfoText>
                  )}
                </ExecuteRow>
              </div>
            )}
            <PrintBar>
              {/* 集計結果が無い状態では出力対象が無いため押せないようにする */}
              <Button
                type="primary"
                onClick={onPrint}
                disabled={isLoading || tableData.length === 0}
              >
                印刷
              </Button>
            </PrintBar>
          </ConditionPanel>
        }
        errorMessage={errMsg}
        warnMessage={warnMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={tableData}
          rowKey="rowKey"
          pagination
          stickyHeader
          loading={isLoading}
          size="middle"
          current={currentPage}
          pageSize={pageSize}
          total={totalRecord}
          onPaginationChange={onPaginationChange}
        />
      </ListPageLayout>

      {/* 必須マスタ未登録ダイアログ（集計実行の中断を通知する） */}
      <Dialog
        open={masterDialogOpen}
        onClose={() => setMasterDialogOpen(false)}
        confirmText="閉じる"
      >
        <p>{masterDialogMsg}</p>
      </Dialog>

      {/* 実行確認ダイアログ */}
      {/* キャンセル・オーバーレイ押下時はダイアログを閉じるのみとし、「実行」押下時のみ集計を実行する */}
      <Dialog
        mode="import"
        open={exeConfirmDialogOpen}
        onClose={() => setExeConfirmDialogOpen(false)}
        onConfirm={onExecute}
        confirmText="実行"
        showCancel={true}
      >
        <p>{CONFIRM_MESSAGE.EXECUTE_MSG}</p>
      </Dialog>

      {/* 登録完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
