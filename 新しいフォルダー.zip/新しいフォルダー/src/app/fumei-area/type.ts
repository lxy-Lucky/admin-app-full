/** 学区域不明児 各APIの共通リクエスト（BE: CommonRequestBaseDto） */
export type FumeiAreaReqInfo = {
  /** 対象年度 */
  year: number;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

/** 学区域不明児リストの1件（BE: InfantFumeiDetailDto） */
export type FumeiAreaDetail = {
  /** 氏名 */
  person_name: string;
  /** 年齢 */
  age: number;
  /** 住民種別（表示用：日本人／外国人） */
  residents_kbn_view: string;
  /** 誕生日 */
  date_of_birth: string;
  /** 区名　例：戸塚区 */
  ward_nm: string;
  /** 町字名　例：～町～～ */
  juki_aza_nm: string;
  /** 番地号　例：10番地10号 */
  banchigou: string;
  /** 方書　例：コマンドプロンプト10号棟 */
  katagaki: string;
  /** 番地枝番　例：00000111112222233333 */
  banchi_branch_num: string;
};

/** /infant/fumei_area_execute_info のレスポンスinfo（BE: InfantFumeiAreaEntity）
 *  ※集計が未実行の場合、APIはinfoにnullを返す */
export type FumeiAreaExecuteInfo = {
  /** 更新日付（＝集計実行日） */
  update_date: string;
  /** 更新者ID */
  update_user_id: string;
  /** 更新者名（＝集計実行者） */
  update_user_nm: string;
  /** 学区域不明児リスト（リクエストのページ分のみ） */
  fumei_list: FumeiAreaDetail[];
  /** ページサイズ */
  page_size: number;
  /** 現在表示ページ */
  current_page: number;
  /** 総件数（全ページ分） */
  total_size: number;
};

/** 一覧のソート対象項目 */
export enum SORT_TYPE {
  PERSON_NAME = "person_name",
  AGE = "age",
  RESIDENTS_KBN_VIEW = "residents_kbn_view",
  DATE_OF_BIRTH = "date_of_birth",
  WARD_NM = "ward_nm",
  JUKI_AZA_NM = "juki_aza_nm",
  BANCHIGOU = "banchigou",
  KATAGAKI = "katagaki",
  BANCHI_BRANCH_NUM = "banchi_branch_num",
  FUMEI_REASON = "fumei_reason",
}
