export type LoginReqInfo = {
  user_id: string;
  password: string;
  language: string;
};

export enum ELapseFlag {
  AVAILABLE = "0",
  SUSPEND = "1",
  UN_AVAILABLE = "9",
}
