import styled from "styled-components";

// 操作エリア全体（取込状況／年度・学籍区分・データ取込）
export const ConditionPanel = styled.div`
  border: 1px solid ${(props) => props.theme.colors.light_gray6};
  border-radius: 4px;
  background: ${(props) => props.theme.colors.light_gray8};
  color: ${(props) => props.theme.colors.absolute_black};
  padding: 12px 16px;
`;

// セクション見出し（学籍DB取込状況）。クリックで取込状況の表示／非表示を切り替える
// （開閉の見た目は共通の検索条件パネル（SearchForm）に合わせる）
export const PanelHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 12px;
  cursor: pointer;
  user-select: none;
  font-size: ${(props) => props.theme.fontSizes.base};
  font-weight: ${(props) => props.theme.fontWeights.semi_bold};
  color: ${(props) => props.theme.colors.absolute_black};
  cursor: pointer;

  .arrow {
    color: ${(props) => props.theme.colors.strong_blue1};
    font-size: ${(props) => props.theme.fontSizes.small};
  }
`;

// 年度・学籍区分・データ取込ボタンを並べる行
export const ImportRow = styled.div`
  display: flex;
  align-items: center;
  gap: 24px;
  flex-wrap: wrap;
`;

// 一覧の行の高さを詰める（※学籍DB画面のみ）
// size="middle"の上下余白（12px）を半分の6pxにする。antdのセルのスタイルより優先させるため!importantを付ける
export const CompactTableWrapper = styled.div`
  .ant-table-cell {
    padding-top: 6px !important;
    padding-bottom: 6px !important;
  }

  .ant-table-tbody > tr > td.number-cell {
    text-align: right;
    white-space: nowrap;
  }
`;

// 年度選択
export const YearSelect = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
`;

//小・中学校ラジオボタン
export const ResultKbnRow = styled.div`
  display: flex;
  align-items: center;
  gap: 24px;
  flex-wrap: wrap;
`;

// 一覧のデータ取込ボタン行（右寄せ）
export const PrintBar = styled.div`
  display: flex;
  justify-content: flex-end;
`;
