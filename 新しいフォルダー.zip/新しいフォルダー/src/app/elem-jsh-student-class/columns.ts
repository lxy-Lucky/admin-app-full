import { numberSorter, sorter } from "@/components/Table/utils";
import { ColumnsType } from "antd/es/table";
import { SCHOOL_KBN } from "./type";

export const schoolColumns = <T extends Record<string, unknown>>(): ColumnsType<T> => [
  {
    title: "学校名",
    dataIndex: "school_nm",
    key: "school_nm",
    width: 200,
    sorter: sorter("school_nm"),
  },
  {
    title: "学校コード",
    dataIndex: "school_code",
    key: "school_code",
    width: 110,
    sorter: sorter("school_code"),
  },
];

/** 数値の列のセル（右寄せ） */
const numberCell = () => ({ className: "number-cell" });

/** 児童・生徒数の列（右寄せ・数値ソート） */
export const yearColumns = <T extends Record<string, unknown>>(
  title: string,
  dataIndex: string,
  width = 115,
): ColumnsType<T>[number] => ({
  title,
  dataIndex,
  key: dataIndex,
  width,
  sorter: numberSorter(dataIndex),
  onCell: numberCell,
});
