"use client";

import { useEffect, useMemo, useState } from "react";
import { Radio, Select, type UploadFile } from "antd";
import type { ColumnsType } from "antd/es/table";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import { usePagination } from "@/components/Table/pagination";
import Button from "@/components/Button/page";
import CsvImportModal from "@/components/Modal/ImportModal/ImportModal";
import Dialog from "@/components/Modal/Dialog";
import { CommonResponse, MessageLevel } from "@/constants/common";
import {
  studentClassDataImport,
  getElemStudentClassList,
  getJhsStudentClassList,
} from "@/services/jhs-elem-student-class-dataService";
import { getCurrentYear } from "@/utils/common";
import {
  CompactTableWrapper,
  ConditionPanel,
  ImportRow,
  PanelHeader,
  PrintBar,
  ResultKbnRow,
  YearSelect,
} from "./styles";
import {
  SCHOOL_KBN,
  ElemStudentClassData,
  JhsStudentClassData,
  StudentClassDataReqInfo,
  ResultInfo,
} from "./type";

import { schoolColumns, yearColumns } from "./columns";

/** 小学校推計 ＞ 児童生徒学級数情報 */
export default function StudentClassInfoPage() {
  const [year, setYear] = useState<number>(new Date().getFullYear());

  const [resultKbn, setResultKbn] = useState(SCHOOL_KBN.ELEMENTARY);

  const [listElemStudentClassData, setListElemStudentClassData] = useState<ElemStudentClassData[]>(
    [],
  );

  const [listJhsStudentClassData, setListJhsStudentClassData] = useState<JhsStudentClassData[]>([]);

  const [errMsg, setErrMsg] = useState("");
  // データが登録されてない初期の場合かつmsg_level=WARN相当
  const [warnMsg, setWarnMsg] = useState("");
  // 初期表示時に必ず取込状況・一覧を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(true);
  const [isListLoading, setIsListLoading] = useState(true);
  // データ取込（Excel取込）用ダイアログの開閉状態・取込処理中フラグ
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  // 取込完了報告ダイアログ
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  const yearOptions = getCurrentYear();

  //ファイルアプロードモデルを初期化するため
  const [importDialogKey, setImportDialogKey] = useState(0);

  const isElementary = resultKbn === SCHOOL_KBN.ELEMENTARY;

  //インポートファイルタイプ
  const fileType = ".xlsm";

  // 集計結果詳細の折りたたみ状態
  const [executeAreaFolded, setExecutedAreaFolded] = useState(true);

  // ページネーション（BE側でページ分のみ返却されるため、ページ状態をここで管理する）
  const {
    currentPage,
    pageSize,
    totalRecord,
    setCurrentPage,
    setTotalRecord,
    handlePaginationChange,
  } = usePagination({
    initialPage: 1,
    initialPageSize: 1000,
  });

  // 児童・学級情報（小学校）情報
  const elemColumns = useMemo<ColumnsType<ElemStudentClassData>>(
    () => [
      ...schoolColumns<ElemStudentClassData>(),
      ...[1, 2, 3, 4, 5, 6].map((year) =>
        yearColumns<ElemStudentClassData>(`児童数${year}年生`, `students_${year}`),
      ),
      yearColumns<ElemStudentClassData>("合計", "total_students"),
      ...[1, 2, 3, 4, 5, 6].map((year) =>
        yearColumns<ElemStudentClassData>(`学級数${year}年生`, `classes_${year}`),
      ),
      yearColumns<ElemStudentClassData>("合計", "total_classes"),
      yearColumns<ElemStudentClassData>("特殊児童数", "special_students"),
      yearColumns<ElemStudentClassData>("特殊学級数", "special_classes"),
    ],
    [year, resultKbn],
  );

  // 生徒・学級情報（中学校）情報
  const jhsColumns = useMemo<ColumnsType<JhsStudentClassData>>(
    () => [
      ...schoolColumns<JhsStudentClassData>(),
      ...[1, 2, 3].map((year) =>
        yearColumns<JhsStudentClassData>(`生徒数${year}年生`, `jhs${year}_students`),
      ),
      yearColumns<JhsStudentClassData>("合計", "total_students"),
      ...[1, 2, 3].map((year) =>
        yearColumns<JhsStudentClassData>(`学級数${year}年生`, `jhs${year}_classes`),
      ),
      yearColumns<JhsStudentClassData>("合計", "total_classes"),
      yearColumns<JhsStudentClassData>("特殊児童数", "special_students"),
      yearColumns<JhsStudentClassData>("特殊学級数", "special_classes"),
    ],
    [year, resultKbn],
  );

  const init = () => {
    clearMessage();
    setResultKbn(SCHOOL_KBN.ELEMENTARY);
    setListElemStudentClassData([]);
    setListJhsStudentClassData([]);
  };

  const clearMessage = () => {
    setErrMsg("");
    setWarnMsg("");
  };

  //画面表示リスト設定
  const setData = (info: ResultInfo<unknown> | null) => {
    const list = info?.return_list ?? [];

    //画面上表示リストデータ作成
    isElementary
      ? setListElemStudentClassData(addRowKey(list as ElemStudentClassData[]))
      : setListJhsStudentClassData(addRowKey(list as JhsStudentClassData[]));
  };

  //結果オブジェクトにキーがないならエラー表示ため、キー作成
  const addRowKey = <T extends object>(list: T[]) =>
    list.map((item, index) => ({
      ...item,
      rowKey: index,
    }));

  const getList = (year: number, page: number, pageSize: number) => {
    isElementary ? fetchElemList(year, page, pageSize) : fetchJhsList(year, page, pageSize);
  };

  // 児童・生徒・学級数リスト取得（年度・学校区分で抽出）
  // ※ローディング開始・メッセージのクリアは呼び出し側で行う
  const fetchElemList = (targetYear: number, page: number, size: number) => {
    const req: StudentClassDataReqInfo = {
      year: targetYear,
      page_size: size,
      current_page: page,
    };

    getElemStudentClassList(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        success(data);
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsListLoading(false);
      });
  };

  // 生徒・学級数リスト取得（年度・学校区分で抽出）
  const fetchJhsList = (targetYear: number, page: number, size: number) => {
    const req: StudentClassDataReqInfo = {
      year: targetYear,
      page_size: size,
      current_page: page,
    };

    getJhsStudentClassList(req)
      .then((res) => {
        const data: CommonResponse = res.data;
        success(data);
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsListLoading(false);
      });
  };

  //API呼び出の成功レスポンス用共通メソッド
  const success = (data: CommonResponse) => {
    if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
      const info: ResultInfo<unknown> | null = data.info ?? null;

      setData(info);
      setTotalRecord(info?.total_size ?? 0);
    } else {
      // エラー時は前回の一覧・件数を残さない
      setData(null);
      setTotalRecord(0);
      setErrMsg(data?.message);
    }
  };

  // 初期表示および年度変更時に取込状況・一覧（1ページ目）を取得する
  useEffect(() => {
    getList(year, 1, pageSize);
  }, [year, resultKbn]);

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    clearMessage();
    //setImportStatus(null);
    setIsLoading(true);
    setIsListLoading(true);
    // 年度が変わると件数も変わるため、1ページ目から表示し直す
    setCurrentPage(1);
    setYear(value);
  };

  // 結果区分（小学校・中学校）変更
  const onChangeResultKbn = (value: SCHOOL_KBN) => {
    clearMessage();
    setIsLoading(true);
    setCurrentPage(1);
    setResultKbn(value);
  };

  // ページ番号・ページサイズ変更時はBEから該当ページを取得し直す
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      clearMessage();
      setIsListLoading(true);
      getList(year, nextPage, nextSize);
    });
  };

  // データ取込（Excel取込）実行
  const onImport = (file: UploadFile) => {
    // 前回取込失敗時のエラーメッセージが残っていればクリアする
    setErrMsg("");
    setIsImporting(true);

    // multipart/form-data形式でJSONデータ(data)とExcelファイル(file)を送信する
    const req: StudentClassDataReqInfo = {
      year: year,
    };
    const formData = new FormData();
    formData.append("data", new Blob([JSON.stringify(req)], { type: "application/json" }));
    formData.append("file", file.originFileObj!);

    studentClassDataImport(formData)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setImportDialogOpen(false);
        setIsImporting(false);
      });
  };

  // 取込ダイアログを開く。取込対象の学籍区分は毎回「小学校」から選択し直してもらう
  const openImportDialog = () => {
    setImportDialogOpen(true);
  };

  // 取込完了報告ダイアログを閉じる。取込結果を反映するため取込状況・一覧（1ページ目）を取得し直す
  const closeCompleteDialog = () => {
    setCompleteDialogOpen(false);
    setIsLoading(false);
    setIsListLoading(true);
    setCurrentPage(1);
    setImportDialogKey((prev) => prev + 1); //ファイルアプロードモデルを初期化する
    getList(year, 1, pageSize);
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ConditionPanel>
            <PanelHeader onClick={() => setExecutedAreaFolded((prev) => !prev)}>
              <span>{executeAreaFolded ? "▼" : "▲"}</span>
              <span>児童生徒学級数結果詳細</span>
            </PanelHeader>

            {!executeAreaFolded && (
              <ImportRow>
                <YearSelect>
                  <Select
                    style={{ width: 120 }}
                    className="drop-down"
                    placeholder="年を選択してください"
                    options={yearOptions}
                    value={year}
                    onChange={onChangeYear}
                    popupStyle={{ zIndex: 800 }}
                  />
                  <span>年度</span>
                </YearSelect>

                {/* 一覧の表示切替用 */}
                <ResultKbnRow>
                  {/* 一覧の表示切替用 */}
                  <Radio.Group
                    value={resultKbn}
                    onChange={(e) => onChangeResultKbn(e.target.value)}
                  >
                    <Radio value={SCHOOL_KBN.ELEMENTARY}>小学校</Radio>
                    <Radio value={SCHOOL_KBN.JUNIOR_HIGH}>中学校</Radio>
                  </Radio.Group>
                </ResultKbnRow>
              </ImportRow>
            )}

            <PrintBar>
              <Button type="primary" onClick={openImportDialog}>
                データ取込
              </Button>
            </PrintBar>
          </ConditionPanel>
        }
        errorMessage={errMsg}
      >
        {/* 行の高さを詰めて表示件数を増やす（この画面のみの指定） */}
        <CompactTableWrapper>
          {isElementary ? (
            <CustomTable
              columns={elemColumns}
              dataSource={listElemStudentClassData}
              rowKey="rowKey"
              pagination
              stickyHeader
              loading={isListLoading}
              size="middle"
              current={currentPage}
              pageSize={pageSize}
              total={totalRecord}
              onPaginationChange={onPaginationChange}
            />
          ) : (
            <CustomTable
              columns={jhsColumns}
              dataSource={listJhsStudentClassData}
              rowKey="rowKey"
              pagination
              stickyHeader
              loading={isListLoading}
              size="middle"
              current={currentPage}
              pageSize={pageSize}
              total={totalRecord}
              onPaginationChange={onPaginationChange}
            />
          )}
        </CompactTableWrapper>
      </ListPageLayout>

      {/* データ取込（Excel取込）ダイアログ */}
      <CsvImportModal
        key={importDialogKey}
        open={importDialogOpen}
        accept={fileType}
        onClose={() => setImportDialogOpen(false)}
        onImport={onImport}
        inOperation={isImporting}
      >
        <p>
          【{year}年度】の【児童生徒学級数情報ファイル（xlsx）】
          <br />
          を選択してください
          <br />
          ※ファイル内の取込済みデータは削除されます
        </p>
        <br />
      </CsvImportModal>

      {/* 取込完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeCompleteDialog} confirmText="OK">
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
