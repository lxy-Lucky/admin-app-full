import { numberSorter } from "@/components/Table/utils";
import { ColumnsType } from "antd/es/table";

/** 小・中学校切り替え用のenum */
export enum SCHOOL_KBN {
  ELEMENTARY = "1", // 小学校
  JUNIOR_HIGH = "2", // 中学校
}

export type StudentClassDataReqInfo = {
  /** 対象年度 */
  year: number;

  /** ページサイズ（一覧における1ページの表示件数） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

/** 児童・生徒・学級情報 */
export type StudentClassBaseData = {
  /** 年度 */
  year: number;

  /** 学校コード */
  school_code: string;

  /** 学校名 */
  school_nm: string;

  /** 学校区分 */
  school_kbn: string;

  /** 児童・生徒数合計 */
  total_students: number | null;

  /** 特殊児童・生徒数 */
  special_students: number | null;

  /** 学級数_合計 */
  total_classes: number | null;

  /** 特殊学級数 */
  special_classes: number | null;
};

/** 児童・学級数 */
export type ElemStudentClassData = {
  /** 児童・生徒・学級情報 */
  studentClassBaseData: StudentClassBaseData;
  /** 1年児童 */
  students_1: number | null;

  /** 2年児童 */
  students_2: number | null;

  /** 3年児童 */
  students_3: number | null;

  /** 4年児童 */
  students_4: number | null;

  /** 5年児童 */
  students_5: number | null;
  /** 6年児童 */
  students_6: number | null;

  /** 1年学級数 */
  classes_1: number | null;

  /** 2年学級数 */
  classes_2: number | null;

  /** 3年学級数 */
  classes_3: number | null;

  /** 4年学級数 */
  classes_4: number | null;

  /** 5年学級数 */
  classes_5: number | null;

  /** 6年学級数 */
  classes_6: number | null;
};

/** 生徒・学級数 */
export type JhsStudentClassData = {
  /** 児童・生徒・学級情報 */
  studentClassBaseData: StudentClassBaseData;
  /** 1年生徒 */
  jhs1_students: number | null;

  /** 2年生徒 */
  jhs2_students: number | null;

  /** 3年生徒 */
  jhs3_students: number | null;

  /** 1年学級数 */
  jhs1_classes: number | null;

  /** 2年学級数 */
  jhs2_classes: number | null;

  /** 3年学級数 */
  jhs3_classes: number | null;
};

/** APIリターン情報 */
export type ResultInfo<T> = {
  /** 対象年度 */
  year: number;
  /** ページサイズ（0=全件） */
  page_size: number;
  /** 現在表示ページ */
  current_page: number;
  /** 総件数 */
  total_size: number;
  /** 更新日時（BEは「yyyy/MM/dd HH:mm:ss」形式で返す） */
  update_date: string | null;
  /** 更新者ID */
  update_user_id: string | null;
  /** 更新者名 */
  update_user_nm: string | null;
  /** リスト */
  return_list: T[];
};
