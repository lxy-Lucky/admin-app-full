export type AnbunRequestInfo = {
  /** 対象年度 */
  year: number;
  /** リスト区分（""=自動集計結果リスト、"1"=登録済みリスト） */
  list_flg?: string;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

export type AnbunAutoCalculateList = {
  /** 指定校コード */
  shiteikou_code: string;
  /** 指定校名 */
  shiteikou_nm: string;
  /** 受入校への按分人数（0歳児） */
  anbun_count_age_0: number;
  /** 受入校への按分人数（1歳児） */
  anbun_count_age_1: number;
  /** 受入校への按分人数（2歳児） */
  anbun_count_age_2: number;
  /** 受入校への按分人数（3歳児） */
  anbun_count_age_3: number;
  /** 受入校への按分人数（4歳児） */
  anbun_count_age_4: number;
  /** 受入校への按分人数（5歳児） */
  anbun_count_age_5: number;
  /** 指定校在籍人数合計*/
  total_anbun_count: number;
  /** 受入校コード*/
  ukeirekou_code: string;
  /** 受入校名*/
  ukeirekou_nm: string;
};

/** 按分率リスト取得のレスポンス情報（info）
 *  ※データが無い場合（学籍DB・学区域情報が未登録）はinfo=nullが返る */
export type AnbunListInfo = {
  /** ページサイズ（0=全件） */
  page_size: number;
  /** 現在表示ページ */
  current_page: number;
  /** 総件数 */
  total_size: number;
  /** 按分率リスト */
  return_list: AnbunAutoCalculateList[];
};

/** 按分率登録・実行情報取得のリクエスト情報 */
export type AnbunRegisterReqInfo = {
  /** 対象年度 */
  year: number;
};

/** 按分率登録の実行情報（按分率登録・実行情報取得のレスポンス情報）
 *  ※未登録の場合はinfo=nullが返る */
export type AnbunExecuteInfo = {
  /** 対象年度 */
  year: number;
  /** 更新日時（＝按分率登録日。BEは「yyyy/MM/dd HH:mm:ss」形式で返す） */
  update_date: string;
  /** 更新者ID */
  update_user_id: string;
  /** 更新者名（＝按分率登録者） */
  update_user_nm: string;
};
