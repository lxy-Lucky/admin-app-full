"use client";

import { useEffect, useMemo, useState } from "react";
import { Select, UploadFile } from "antd";
import type { ColumnsType } from "antd/es/table";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import { sorter } from "@/components/Table/utils";
import Button from "@/components/Button/page";
import Dialog from "@/components/Modal/Dialog";
import { CommonResponse, MessageLevel } from "@/constants/common";
import { getAnbunInfo, getAnbunList, listPrint, register } from "@/services/infantRoutineService";
import { usePagination } from "@/components/Table/pagination";
import { getCurrentYear, saveBlobResponse } from "@/utils/common";
import {
  ConditionPanel,
  ExecuteInfoText,
  ExecuteRow,
  PanelHeader,
  PrintBar,
  YearRow,
} from "./styles";
import {
  AnbunAutoCalculateList,
  AnbunExecuteInfo,
  AnbunListInfo,
  AnbunRegisterReqInfo,
  AnbunRequestInfo,
} from "./type";
import { ERROR_MESSAGE } from "@/constants/message";
import CsvImportModal from "@/components/Modal/ImportModal/ImportModal";

// リスト区分（BEへのリクエスト値）
// ※Excel取込で登録する方式のため、一覧は登録済みリストのみ表示する
const LIST_FLG_REGISTERED = "1"; // 登録済みリスト

/** 按分率を小数第3位まで表示する（値が無い場合は空欄） */
const renderAnbunRate = (value: number | null) => (value == null ? "" : value.toFixed(3));

/** 2次集計（特調校按分登録） */
export default function InfantRoutineAnbun() {
  const [year, setYear] = useState<number>(new Date().getFullYear());
  // 按分率リスト。データが無い場合は空配列
  const [anbunList, setAnbunList] = useState<AnbunAutoCalculateList[]>([]);
  // 按分率登録の実行情報（登録日・登録者）。未登録の場合はnull
  const [registerInfo, setRegisterInfo] = useState<AnbunExecuteInfo | null>(null);
  // ファイルアップロード（Excel取込）ダイアログ表示
  const [fileUploadModalOpen, setFileUploadModalOpen] = useState(false);
  // 取込中はダイアログの実行ボタンを非活性にする
  const [isImporting, setIsImporting] = useState(false);

  const [errMsg, setErrMsg] = useState("");
  // 集計未実行など、エラーではないが利用者に対応を促すメッセージ（msg_level=WARN相当）
  const [warnMsg, setWarnMsg] = useState("");
  // 初期表示時に必ず集計実行情報を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(false);

  // 登録完了ダイアログ表示
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  // 集計結果詳細の折りたたみ状態
  const [executeAreaFolded, setExecutedAreaFolded] = useState(true);

  //現在の年度を取得
  const yearOptions = getCurrentYear();

  // ページネーション（BE側でページ分のみ返却されるため、ページ状態をここで管理する）
  const {
    currentPage,
    pageSize,
    totalRecord,
    setCurrentPage,
    setTotalRecord,
    handlePaginationChange,
  } = usePagination({});

  const columns = useMemo<ColumnsType<AnbunAutoCalculateList>>(
    () => [
      {
        title: "指定校名",
        dataIndex: "shiteikou_nm",
        key: "shiteikou_nm",
        width: 160,
        sorter: sorter("shiteikou_nm"),
      },
      {
        title: "学校＃",
        dataIndex: "shiteikou_code",
        key: "shiteikou_code",
        width: 80,
        sorter: sorter("shiteikou_code"),
      },
      {
        title: "0歳",
        dataIndex: "anbun_count_age_0",
        key: "anbun_count_age_0",
        width: 70,
        sorter: sorter("anbun_count_age_0"),
      },
      {
        title: "1歳",
        dataIndex: "anbun_count_age_1",
        key: "anbun_count_age_1",
        width: 70,
        sorter: sorter("anbun_count_age_1"),
      },
      {
        title: "2歳",
        dataIndex: "anbun_count_age_2",
        key: "anbun_count_age_2",
        width: 70,
        sorter: sorter("anbun_count_age_2"),
      },
      {
        title: "3歳",
        dataIndex: "anbun_count_age_3",
        key: "anbun_count_age_3",
        width: 70,
        sorter: sorter("anbun_count_age_3"),
      },
      {
        title: "4歳",
        dataIndex: "anbun_count_age_4",
        key: "anbun_count_age_4",
        width: 70,
        sorter: sorter("anbun_count_age_4"),
      },
      {
        title: "5歳",
        dataIndex: "anbun_count_age_5",
        key: "anbun_count_age_5",
        width: 70,
        sorter: sorter("anbun_count_age_5"),
      },
      {
        title: "合計",
        dataIndex: "total_anbun_count",
        key: "total_anbun_count",
        width: 140,
        sorter: sorter("total_anbun_count"),
      },
      {
        title: "受入校名",
        dataIndex: "ukeirekou_nm",
        key: "ukeirekou_nm",
        width: 160,
        sorter: sorter("ukeirekou_nm"),
      },
      {
        title: "学校＃",
        dataIndex: "ukeirekou_code",
        key: "ukeirekou_code",
        width: 80,
        sorter: sorter("ukeirekou_code"),
      },
    ],
    [year],
  );

  //画面に表示されるメッセージをクリア
  const clearMessage = () => {
    setErrMsg("");
    setWarnMsg("");
  };

  // 按分人数リスト（登録済み）取得
  // ※ローディング開始・メッセージのクリアは呼び出し側で行う
  const fetchList = (page: number, size: number) => {
    const req: AnbunRequestInfo = {
      year: year,
      list_flg: LIST_FLG_REGISTERED,
      current_page: page,
      page_size: size,
    };

    // ※データが無い（按分人数が未登録）場合はWARN（info=null）が返る
    return getAnbunList(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          // データが無い（按分人数が未登録）場合はinfo=null
          const info: AnbunListInfo | null = data.info ?? null;

          setAnbunList(info?.return_list ?? []);
          // 総件数（データ無しの場合は0件）
          setTotalRecord(info?.total_size ?? 0);
          // データ無し（info=null）の場合のみ注意メッセージを表示する
          setWarnMsg(info ? "" : data?.message || ERROR_MESSAGE.ANBURITSU_NOT_EXECUTED_MESSAGE);
        } else {
          // エラー時は前回の一覧・件数を残さない
          setAnbunList([]);
          setTotalRecord(0);
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setAnbunList([]);
        setTotalRecord(0);
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 按分率登録の実行情報（登録日・登録者）取得
  // ※未登録の場合はinfo=null（WARN）が返るため、登録日・登録者を非表示にする（メッセージは表示しない）
  const fetchRegisterInfo = (targetYear: number) => {
    const req: AnbunRegisterReqInfo = {
      year: targetYear,
    };

    getAnbunInfo(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setRegisterInfo(data.info ?? null);
        } else {
          setRegisterInfo(null);
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setRegisterInfo(null);
        setErrMsg(err.message);
      });
  };

  // テーブル表示用データ（行キーを付与）
  const tableData = useMemo(
    () =>
      anbunList.map((item, index) => ({
        ...item,
        rowKey: index,
      })),
    [anbunList],
  );

  // 初期表示および年度の変更時に按分人数リストを取得する
  // （メッセージのクリア・ローディング開始は各イベントハンドラで行うため、ここでは取得のみを行う）
  useEffect(() => {
    fetchList(currentPage, pageSize);
    // ページの変更はonPaginationChangeで取得するため、ここでは年度の変更時のみ実行する
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year]);

  // 初期表示および年度変更時に按分率登録の実行情報を取得する
  useEffect(() => {
    fetchRegisterInfo(year);
  }, [year]);

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    clearMessage();
    setIsLoading(true);
    // 年度が変わると件数も変わるため、1ページ目から表示し直す
    setCurrentPage(1);
    setYear(value);
  };

  // ページ番号・ページサイズ変更時はBEから該当ページを取得し直す
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      clearMessage();
      setIsLoading(true);
      fetchList(nextPage, nextSize);
    });
  };

  // 按分率登録（Excel取込ダイアログの「実行」ボタン）
  const onImport = (file: UploadFile) => {
    // 前回取込失敗時のエラーメッセージが残っていればクリアする
    clearMessage();
    setIsImporting(true);
    setIsLoading(true);

    const req: AnbunRegisterReqInfo = {
      year: year,
    };

    // multipart/form-data形式でJSONデータ(data)とExcelファイル(file)を送信する
    const formData = new FormData();
    formData.append("data", new Blob([JSON.stringify(req)], { type: "application/json" }));
    formData.append("file", file.originFileObj!);

    register(formData)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO) {
          // 登録成功。レスポンスの実行情報で登録日・登録者を更新する
          // （一覧は完了ダイアログを閉じた後に取得し直す）
          setRegisterInfo(data.info ?? null);
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else {
          // シート不正・入力値不正・学校マスタ未登録などの理由はBEのメッセージそのままで表示する
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsImporting(false);
        setIsLoading(false);
        setFileUploadModalOpen(false);
      });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    //按分率リスト取得
    clearMessage();
    setIsLoading(true);
    fetchList(currentPage, pageSize);
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ConditionPanel>
            <PanelHeader onClick={() => setExecutedAreaFolded((prev) => !prev)}>
              <span>{executeAreaFolded ? "▼" : "▲"}</span>
              <span>集計結果詳細</span>
            </PanelHeader>

            {!executeAreaFolded && (
              <div>
                <YearRow>
                  <Select
                    style={{ width: 120 }}
                    placeholder="年を選択してください"
                    options={yearOptions}
                    value={year}
                    onChange={onChangeYear}
                  />
                  <span>年度</span>
                </YearRow>

                <ExecuteRow>
                  {/* Excel取込ダイアログを開く（取込ファイルの内容で登録する） */}
                  <Button
                    type="primary"
                    onClick={() => setFileUploadModalOpen(true)}
                    disabled={isLoading}
                  >
                    按分登録
                  </Button>

                  {/* 按分率登録済みの場合のみ、登録日・登録者を表示する */}
                  {registerInfo && (
                    <ExecuteInfoText>
                      {/* BEは「yyyy/MM/dd HH:mm:ss」形式で返すため、時分秒までそのまま表示する */}
                      <span>登録日：{registerInfo.update_date}</span>
                      <span>登録者：{registerInfo.update_user_nm}</span>
                    </ExecuteInfoText>
                  )}
                </ExecuteRow>
              </div>
            )}
          </ConditionPanel>
        }
        errorMessage={errMsg}
        warnMessage={warnMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={tableData}
          rowKey="rowKey"
          pagination
          stickyHeader
          loading={isLoading}
          size="middle"
          current={currentPage}
          pageSize={pageSize}
          total={totalRecord}
          onPaginationChange={onPaginationChange}
        />
      </ListPageLayout>

      {/* 按分率登録（Excel取込）ダイアログ */}
      <CsvImportModal
        open={fileUploadModalOpen}
        accept=".xlsx,.xlsm"
        onClose={() => setFileUploadModalOpen(false)}
        onImport={onImport}
        inOperation={isImporting}
      >
        <p>
          【{year}年度】の【実績入力表】
          <br />
          を選択してください
          <br />
          ※「実績入力表」シートは1シートのみとしてください
        </p>
      </CsvImportModal>

      {/* 登録完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
