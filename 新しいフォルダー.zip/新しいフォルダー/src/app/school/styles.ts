import styled from "styled-components";

// 現在の検索年度表示＋データ作成ボタンの行（検索条件パネルと一覧の間）
export const DataCreateBar = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin-top: 12px;
`;

// 現在の検索年度表示（YearBadge）のスタイル
export const YearBadge = styled.span`
  display: inline-block;
  min-width: 100px;
  padding: 6px 12px;
  border: 1px solid ${(props) => props.theme.colors.light_gray5};
  border-radius: 4px;
  background: ${(props) => props.theme.colors.absolute_white};
  font-size: ${(props) => props.theme.fontSizes.base};
  color: ${(props) => props.theme.colors.absolute_black};
`;
