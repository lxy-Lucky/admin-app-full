"use client";

import { ReactNode, useEffect, useMemo, useState } from "react";
import type { ColumnsType } from "antd/es/table";
import type { UploadFile } from "antd";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import { sorter } from "@/components/Table/utils";
import { usePagination } from "@/components/Table/pagination";
import SearchForm from "@/components/SearchForm/page";
import { SearchFieldConfig } from "@/components/SearchForm/type";
import Button from "@/components/Button/page";
import CsvImportModal from "@/components/Modal/ImportModal/ImportModal";
import Dialog from "@/components/Modal/Dialog";
import { CheckBox } from "@/app/styles";
import { CommonResponse, MessageLevel } from "@/constants/common";
import { excelImport, list as listSchools } from "@/services/schoolService";
import { list as listWards } from "@/services/wardService";
import { getCurrentYear } from "@/utils/common";
import { DataCreateBar, YearBadge } from "./styles";
import {
  SCHOOL_KBN,
  SchoolImportResultInfo,
  SchoolInfo,
  SchoolListReqInfo,
  SchoolSearchFormValues,
  SORT_TYPE,
  WardInfo,
} from "./type";

// 学校一覧ページのコンポーネント
const SCHOOL_KBN_LABEL: Record<string, string> = {
  [SCHOOL_KBN.ELEMENTARY]: "小学校",
  [SCHOOL_KBN.JUNIOR_HIGH]: "中学校",
};

// 学校一覧ページのメインコンポーネント
export default function SchoolListPage() {
  const currentYear = new Date().getFullYear();

  const [schools, setSchools] = useState<SchoolInfo[]>([]);
  const [wardOptions, setWardOptions] = useState<{ value: string; label: string }[]>([]);
  const [errMsg, setErrMsg] = useState("");
  // 初期表示時に必ず一覧を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(true);
  // 直近の検索で使われた年度（一覧上部に表示する）
  const [searchedYear, setSearchedYear] = useState(currentYear);
  // データ取込（Excel取込）用ダイアログの開閉状態
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  // 取込完了報告ダイアログ
  const [completeMsg, setCompleteMsg] = useState<ReactNode>("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  // ページネーション（一覧は全件取得しているため、ページ切替は画面側のみで行いAPIは呼ばない）
  const { currentPage, pageSize, setCurrentPage, handlePaginationChange } = usePagination({
    initialPage: 1,
    initialPageSize: 1000,
  });

  const columns: ColumnsType<SchoolInfo> = [
    {
      title: "区分",
      dataIndex: "school_kbn",
      key: "school_kbn",
      width: 90,
      sorter: sorter(SORT_TYPE.SCHOOL_KBN),
      render: (value: string) => SCHOOL_KBN_LABEL[value] ?? value,
    },
    {
      title: "区#",
      dataIndex: "ward_code",
      key: "ward_code",
      width: 80,
      sorter: sorter(SORT_TYPE.WARD_CODE),
    },
    {
      title: "区名",
      dataIndex: "ward_nm",
      key: "ward_nm",
      width: 100,
      sorter: sorter(SORT_TYPE.WARD_NM),
    },
    {
      title: "学校名フリガナ",
      dataIndex: "school_nm_kana",
      key: "school_nm_kana",
      width: 160,
      sorter: sorter(SORT_TYPE.SCHOOL_NM_KANA),
    },
    {
      title: "学校名",
      dataIndex: "school_nm",
      key: "school_nm",
      width: 160,
      sorter: sorter(SORT_TYPE.SCHOOL_NM),
    },
    {
      title: "調査#",
      dataIndex: "school_code_pre",
      key: "school_code_pre",
      width: 120,
      sorter: sorter(SORT_TYPE.SCHOOL_CODE_PRE),
    },
    {
      title: "JJ#",
      dataIndex: "school_code_city",
      key: "school_code_city",
      width: 120,
      sorter: sorter(SORT_TYPE.SCHOOL_CODE_CITY),
    },
    {
      title: "学校(国#)",
      dataIndex: "school_code_gov",
      key: "school_code_gov",
      width: 140,
      sorter: sorter(SORT_TYPE.SCHOOL_CODE_GOV),
    },
    {
      title: "電話番号",
      dataIndex: "tel",
      key: "tel",
      width: 120,
      sorter: sorter(SORT_TYPE.TEL),
    },
    {
      title: "所在地",
      dataIndex: "address",
      key: "address",
      width: 200,
      sorter: sorter(SORT_TYPE.ADDRESS),
    },
    {
      title: "備考",
      dataIndex: "note",
      key: "note",
      width: 200,
      sorter: sorter(SORT_TYPE.NOTE),
    },
    {
      title: "廃止",
      dataIndex: "close_flg",
      key: "close_flg",
      width: 80,
      sorter: sorter(SORT_TYPE.CLOSE_FLG),
      render: (value: string, record) => (
        <CheckBox
          id={`close_flg_${record.school_code_id}`}
          type="checkbox"
          checked={value === "1"}
          disabled
        />
      ),
    },
  ];

  // 学校コード一覧取得
  const fetchSchools = (req: SchoolListReqInfo) => {
    listSchools(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setSchools(data.info?.return_list ?? []);
          // 再取得時は1ページ目から表示する
          setCurrentPage(1);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // データ取込（Excel取込）ボタン押下時の処理
  const onImport = (file: UploadFile) => {
    setImportDialogOpen(false);
    // 前回取込失敗時のエラーメッセージが残っていればクリアする
    setErrMsg("");

    // multipart/form-data形式でJSONデータ(data)とExcelファイル(file)を送信する
    const formData = new FormData();
    formData.append(
      "data",
      new Blob(
        [
          JSON.stringify({
            year: searchedYear,
          }),
        ],
        { type: "application/json" },
      ),
    );
    formData.append("file", file.originFileObj!);

    excelImport(formData)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          const result: SchoolImportResultInfo = data.info ?? {};
          // 小学校・中学校の取込件数を合算して1件数として表示する
          const insertCount = (result.insert_count_elem ?? 0) + (result.insert_count_junior ?? 0);

          setCompleteMsg(
            <>
              取り込みが完了しました
              <br />
              取り込み件数：{insertCount}件
            </>,
          );
          setCompleteDialogOpen(true);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      });
  };

  // 取込完了報告ダイアログを閉じる
  const closeCompleteDialog = () => {
    setCompleteDialogOpen(false);
    // 取込結果を反映するため、現在表示中の年度で再取得する
    // （取込前に表示されたままのエラーメッセージもここでクリアする）
    setErrMsg("");
    setIsLoading(true);
    fetchSchools({
      year: searchedYear,
      page_size: 0,
      current_page: 1,
    });
  };

  useEffect(() => {
    // 区マスタ取得（検索条件「区」のチェックボックス選択肢）
    listWards()
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          const wards: WardInfo[] = data.info?.return_list ?? [];
          setWardOptions(
            wards.map((ward) => ({
              value: ward.ward_code,
              label: ward.ward_nm,
            })),
          );
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      });

    // 初期表示：デフォルト年度・条件無しで取得
    fetchSchools({
      year: currentYear,
      page_size: 0,
      current_page: 1,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const searchFields: SearchFieldConfig[] = useMemo(
    () => [
      {
        name: "year",
        label: "年度",
        kind: "select",
        options: getCurrentYear(),
        width: 120,
      },
      {
        name: "school_kbn",
        label: "学校区分",
        kind: "radio",
        options: [
          { value: "", label: "すべて" },
          { value: SCHOOL_KBN.ELEMENTARY, label: "小学校" },
          { value: SCHOOL_KBN.JUNIOR_HIGH, label: "中学校" },
        ],
      },
      {
        name: "ward_codes",
        label: "区",
        kind: "checkboxGroup",
        options: wardOptions,
        width: "100%",
      },
      {
        name: "school_nm_kana",
        label: "学校名（フリガナ）",
        kind: "text",
      },
      {
        name: "close_flg_only",
        label: "廃止のみ表示",
        kind: "checkbox",
      },
    ],
    [wardOptions],
  );

  // 検索フォームの初期値
  const defaultSearchValues: SchoolSearchFormValues = {
    year: currentYear,
    school_kbn: "",
    ward_codes: [],
    school_nm_kana: "",
    close_flg_only: false,
  };

  // 検索フォームの検索実行時の処理
  const onSearch = (values: SchoolSearchFormValues) => {
    const req: SchoolListReqInfo = {
      year: values.year,
      arr_ward_code: values.ward_codes?.length ? values.ward_codes : undefined,
      school_kbn: values.school_kbn || undefined,
      school_nm_kana: values.school_nm_kana || undefined,
      close_flg: values.close_flg_only ? "1" : undefined,
      page_size: 0,
      current_page: 1,
    };
    setSearchedYear(values.year);
    // 前回検索・前回取込等で表示されたままのエラーメッセージをクリアする
    setErrMsg("");
    setIsLoading(true);
    fetchSchools(req);
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <>
            <SearchForm<SchoolSearchFormValues>
              fields={searchFields}
              defaultValues={defaultSearchValues}
              onSearch={onSearch}
            />
            <DataCreateBar>
              <YearBadge>{searchedYear}年度</YearBadge>
              <Button
                type="primary"
                onClick={() => {
                  setImportDialogOpen(true);
                }}
              >
                データ取込
              </Button>
            </DataCreateBar>
          </>
        }
        errorMessage={errMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={schools}
          rowKey="school_code_id"
          pagination
          stickyHeader
          loading={isLoading}
          size="small"
          current={currentPage}
          pageSize={pageSize}
          total={schools.length}
          onPaginationChange={handlePaginationChange}
        />
      </ListPageLayout>

      {/* データ取込（Excel取込）ダイアログ */}
      <CsvImportModal
        open={importDialogOpen}
        onClose={() => setImportDialogOpen(false)}
        onImport={onImport}
        accept=".xlsx"
      >
        <p>
          Excelファイルを取り込んで作成
          <br />
          ※作成済みデータは削除されます。
        </p>
        <br />
      </CsvImportModal>

      {/* 取込完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeCompleteDialog} confirmText="OK">
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
