// 学校コード一覧 1件分
export type SchoolInfo = {
  school_code_id?: string;
  year?: number;
  ward_code?: string;
  ward_nm?: string;
  ward_nm_kana?: string;
  school_kbn?: string; // 1=小学校、5=中学校
  school_nm?: string;
  school_nm_kana?: string;
  school_code_pre?: string; // 学校コード（神奈川県）
  school_code_city?: string; // 学校コード（横浜市教育委員会）
  school_code_gov?: string; // 学校コード（国指定）
  tel?: string;
  address?: string;
  note?: string;
  close_flg?: string; // 1=廃止
  update_user_id?: string;
  update_user_nm?: string;
  update_date?: string;
};

// 学校コード一覧 検索リクエスト
export type SchoolListReqInfo = {
  year: number;
  arr_ward_code?: string[];
  school_kbn?: string;
  school_nm?: string;
  school_nm_kana?: string;
  close_flg?: string;
  page_size: number;
  current_page: number;
};

// 学校コード対応表（Excel）取込 リクエスト
export type SchoolImportReqInfo = {
  year: number;
};

// 学校コード対応表（Excel）取込 レスポンス
export type SchoolImportResultInfo = {
  insert_count_elem?: number; // 取込データ件数（小学校）
  insert_count_junior?: number; // 取込データ件数（中学校）
};

// 区マスタ 1件分
export type WardInfo = {
  ward_code: string;
  ward_nm: string;
  ward_nm_kana: string;
};

// 検索フォーム入力値
export type SchoolSearchFormValues = {
  year: number;
  school_kbn: string;
  ward_codes: string[];
  school_nm_kana: string;
  close_flg_only: boolean;
};

// ソートタイプ一覧
export enum SORT_TYPE {
  SCHOOL_KBN = "school_kbn",
  WARD_CODE = "ward_code",
  WARD_NM = "ward_nm",
  SCHOOL_NM_KANA = "school_nm_kana",
  SCHOOL_NM = "school_nm",
  SCHOOL_CODE_PRE = "school_code_pre",
  SCHOOL_CODE_CITY = "school_code_city",
  SCHOOL_CODE_GOV = "school_code_gov",
  TEL = "tel",
  ADDRESS = "address",
  NOTE = "note",
  CLOSE_FLG = "close_flg",
}

export const SCHOOL_KBN = {
  ELEMENTARY: "1",
  JUNIOR_HIGH: "5",
} as const;
