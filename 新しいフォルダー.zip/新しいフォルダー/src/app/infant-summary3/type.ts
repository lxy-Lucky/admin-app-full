export type reqInfo = {
  /** 対象年度 */
  year: number;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

export type summary_3_Detail = {
  /** 学校名 */
  school_nm: string;
  /** 学校コード */
  school_code: number;

  /** 0歳児人数 */
  count_age_0: string;
  /** 1歳児人数 */
  count_age_1: string;
  /** 2歳児人数 */
  count_age_2: string;
  /** 3歳児人数*/
  count_age_3: string;
  /** 4歳児人数*/
  count_age_4: string;
  /** 5歳児人数*/
  count_age_5: string;
};

export type summary_3_ExecuteInfo = {
  /** 更新日付（＝集計実行日） */
  update_date: string;
  /** 更新者ID */
  update_user_id: string;
  /** 更新者名（＝集計実行者） */
  update_user_nm: string;

  return_list: summary_3_Detail[];
  /** ページサイズ */
  page_size: number;
  /** 現在表示ページ */
  current_page: number;
  /** 総件数（全ページ分） */
  total_size: number;
};
