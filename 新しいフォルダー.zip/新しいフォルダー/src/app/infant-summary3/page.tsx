"use client";

import { useEffect, useMemo, useState } from "react";
import { Select } from "antd";
import type { ColumnsType } from "antd/es/table";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import { sorter } from "@/components/Table/utils";
import Button from "@/components/Button/page";
import Dialog from "@/components/Modal/Dialog";
import { CommonResponse, CONFIRM_MESSAGE, MessageLevel } from "@/constants/common";
import { execute, executeInfo, listPrint } from "@/services/infant-summary3Service";
import { usePagination } from "@/components/Table/pagination";
import { getCurrentYear, saveBlobResponse } from "@/utils/common";
import {
  ConditionPanel,
  ExecuteInfoText,
  ExecuteRow,
  PanelHeader,
  PrintBar,
  YearRow,
} from "./styles";
import { summary_3_Detail, summary_3_ExecuteInfo, reqInfo } from "./type";
import { ERROR_MESSAGE } from "@/constants/message";

// 人数がマイナスのセルは赤背景で表示する
// （常態化地区按分の人数が、2次集計後の指定校の人数より多い場合に発生する）
const minusCountCell = (key: keyof summary_3_Detail) => (record: summary_3_Detail) => ({
  className: Number(record[key]) < 0 ? "minus-count-cell" : "",
});

/** 3次集計実行 */
export default function InfantSummary3() {
  const [year, setYear] = useState<number>(new Date().getFullYear());
  // 集計実行情報（集計実行日・集計実行者）。未集計の場合はnull
  const [s3Info, setS3Info] = useState<summary_3_ExecuteInfo | null>(null);

  const [errMsg, setErrMsg] = useState("");
  // 集計未実行など、エラーではないが利用者に対応を促すメッセージ（msg_level=WARN相当）
  const [warnMsg, setWarnMsg] = useState("");
  // 初期表示時に必ず集計実行情報を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(false);

  // 実行完了ダイアログ表示
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  const [exeConfirmDialogOpen, setExeConfirmDialogOpen] = useState(false);

  // 集計結果詳細の折りたたみ状態
  const [executeAreaFolded, setExecutedAreaFolded] = useState(true);

  const yearOptions = getCurrentYear();

  // ページネーション（BE側でページ分のみ返却されるため、ページ状態をここで管理する）
  const {
    currentPage,
    pageSize,
    totalRecord,
    setCurrentPage,
    setTotalRecord,
    handlePaginationChange,
  } = usePagination({});

  const columns = useMemo<ColumnsType<summary_3_Detail>>(
    () => [
      {
        title: "学校名",
        dataIndex: "school_nm",
        key: "school_nm",
        width: 160,
        sorter: sorter("school_nm"),
      },
      {
        title: "学校コード",
        dataIndex: "school_code",
        key: "school_code",
        width: 80,
        sorter: sorter("school_code"),
      },
      {
        title: "0歳児人数",
        dataIndex: "count_age_0",
        key: "count_age_0",
        width: 180,
        sorter: sorter("count_age_0"),
        onCell: minusCountCell("count_age_0"),
      },
      {
        title: "1歳児人数",
        dataIndex: "count_age_1",
        key: "count_age_1",
        width: 140,
        sorter: sorter("count_age_1"),
        onCell: minusCountCell("count_age_1"),
      },
      {
        title: "2歳児人数",
        dataIndex: "count_age_2",
        key: "count_age_2",
        width: 140,
        sorter: sorter("count_age_2"),
        onCell: minusCountCell("count_age_2"),
      },
      {
        title: "3歳児人数",
        dataIndex: "count_age_3",
        key: "count_age_3",
        width: 140,
        sorter: sorter("count_age_3"),
        onCell: minusCountCell("count_age_3"),
      },
      {
        title: "4歳児人数",
        dataIndex: "count_age_4",
        key: "count_age_4",
        width: 140,
        sorter: sorter("count_age_4"),
        onCell: minusCountCell("count_age_4"),
      },
      {
        title: "5歳児人数",
        dataIndex: "count_age_5",
        key: "count_age_5",
        width: 140,
        sorter: sorter("count_age_5"),
        onCell: minusCountCell("count_age_5"),
      },
    ],
    [],
  );

  const fetchExecuteInfo = (page: number, size: number) => {
    clearMessage();
    const req: reqInfo = {
      year: year,
      current_page: page,
      page_size: size,
    };

    return executeInfo(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          const info: summary_3_ExecuteInfo | null = data.info ?? null;

          const infoList: summary_3_Detail[] = data.info?.return_list ?? [];
          const tableData = infoList.map((item, index) => ({
            ...item,
            rowKey: index,
          }));

          setS3Info(info);

          // 全ページ分の総件数（未集計の場合は0件）
          setTotalRecord(info?.total_size ?? 0);
          // 未集計（info=null）の場合のみ注意メッセージを表示する
          setWarnMsg(info ? "" : data?.message || ERROR_MESSAGE.NOT_EXECUTED_MESSAGE);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  const tableData = useMemo(
    () =>
      (s3Info?.return_list ?? []).map((item, index) => ({
        ...item,
        rowKey: index,
      })),
    [s3Info],
  );

  // 初期表示および年度変更時に集計実行情報を取得する
  // （初期表示時点でisLoading=true・メッセージ無しのため、ここでは取得のみを行う）
  useEffect(() => {
    fetchExecuteInfo(currentPage, pageSize);
  }, [year]);

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    clearMessage();
    setIsLoading(true);
    // 年度が変わると件数も変わるため、1ページ目から表示し直す
    setCurrentPage(1);
    setYear(value);
  };

  // ページ番号・ページサイズ変更時はBEから該当ページを取得し直す
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      setErrMsg("");

      setIsLoading(true);
      fetchExecuteInfo(nextPage, nextSize);
    });
  };

  // 印刷ボタン
  const onPrint = () => {
    clearMessage();
    setIsLoading(true);

    const req: reqInfo = {
      year: year,
    };

    listPrint(req)
      .then(async (res) => {
        // ファイルを受け取れなかった場合は理由がメッセージとして返るため、エラー表示する
        // ファイル名は基本的にBEのレスポンスヘッダーのものを使う（取得できない場合のみ第2引数の名前）
        const failedMsg = await saveBlobResponse(res, `${year}年度_幼児数3次集計.xlsx`);

        if (failedMsg) {
          setErrMsg(failedMsg);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 3次集計実行
  const onExecute = () => {
    setExeConfirmDialogOpen(false);

    // 集計中の二重実行防止（集計完了まで実行ボタン・印刷ボタンを押せないようにする）
    if (isLoading) {
      return;
    }
    setIsLoading(true);

    // 前回取込失敗時のエラーメッセージが残っていればクリアする
    clearMessage();

    const req: reqInfo = {
      year: year,
    };

    execute(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO) {
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    //データリスト取得
    fetchExecuteInfo(currentPage, pageSize);
  };

  //画面に表示されるメッセージをクリア
  const clearMessage = () => {
    setErrMsg("");
    setWarnMsg("");
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ConditionPanel>
            <PanelHeader onClick={() => setExecutedAreaFolded((prev) => !prev)}>
              <span>{executeAreaFolded ? "▼" : "▲"}</span>
              <span>集計結果詳細</span>
            </PanelHeader>
            {!executeAreaFolded && (
              <div>
                <YearRow>
                  <Select
                    style={{ width: 120 }}
                    placeholder="年を選択してください"
                    options={yearOptions}
                    value={year}
                    onChange={onChangeYear}
                  />
                  <span>年度</span>
                </YearRow>

                <ExecuteRow>
                  <Button
                    type="primary"
                    onClick={() => setExeConfirmDialogOpen(true)}
                    disabled={isLoading}
                  >
                    3次集計実行
                  </Button>

                  {/* 集計済みの場合のみ、集計実行日・集計実行者を表示する */}
                  {s3Info && (
                    <ExecuteInfoText>
                      {/* BEは「yyyy/MM/dd HH:mm:ss」形式で返すため、時分秒までそのまま表示する */}
                      <span>集計実行日：{s3Info.update_date}</span>
                      <span>集計実行者：{s3Info.update_user_nm}</span>
                    </ExecuteInfoText>
                  )}
                </ExecuteRow>
              </div>
            )}

            <PrintBar>
              {/* 集計結果が無い状態では出力対象が無いため押せないようにする */}
              <Button
                type="primary"
                onClick={onPrint}
                disabled={isLoading || tableData.length === 0}
              >
                印刷
              </Button>
            </PrintBar>
          </ConditionPanel>
        }
        errorMessage={errMsg}
        warnMessage={warnMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={tableData}
          rowKey="rowKey"
          pagination
          stickyHeader
          loading={isLoading}
          size="middle"
          current={currentPage}
          pageSize={pageSize}
          total={totalRecord}
          onPaginationChange={onPaginationChange}
        />
      </ListPageLayout>

      {/* 実行前に確認ダイアログ */}
      <Dialog
        mode="import"
        open={exeConfirmDialogOpen}
        onClose={() => setExeConfirmDialogOpen(false)}
        onConfirm={onExecute}
        confirmText="実行"
        showCancel={true}
      >
        <p>{CONFIRM_MESSAGE.EXECUTE_MSG}</p>
      </Dialog>

      {/* 登録完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
