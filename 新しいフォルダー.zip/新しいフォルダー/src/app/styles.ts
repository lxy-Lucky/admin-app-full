import styled from "styled-components";

export const LoginWrapper = styled.div`
  width: 100%;
  min-height: 100vh;
  background-color: ${(props) => props.theme.colors.light_gray2};
  & .ant-card-body {
    & > div:first-child {
      & > div:first-child {
        img {
          width: 60px !important;
          height: 60px !important;
        }
      }
      & > div:nth-child(2) {
        img {
          width: 12px !important;
          height: 45px !important;
        }
      }
    }
  }
`;

export const Form = styled.div`
  color: ${(props) => props.theme.colors.absolute_black};
  --color--highlight: ${(props) => props.theme.colors.strong_blue1};
  max-width: 500px;
  width: 100%;
  margin: auto;
  margin: 0;
  background: ${(props) => props.theme.colors.light_gray1};
  position: absolute;
  top: 50%;
  left: 50%;
  user-select: auto;
  -ms-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -webkit-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);

  .ant-card-body {
    padding: 15px !important;
  }

  form {
    padding: 0 40px;
    margin-top: 10px;
    margin-bottom: 40px;
  }

  .text-medium {
    font-weight: ${(props) => props.theme.fontWeights.bold};
  }
  .text-guide {
    font-size: ${(props) => props.theme.fontSizes.small};
    color: ${(props) => props.theme.colors.strong_blue1};
    cursor: pointer;
    position: relative;
    &:hover .modal-container {
      display: block;
    }
  }
  .font-size-base {
    font-size: ${(props) => props.theme.fontSizes.base};
  }
  .center {
    justify-content: center;
  }
  .login {
    margin: 20px 0px;
    height: 55px;
    h3 {
      font-size: ${(props) => props.theme.fontSizes.gigantic};
      font-weight: ${(props) => props.theme.fontWeights.bold};
      text-align: center;
      color: ${(props) => props.theme.colors.strong_blue1};
      justify-content: center;
    }
    span {
      display: block;
      font-size: ${(props) => props.theme.fontSizes.base};
      text-align: center;
      text-align: center;
    }
  }
  .error-div {
    padding: 15px 0px;
  }
  .mess-error {
    margin-left: 5px;
  }
  .footer {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    bottom: -50px;
    .blue {
      color: ${(props) => props.theme.colors.strong_blue1};
    }
  }
`;

export const FormItem = styled.div`
  margin-bottom: 30px;
  position: relative;
  input {
    height: 55px;
    font-size: ${(props) => props.theme.fontSizes.semi_large};
    width: 100%;
    border: 2px solid transparent;
    border-radius: 5px;
    background: ${(props) => props.theme.colors.light_gray2};
    padding: 10px 50px 13px 10px;
    margin: 5px 0 0;
    box-sizing: border-box;
    &:hover,
    &:focus {
      border: 2px solid ${(props) => props.theme.colors.strong_blue2};
      outline: none !important;
    }

    &:disabled {
      border-color: ${(props) => props.theme.colors.light_gray4} !important;
    }
  }

  label {
    margin: 10px 8px 0 12px;
    width: max-content;
    align-self: flex-end;
  }
  span {
    flex: 1;

    &.note {
      flex: unset;
      font-size: ${(props) => props.theme.fontSizes.small};
    }
  }
  .show-password {
    position: absolute;
    right: 10px;
    bottom: 18%;
    cursor: pointer;
  }
`;

export const LoginButtonWrapper = styled.div`
  width: 100%;
  height: 55px;
  text-align: center;

  .login-button {
    width: 100%;
    height: 100%;
    font-size: ${(props) => props.theme.fontSizes.semi_large};
  }
`;

export const CheckBox = styled.input`
  appearance: none;
  width: 20px;
  height: 20px;
  padding: 0px !important;
  border: 2px solid ${(props) => props.theme.colors.light_gray4};
  //border-radius: 3px;
  background-color: ${(props) => props.theme.colors.absolute_white};
  position: relative;

  &:checked::after {
    content: "✓";
    position: absolute;
    transform: translate(-50%, -50%);
    color: ${(props) => props.theme.colors.strong_blue2};
    font-weight: bold;
    left: 50%;
    top: 50%;
  }
`;

export const TableWrapper = styled.div`
  margin-top: 20px;
`;

export const ButtonWrapper = styled.div`
  text-align: right;
`;

export const ContentWrapper = styled.div`
  width: 80%;
`;
