"use client";
import AppLayout from "@/components/AppLayout/page";
import { TableWrapper } from "../styles";
import { Button, Select, Spin, UploadFile } from "antd";
import CustomTable from "@/components/Table/page";
import { useEffect, useState, useMemo } from "react";
import { getCurrentYear } from "@/utils/common";
import Table, { ColumnsType } from "antd/es/table";
import { FormDatas, SchoolAreaInfo, SchoolAreaInfoReqInfo, SORT_TYPE } from "./type";
import { sorter } from "@/components/Table/utils";
import { useForm } from "react-hook-form";
import { CommonResponse, MessageLevel } from "@/constants/common";
import { ROUTES } from "@/constants/routes";
import { excelImport, list } from "@/services/schoolAreaInfoService";
import CsvImportModal from "@/components/Modal/ImportModal/ImportModal";
import Dialog from "@/components/Modal/Dialog";
import { useRouter } from "next/navigation";
import { ButtonWrapper, ContentWrapper } from "./styles";
import ListPageLayout from "@/components/ListPageLayout/page";
import { usePagination } from "@/components/Table/pagination";

export default function adjustCodeList() {
  const router = useRouter();
  const [schoolAreaInfo, setSchoolAreaInfo] = useState<SchoolAreaInfo[]>([]);
  const [errMsg, setErrMsg] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  const [year, setYear] = useState<number>(new Date().getFullYear());

  const yearOptions = getCurrentYear();

  //ページネーション
  const { currentPage, pageSize, totalRecord, setTotalRecord, handlePaginationChange } =
    usePagination({
      initialPage: 1,
      initialPageSize: 1000,
    });

  // ページネーションが変わる度ににAPIコール
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      getList(nextSize, nextPage);
    });
  };

  const columns = useMemo<ColumnsType<SchoolAreaInfo>>(
    () => [
      {
        title: "区#",
        dataIndex: "ward_code",
        key: "ward_code",
        sorter: sorter(SORT_TYPE.WARD_CODE),
      },

      {
        title: "町#",
        dataIndex: "town_code",
        key: "town_code",
        sorter: sorter(SORT_TYPE.TOWN_CODE),
      },

      {
        title: "字#",
        dataIndex: "aza_code",
        key: "aza_code",
        sorter: sorter(SORT_TYPE.AZA_CODE),
      },

      {
        title: "番地#FROM",
        dataIndex: "banchi_code_from_1",
        key: "banchi_code_from_1",
        sorter: sorter(SORT_TYPE.BANCHI_CODE_FROM_1),
      },

      {
        title: "",
        dataIndex: "banchi_code_from_2",
        key: "banchi_code_from_2",
        //sorter: sorter(SORT_TYPE.BANCHI_CODE_FROM_2),
      },
      {
        title: "",
        dataIndex: "banchi_code_from_3",
        key: "banchi_code_from_3",
        //sorter: sorter(SORT_TYPE.BANCHI_CODE_FROM_3),
      },
      {
        title: "",
        dataIndex: "banchi_code_from_4",
        key: "banchi_code_from_4",
        //sorter: sorter(SORT_TYPE.BANCHI_CODE_FROM_4),
      },
      {
        title: "番地#To",
        dataIndex: "banchi_code_to_1",
        key: "banchi_code_to_1",
        sorter: sorter(SORT_TYPE.BANCHI_CODE_TO_1),
      },
      {
        title: "",
        dataIndex: "banchi_code_to_2",
        key: "banchi_code_to_2",
        //sorter: sorter(SORT_TYPE.BANCHI_CODE_TO_2),
      },
      {
        title: "",
        dataIndex: "banchi_code_to_3",
        key: "banchi_code_to_3",
        //sorter: sorter(SORT_TYPE.BANCHI_CODE_TO_3),
      },
      {
        title: "",
        dataIndex: "banchi_code_to_4",
        key: "banchi_code_to_4",
        //sorter: sorter(SORT_TYPE.BANCHI_CODE_TO_4),
      },
      {
        title: "指定校#①",
        dataIndex: "shiteikou_code_1",
        key: "shiteikou_code_1",
        sorter: sorter(SORT_TYPE.SHITEIKOU_CODE_1),
      },
      {
        title: "指定校#②",
        dataIndex: "shiteikou_code_2",
        key: "shiteikou_code_2",
        sorter: sorter(SORT_TYPE.SHITEIKOU_CODE_2),
      },
      /*
      {
        title: "指定校コード③",
        dataIndex: "shiteikou_code_3",
        key: "shiteikou_code_3",
        sorter: sorter(SORT_TYPE.SHITEIKOU_CODE_3),
      },
      */
      {
        title: "特調区分",
        dataIndex: "tokucho_kbn",
        key: "tokucho_kbn",
        sorter: sorter(SORT_TYPE.TOKUCHO_KBN),
      },
      {
        title: "特調校#①",
        dataIndex: "tokucho_kou_code_1",
        key: "tokucho_kou_code_1",
        sorter: sorter(SORT_TYPE.TOKUCHO_KOU_CODE_1),
      },
      {
        title: "特調校#②",
        dataIndex: "tokucho_kou_code_2",
        key: "tokucho_kou_code_2",
        sorter: sorter(SORT_TYPE.TOKUCHO_KOU_CODE_2),
      },
    ],
    [],
  );

  const {
    formState: { errors },
  } = useForm<FormDatas>({
    //mode: 'onSubmit',
    shouldFocusError: true,
    reValidateMode: "onSubmit",
  });

  const tableData = useMemo(
    () =>
      schoolAreaInfo.map((item, index) => ({
        ...item,
        rowKey: index,
      })),
    [schoolAreaInfo],
  );

  //リスト取得
  useEffect(() => {
    //住基データリスト取得
    getList(pageSize, currentPage);
  }, [year]);

  const getList = (size: number, page: number) => {
    if (year === undefined) {
      return;
    }

    setIsLoading(true);
    const req: SchoolAreaInfoReqInfo = {
      year: year,
      page_size: size,
      current_page: page,
    };

    list(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          //キー追加
          const infoList: SchoolAreaInfo[] = data.info?.return_list ?? [];
          const tableData = infoList.map((item, index) => ({
            ...item,
            rowKey: index,
          }));

          setSchoolAreaInfo(tableData);
          setTotalRecord(data.info?.total_size);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        console.log("API FINALLY");
        setIsLoading(false);
      });
  };

  //csvインポートボタン
  const onImport = (file: UploadFile) => {
    setImportDialogOpen(false);
    const formData = new FormData();

    formData.append(
      "data",
      new Blob(
        [
          JSON.stringify({
            year: year,
          }),
        ],
        { type: "application/json" },
      ),
    );
    formData.append("file", file.originFileObj!);

    excelImport(formData)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        console.log("API FINALLY");
        setIsLoading(false);
      });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    //データリスト取得
    getList(pageSize, currentPage);
    router.replace(ROUTES.SCHOOL_AREA_INFO_LIST);
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ButtonWrapper>
            <Select
              style={{ width: 200 }}
              placeholder="年を選択してください"
              options={yearOptions}
              value={year}
              onChange={(value) => setYear(value)}
            />
            <Button
              type="primary"
              onClick={() => {
                setImportDialogOpen(true);
              }}
            >
              データ取込
            </Button>
          </ButtonWrapper>
        }
        errorMessage={errMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={tableData}
          rowKey="rowKey"
          pagination={true}
          stickyHeader
          loading={isLoading}
          size="middle"
          current={currentPage}
          pageSize={pageSize}
          total={totalRecord}
          onPaginationChange={onPaginationChange}
        />
      </ListPageLayout>

      <CsvImportModal
        open={importDialogOpen}
        accept=".xlsx"
        onClose={() => setImportDialogOpen(false)}
        onImport={onImport}
      >
        <p>
          【{year}年度】の【学区域情報ファイル（xlsx）】
          <br />
          を選択してください
          <br />
          ※取込済みデータは削除されます
        </p>
        <br />
      </CsvImportModal>

      {/* 登録完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
