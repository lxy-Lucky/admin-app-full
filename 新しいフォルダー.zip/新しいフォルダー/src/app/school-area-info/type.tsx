import { UploadFile } from "antd";

export type SchoolAreaInfo = {
  ward_code: string;
  town_code: string;
  aza_code: string;
  banchi_code_from_1: string;
  banchi_code_from_2: string;
  banchi_code_from_3: string;
  banchi_code_from_4: string;
  banchi_code_to_1: string;
  banchi_code_to_2: string;
  banchi_code_to_3: string;
  banchi_code_to_4: string;
  shiteikou_code_1: string;
  shiteikou_code_2: string;
  shiteikou_code_3: string;
  tokucho_kbn: string;
  tokucho_kou_code_1: string;
  tokucho_kou_code_2: string;
};

export enum SORT_TYPE {
  WARD_CODE = "ward_code",
  TOWN_CODE = "town_code",
  AZA_CODE = "aza_code",
  BANCHI_CODE_FROM_1 = "banchi_code_from_1",
  BANCHI_CODE_FROM_2 = "banchi_code_from_2",
  BANCHI_CODE_FROM_3 = "banchi_code_from_3",
  BANCHI_CODE_FROM_4 = "banchi_code_from_4",
  BANCHI_CODE_TO_1 = "banchi_code_to_1",
  BANCHI_CODE_TO_2 = "banchi_code_to_2",
  BANCHI_CODE_TO_3 = "banchi_code_to_3",
  BANCHI_CODE_TO_4 = "banchi_code_to_4",
  SHITEIKOU_CODE_1 = "shiteikou_code_1",
  SHITEIKOU_CODE_2 = "shiteikou_code_2",
  SHITEIKOU_CODE_3 = "shiteikou_code_3",
  TOKUCHO_KBN = "tokucho_kbn",
  TOKUCHO_KOU_CODE_1 = "tokucho_kou_code_1",
  TOKUCHO_KOU_CODE_2 = "tokucho_kou_code_2",
}

export type SchoolAreaInfoReqInfo = {
  year: number;
  page_size: number;
  current_page: number;
};

export type FormDatas = {
  year: string;
  file_nm: UploadFile[];
};
