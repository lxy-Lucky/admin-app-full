import {
  AdoptRateKbn,
  RateListInfo,
  RateUpdateReqInfo,
  RateUpdateValues,
} from "@/components/RateTable/type";

/** 中学校増減率表リスト取得のリクエスト情報 */
export type JhsChangeRateReqInfo = {
  /** 対象年度 */
  year: number;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

/** 中学校増減率表リストの1行 */
export type JhsChangeRates = {
  /** 中学校増減率表データID（画面には出さない） */
  jhs_change_rates_id: string;
  /** 対象年度 */
  year: number;
  /** 区コード */
  ward_code: string;
  /** 学校コード */
  school_code: string;
  /** 学校名 */
  school_nm: string;

  /** 昨年度中1～中2（前年度データが無い学校はnull） */
  last_year_jhs1_students: number | null;
  last_year_jhs2_students: number | null;
  /** 昨年度計（中1～中2） */
  last_year_jhs_total: number | null;

  /** 今年度中2～中3 */
  this_year_jhs2_students: number | null;
  this_year_jhs3_students: number | null;
  /** 今年度計（中2～中3） */
  this_year_jhs_total: number | null;

  /** 増減率（4年前～今年） */
  change_rate_4y_ago: number | null;
  change_rate_3y_ago: number | null;
  change_rate_2y_ago: number | null;
  change_rate_1y_ago: number | null;
  change_rate_this_year: number | null;

  /** 3年平均 */
  avg3_change_rate: number | null;
  /** 5年平均 */
  avg5_change_rate: number | null;
  /** その他率（画面で手入力した率） */
  misc_change_rate: number | null;
  /** 前年採用率 */
  last_year_rate: number | null;
  /** 本年採用率（ラジオボタンで選択した率の値） */
  this_year_rate: number | null;
  /** 採用率区分（未選択の場合はnull） */
  adopt_rate_kbn: AdoptRateKbn | null;
  /** 備考 */
  note: string | null;
};

/** 中学校増減率表リスト取得のレスポンス情報（info） */
export type JhsChangeRatesInfo = RateListInfo<JhsChangeRates>;

/** 中学校増減率表 修正登録のリクエスト情報 */
export type JhsChangeRateUpdateReqInfo = RateUpdateReqInfo<
  RateUpdateValues & {
    /** 中学校増減率表データID */
    jhs_change_rates_id: string;
    /** その他率（画面の入力値。採用率区分が「その他」の場合は本年採用率にもなる） */
    misc_change_rate: number | null;
  }
>;
