export type InfantSummary2ReqInfo = {
  /** 対象年度 */
  year: number;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

/** 2次集計結果（指定校：受入校 ごと）
 *  ※特調区域でない住所の人数は、受入校無し（null）の行として返る */
export type InfantSummary2Detail = {
  /** 指定校（正規校）学校コード */
  shiteikou_code: string;
  /** 指定校（正規校）学校名 */
  shiteikou_nm: string;
  /** 受入校学校コード（受入なしの場合はnull） */
  ukeirekou_code: string | null;
  /** 受入校学校名（受入なしの場合はnull） */
  ukeirekou_nm: string | null;
  /** 受入校②学校コード（受入校が1校・受入なしの場合はnull） */
  ukeirekou2_code: string | null;
  /** 受入校②学校名（受入校が1校・受入なしの場合はnull） */
  ukeirekou2_nm: string | null;
  /** 指定校 0歳児人数（按分する前の人数） */
  shiteikou_count_age_0: number;
  /** 指定校 1歳児人数（按分する前の人数） */
  shiteikou_count_age_1: number;
  /** 指定校 2歳児人数（按分する前の人数） */
  shiteikou_count_age_2: number;
  /** 指定校 3歳児人数（按分する前の人数） */
  shiteikou_count_age_3: number;
  /** 指定校 4歳児人数（按分する前の人数） */
  shiteikou_count_age_4: number;
  /** 指定校 5歳児人数（按分する前の人数） */
  shiteikou_count_age_5: number;
  /** 指定校 0~5歳児合計（按分する前の人数） */
  shiteikou_count_total: number;
  /** 受入校への按分率（受入なし・按分率未登録の場合はnull） */
  anbun_rate: number | null;
  /** 受入校への按分人数：0歳児 */
  anbun_count_age_0: number;
  /** 受入校への按分人数：1歳児 */
  anbun_count_age_1: number;
  /** 受入校への按分人数：2歳児 */
  anbun_count_age_2: number;
  /** 受入校への按分人数：3歳児 */
  anbun_count_age_3: number;
  /** 受入校への按分人数：4歳児 */
  anbun_count_age_4: number;
  /** 受入校への按分人数：5歳児 */
  anbun_count_age_5: number;
  /** 受入校への按分人数：0~5歳児合計 */
  anbun_count_total: number;
  /** 受入校②への按分率（受入校②なし・按分率未登録の場合はnull） */
  anbun2_rate: number | null;
  /** 受入校②への按分人数：0歳児 */
  anbun2_count_age_0: number;
  /** 受入校②への按分人数：1歳児 */
  anbun2_count_age_1: number;
  /** 受入校②への按分人数：2歳児 */
  anbun2_count_age_2: number;
  /** 受入校②への按分人数：3歳児 */
  anbun2_count_age_3: number;
  /** 受入校②への按分人数：4歳児 */
  anbun2_count_age_4: number;
  /** 受入校②への按分人数：5歳児 */
  anbun2_count_age_5: number;
  /** 受入校②への按分人数：0~5歳児合計 */
  anbun2_count_total: number;
  /** 指定校 0歳児人数（按分した後の人数） */
  result_count_age_0: number;
  /** 指定校 1歳児人数（按分した後の人数） */
  result_count_age_1: number;
  /** 指定校 2歳児人数（按分した後の人数） */
  result_count_age_2: number;
  /** 指定校 3歳児人数（按分した後の人数） */
  result_count_age_3: number;
  /** 指定校 4歳児人数（按分した後の人数） */
  result_count_age_4: number;
  /** 指定校 5歳児人数（按分した後の人数） */
  result_count_age_5: number;
  /** 指定校 0~5歳児合計（按分した後の人数） */
  result_count_total: number;
};

/** 2次集計実行情報（集計実行情報取得のレスポンス情報）
 *  ※未集計（2次集計が未実行）の場合はinfo=nullが返る */
export type InfantSummary2ExecuteInfo = {
  /** 対象年度 */
  year: number;
  /** 更新日付（＝集計実行日） */
  update_date: string;
  /** 更新者ID */
  update_user_id: string;
  /** 更新者名（＝集計実行者） */
  update_user_nm: string;
  /** 2次集計結果リスト（リクエストのページ分のみ） */
  summary_2_list: InfantSummary2Detail[];
  /** ページサイズ */
  page_size: number;
  /** 現在表示ページ */
  current_page: number;
  /** 総件数（全ページ分） */
  total_size: number;
};
