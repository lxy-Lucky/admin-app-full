"use client";

import { useEffect, useMemo, useState } from "react";
import { Select } from "antd";
import type { ColumnsType } from "antd/es/table";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import { numberSorter, sorter } from "@/components/Table/utils";
import Button from "@/components/Button/page";
import Dialog from "@/components/Modal/Dialog";
import { CommonResponse, CONFIRM_MESSAGE, MessageLevel } from "@/constants/common";
import { execute, executeInfo, listPrint } from "@/services/infant-summary2Service";
import { usePagination } from "@/components/Table/pagination";
import { getCurrentYear, renderAnbunRate, saveBlobResponse } from "@/utils/common";
import {
  ConditionPanel,
  ExecuteInfoText,
  ExecuteRow,
  PanelHeader,
  PrintBar,
  YearRow,
} from "./styles";
import { InfantSummary2Detail, InfantSummary2ExecuteInfo, InfantSummary2ReqInfo } from "./type";
import { ERROR_MESSAGE } from "@/constants/message";

// 年齢別人数の列の種類（BEの項目名の接頭辞。anbun=受入校①への按分、anbun2=受入校②への按分）
type CountColumnKind = "shiteikou" | "anbun" | "anbun2" | "result";

/** 受入校が無い（受入なし）行か判定する */
const isNoUkeirekou = (record: InfantSummary2Detail) => record.ukeirekou_code == null;

/** 受入校②が無い（受入なし・受入校が1校の区域）行か判定する */
const isNoUkeirekou2 = (record: InfantSummary2Detail) => record.ukeirekou2_code == null;

/** 年齢別人数の表示
 *  ※受入校①②への按分人数は、その受入校が無い行では按分対象外のため「-」を表示する */
const renderCount = (kind: CountColumnKind) => (value: number, record: InfantSummary2Detail) => {
  if (kind === "anbun" && isNoUkeirekou(record)) {
    return "-";
  }
  if (kind === "anbun2" && isNoUkeirekou2(record)) {
    return "-";
  }
  return value;
};

/** 受入校名・学校＃・按分率の列を生成する（受入校①②で同じ並びのため）
 *  ※受入校①が無い行は、受入校名に「（受入なし）」、その他の項目に「-」を表示する
 *  ※受入校②が無い行は、受入校名・学校＃・按分率とも「-」を表示する */
const createUkeirekouColumns = (
  kind: "ukeirekou" | "ukeirekou2",
  rateField: "anbun_rate" | "anbun2_rate",
): ColumnsType<InfantSummary2Detail> => {
  // この受入校が無い行か判定する
  const isNone = (record: InfantSummary2Detail) =>
    kind === "ukeirekou" ? isNoUkeirekou(record) : isNoUkeirekou2(record);

  return [
    {
      title: "受入校名",
      dataIndex: `${kind}_nm`,
      key: `${kind}_nm`,
      width: 160,
      sorter: sorter(`${kind}_nm`),
      render: (value: string | null, record) => {
        if (!isNone(record)) {
          return value;
        }
        return kind === "ukeirekou" ? "（受入なし）" : "-";
      },
    },
    {
      title: "学校＃",
      dataIndex: `${kind}_code`,
      key: `${kind}_code`,
      width: 80,
      sorter: sorter(`${kind}_code`),
      render: (value: string | null, record) => (isNone(record) ? "-" : value),
    },
    {
      title: "按分率",
      dataIndex: rateField,
      key: rateField,
      width: 100,
      sorter: numberSorter(rateField),
      render: (value: number | null, record) => (isNone(record) ? "-" : renderAnbunRate(value)),
    },
  ];
};

/** 0歳～5歳児人数＋合計の列を生成する（按分前・按分人数・按分後で同じ並びのため） */
const createCountColumns = (kind: CountColumnKind): ColumnsType<InfantSummary2Detail> => [
  ...[0, 1, 2, 3, 4, 5].map((age) => ({
    title: `${age}歳`,
    dataIndex: `${kind}_count_age_${age}`,
    key: `${kind}_count_age_${age}`,
    width: 70,
    sorter: numberSorter(`${kind}_count_age_${age}`),
    render: renderCount(kind),
  })),
  {
    title: "合計",
    dataIndex: `${kind}_count_total`,
    key: `${kind}_count_total`,
    width: 80,
    sorter: numberSorter(`${kind}_count_total`),
    render: renderCount(kind),
  },
];

/** 2次集計実行 */
export default function InfantSummary2() {
  const [year, setYear] = useState<number>(new Date().getFullYear());
  // 集計実行情報（集計実行日・集計実行者・2次集計結果リスト）。未集計の場合はnull
  const [summaryInfo, setSummaryInfo] = useState<InfantSummary2ExecuteInfo | null>(null);

  const [errMsg, setErrMsg] = useState("");
  // 集計未実行など、エラーではないが利用者に対応を促すメッセージ（msg_level=WARN相当）
  const [warnMsg, setWarnMsg] = useState("");
  // 初期表示時に必ず集計実行情報を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(false);

  // 集計完了ダイアログ表示
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  // 2次集計実行の実行確認ダイアログ表示
  const [exeConfirmDialogOpen, setExeConfirmDialogOpen] = useState(false);

  // 集計結果詳細の折りたたみ状態
  const [executeAreaFolded, setExecutedAreaFolded] = useState(true);

  const yearOptions = getCurrentYear();

  // ページネーション（BE側でページ分のみ返却されるため、ページ状態をここで管理する）
  const {
    currentPage,
    pageSize,
    totalRecord,
    setCurrentPage,
    setTotalRecord,
    handlePaginationChange,
  } = usePagination({});

  // 横形式の一覧：指定校 → 按分前人数 → 受入校①・按分人数 → 受入校②・按分人数 → 按分後人数
  const columns = useMemo<ColumnsType<InfantSummary2Detail>>(
    () => [
      {
        title: "指定校（正規校）",
        children: [
          {
            title: "指定校名",
            dataIndex: "shiteikou_nm",
            key: "shiteikou_nm",
            width: 160,
            sorter: sorter("shiteikou_nm"),
          },
          {
            title: "学校＃",
            dataIndex: "shiteikou_code",
            key: "shiteikou_code",
            width: 80,
            sorter: sorter("shiteikou_code"),
          },
        ],
      },
      {
        title: "按分前人数",
        children: createCountColumns("shiteikou"),
      },
      {
        title: "受入校①",
        children: createUkeirekouColumns("ukeirekou", "anbun_rate"),
      },
      {
        title: "受入校①への按分人数",
        children: createCountColumns("anbun"),
      },
      {
        title: "受入校②",
        children: createUkeirekouColumns("ukeirekou2", "anbun2_rate"),
      },
      {
        title: "受入校②への按分人数",
        children: createCountColumns("anbun2"),
      },
      {
        title: "按分後人数（指定校）",
        children: createCountColumns("result"),
      },
    ],
    [],
  );

  //画面に表示されるメッセージをクリア
  const clearMessage = () => {
    setErrMsg("");
    setWarnMsg("");
  };

  // 2次集計結果リスト取得
  // ※ローディング開始・メッセージのクリアは呼び出し側で行う
  const fetchExecuteInfo = (page: number, size: number) => {
    const req: InfantSummary2ReqInfo = {
      year: year,
      current_page: page,
      page_size: size,
    };

    return executeInfo(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          // 未集計（2次集計が未実行）の場合はinfo=null
          const info: InfantSummary2ExecuteInfo | null = data.info ?? null;

          setSummaryInfo(info);

          // 全ページ分の総件数（未集計の場合は0件）
          setTotalRecord(info?.total_size ?? 0);
          // 未集計（info=null）の場合のみ注意メッセージを表示する
          setWarnMsg(info ? "" : data?.message || ERROR_MESSAGE.NOT_EXECUTED_MESSAGE);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  const tableData = useMemo(
    () =>
      (summaryInfo?.summary_2_list ?? []).map((item, index) => ({
        ...item,
        rowKey: index,
      })),
    [summaryInfo],
  );

  // 初期表示および年度変更時に集計実行情報を取得する
  // （初期表示時点でisLoading=true・メッセージ無しのため、ここでは取得のみを行う）
  useEffect(() => {
    fetchExecuteInfo(currentPage, pageSize);
    // ページの変更はonPaginationChangeで取得するため、ここでは年度の変更時のみ実行する
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year]);

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    clearMessage();
    setIsLoading(true);
    // 年度が変わると件数も変わるため、1ページ目から表示し直す
    setCurrentPage(1);
    setYear(value);
  };

  // ページ番号・ページサイズ変更時はBEから該当ページを取得し直す
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      clearMessage();
      setIsLoading(true);
      fetchExecuteInfo(nextPage, nextSize);
    });
  };

  // 2次集計実行（実行確認ダイアログの「実行」ボタン）
  // 1次集計結果と採用按分率から2次集計結果を作成し、登録する
  const onExecute = () => {
    clearMessage();
    setIsLoading(true);
    setExeConfirmDialogOpen(false);

    const req: InfantSummary2ReqInfo = {
      year: year,
    };

    execute(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO) {
          // 集計成功（一覧・集計実行日・集計実行者は完了ダイアログを閉じた後に取得し直す）
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else if (data?.msg_level === MessageLevel.WARN) {
          // 1次集計が未実行のため集計されていない
          setWarnMsg(data?.message);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 印刷ボタン（2次集計結果情報リストのExcel出力）
  const onPrint = () => {
    clearMessage();
    setIsLoading(true);

    const req: InfantSummary2ReqInfo = {
      year: year,
    };

    listPrint(req)
      .then(async (res) => {
        // ファイルを受け取れなかった場合は理由がメッセージとして返るため、エラー表示する
        const failedMsg = await saveBlobResponse(res, `2次集計結果情報_${year}.xlsx`);

        if (failedMsg) {
          setErrMsg(failedMsg);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    //2次集計結果リスト取得
    clearMessage();
    setIsLoading(true);
    fetchExecuteInfo(currentPage, pageSize);
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ConditionPanel>
            <PanelHeader onClick={() => setExecutedAreaFolded((prev) => !prev)}>
              <span>{executeAreaFolded ? "▼" : "▲"}</span>
              <span>集計結果詳細</span>
            </PanelHeader>
            {!executeAreaFolded && (
              <div>
                <YearRow>
                  <Select
                    style={{ width: 120 }}
                    placeholder="年を選択してください"
                    options={yearOptions}
                    value={year}
                    onChange={onChangeYear}
                  />
                  <span>年度</span>
                </YearRow>

                <ExecuteRow>
                  <Button
                    type="primary"
                    onClick={() => setExeConfirmDialogOpen(true)}
                    disabled={isLoading}
                  >
                    2次集計実行
                  </Button>

                  {/* 集計済みの場合のみ、集計実行日・集計実行者を表示する */}
                  {summaryInfo && (
                    <ExecuteInfoText>
                      {/* BEは「yyyy/MM/dd HH:mm:ss」形式で返すため、時分秒までそのまま表示する */}
                      <span>集計実行日：{summaryInfo.update_date}</span>
                      <span>集計実行者：{summaryInfo.update_user_nm}</span>
                    </ExecuteInfoText>
                  )}
                </ExecuteRow>
              </div>
            )}

            <PrintBar>
              {/* 集計結果が無い状態では出力対象が無いため押せないようにする */}
              <Button
                type="primary"
                onClick={onPrint}
                disabled={isLoading || tableData.length === 0}
              >
                印刷
              </Button>
            </PrintBar>
          </ConditionPanel>
        }
        errorMessage={errMsg}
        warnMessage={warnMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={tableData}
          rowKey="rowKey"
          pagination
          stickyHeader
          loading={isLoading}
          size="middle"
          current={currentPage}
          pageSize={pageSize}
          total={totalRecord}
          onPaginationChange={onPaginationChange}
        />
      </ListPageLayout>

      {/* 2次集計実行の実行確認ダイアログ */}
      <Dialog
        mode="import"
        open={exeConfirmDialogOpen}
        onClose={() => setExeConfirmDialogOpen(false)}
        onConfirm={onExecute}
        confirmText="実行"
        showCancel={true}
      >
        <p>{CONFIRM_MESSAGE.EXECUTE_MSG}</p>
      </Dialog>

      {/* 集計完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
