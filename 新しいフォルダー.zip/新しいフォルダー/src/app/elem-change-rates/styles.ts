import styled from "styled-components";

// 操作エリア全体（セクション見出し＋年度／修正登録／表の切替／印刷）
export const ConditionPanel = styled.div`
  border: 1px solid ${(props) => props.theme.colors.light_gray6};
  border-radius: 4px;
  background: ${(props) => props.theme.colors.light_gray8};
  padding: 12px 16px;
`;

// セクション見出し（集計結果詳細）。クリックで操作エリアの表示／非表示を切り替える
// （開閉の見た目は共通の検索条件パネル（SearchForm）に合わせる）
export const PanelHeader = styled.div<{ $collapsed: boolean }>`
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: ${(props) => (props.$collapsed ? "0" : "12px")};
  cursor: pointer;
  user-select: none;
  font-size: ${(props) => props.theme.fontSizes.base};
  font-weight: ${(props) => props.theme.fontWeights.semi_bold};
  color: ${(props) => props.theme.colors.absolute_black};

  .arrow {
    color: ${(props) => props.theme.colors.strong_blue1};
    font-size: ${(props) => props.theme.fontSizes.small};
  }
`;

// 年度選択行
export const YearRow = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  color: ${(props) => props.theme.colors.absolute_black};
`;

// 修正登録ボタンの行
export const UpdateRow = styled.div`
  display: flex;
  align-items: center;
  gap: 24px;
  flex-wrap: wrap;
`;

// 表の切替（ラジオボタン）と印刷ボタンを左右に並べる行
export const ResultKbnRow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  flex-wrap: wrap;
  margin-top: 12px;
`;

// 印刷ボタン（右寄せ）
export const PrintBar = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 10px;
`;
