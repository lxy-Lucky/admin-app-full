"use client";

import { useState } from "react";
import { Radio, Select } from "antd";
import type { AxiosResponse } from "axios";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import Button from "@/components/Button/page";
import Dialog from "@/components/Modal/Dialog";
import { CONFIRM_MESSAGE } from "@/constants/common";
import {
  elemInfantRateInfoPrint,
  elemNext6yForecastPrint,
} from "@/services/elemChangeRatesService";
import { getCurrentYear, saveBlobResponse } from "@/utils/common";
import { RateTableWrapper } from "@/components/RateTable/styles";
import {
  ELEM_CHANGE_RATE_TABLE,
  INFANT_CHANGE_RATE_TABLE,
  INFANT_ENROL_RATE_TABLE,
} from "@/components/RateTable/rateTableDefs";
import { useRateTable } from "@/components/RateTable/useRateTable";
import { ConditionPanel, PanelHeader, PrintBar, ResultKbnRow, UpdateRow, YearRow } from "./styles";
import { ElemChangeRateReqInfo } from "./type";

//（ラジオボタンの値）表示・修正する率表
const INFANT_CHANGE_RATE = "1"; // 幼児増減率
const INFANT_ENROL_RATE = "2"; // 幼児就学率
const ELEM_CHANGE_RATE = "3"; // 小学校増減率

/** ラジオボタンの値ごとの率表の定義 */
const RATE_TABLES = {
  [INFANT_CHANGE_RATE]: INFANT_CHANGE_RATE_TABLE,
  [INFANT_ENROL_RATE]: INFANT_ENROL_RATE_TABLE,
  [ELEM_CHANGE_RATE]: ELEM_CHANGE_RATE_TABLE,
};

type ResultKbn = keyof typeof RATE_TABLES;

/** 小学校推計 ＞ 採用率修正（幼児増減率表・幼児就学率表・小学校増減率表） */
export default function ElemChangeRatesPage() {
  const [year, setYear] = useState<number>(new Date().getFullYear());
  // 表示・修正する率表（初期表示は幼児増減率）
  const [resultKbn, setResultKbn] = useState<ResultKbn>(INFANT_CHANGE_RATE);
  // 修正登録の確認ダイアログ表示
  const [updateConfirmDialogOpen, setUpdateConfirmDialogOpen] = useState(false);
  // 「集計結果詳細」エリアの折りたたみ
  const [panelCollapsed, setPanelCollapsed] = useState(false);

  // 登録完了ダイアログ表示
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  //現在の年度を取得
  const yearOptions = getCurrentYear();

  // 表示中の率表
  const table = RATE_TABLES[resultKbn];

  // 表示中の一覧の取得・修正登録（幼児増減率表・就学率表・小学校増減率表で共通の処理）
  const rateTable = useRateTable(table, year);
  const { setErrMsg, setIsLoading, clearMessage, isLoading, hasListData } = rateTable;

  // 表示する率表の変更
  const onChangeResultKbn = (value: ResultKbn) => {
    rateTable.prepareReload();
    setResultKbn(value);
  };

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    rateTable.prepareReload();
    setYear(value);
  };

  // 修正登録ボタン。入力漏れがあれば確認ダイアログを出さずにエラーを表示する
  const onClickUpdate = () => {
    if (rateTable.validateUpdate()) {
      setUpdateConfirmDialogOpen(true);
    }
  };

  // 修正登録（確認ダイアログの「登録」ボタン）
  // 表示中の率表の、表示中ページの全行の採用率・その他率・備考を送る
  const onUpdate = () => {
    setUpdateConfirmDialogOpen(false);
    rateTable.update((message) => {
      // 一覧は完了ダイアログを閉じた後に取得し直す
      setCompleteMsg(message);
      setCompleteDialogOpen(true);
    });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    //一覧を取得し直す
    rateTable.reload();
  };

  /** Excel出力（各率登録印刷・将来推計印刷で共通）
   *  @param print 印刷API
   *  @param defaultFileName BEからファイル名が返らなかった場合のファイル名 */
  const printExcel = (
    print: (req: ElemChangeRateReqInfo) => Promise<AxiosResponse<Blob>>,
    defaultFileName: string,
  ) => {
    clearMessage();
    setIsLoading(true);

    const req: ElemChangeRateReqInfo = {
      year: year,
    };

    print(req)
      .then(async (res) => {
        // ファイルを受け取れなかった場合は理由がメッセージとして返るため、エラー表示する
        const failedMsg = await saveBlobResponse(res, defaultFileName);

        if (failedMsg) {
          setErrMsg(failedMsg);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 各率登録印刷ボタン（幼児・就学・小学校増減率の登録内容のExcel出力）
  const onPrintRateInfo = () => {
    printExcel(elemInfantRateInfoPrint, `${year}年度幼率_就率_転率.xlsx`);
  };

  // 将来推計印刷ボタン（児童6年先推計のExcel出力）
  const onPrintForecast = () => {
    printExcel(elemNext6yForecastPrint, `${year}年度_幼児_就学_増減率組込ファイル.xlsx`);
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ConditionPanel>
            <PanelHeader
              $collapsed={panelCollapsed}
              onClick={() => setPanelCollapsed((prev) => !prev)}
            >
              <span>集計結果詳細</span>
              <span className="arrow">{panelCollapsed ? "▼" : "▲"}</span>
            </PanelHeader>

            {!panelCollapsed && (
              <>
                <YearRow>
                  <Select
                    style={{ width: 120 }}
                    placeholder="年を選択してください"
                    options={yearOptions}
                    value={year}
                    onChange={onChangeYear}
                  />
                  <span>年度</span>
                </YearRow>

                <UpdateRow>
                  {/* 画面で選択した採用率・その他率・備考を登録する（表示中の率表の、表示中のページ分） */}
                  <Button
                    type="primary"
                    onClick={onClickUpdate}
                    disabled={isLoading || !hasListData}
                  >
                    修正登録
                  </Button>
                </UpdateRow>

                <ResultKbnRow>
                  {/* 一覧の表示切替用 */}
                  <Radio.Group
                    value={resultKbn}
                    onChange={(e) => onChangeResultKbn(e.target.value)}
                  >
                    <Radio value={INFANT_CHANGE_RATE}>幼児増減率</Radio>
                    <Radio value={INFANT_ENROL_RATE}>幼児就学率</Radio>
                    <Radio value={ELEM_CHANGE_RATE}>小学校増減率</Radio>
                  </Radio.Group>

                  {/* 印刷は表示中の率表に関係なく出力する（出力対象が無い場合はBEのメッセージを表示する） */}
                  <PrintBar>
                    <Button type="primary" onClick={onPrintRateInfo} disabled={isLoading}>
                      各率登録印刷
                    </Button>
                    <Button type="primary" onClick={onPrintForecast} disabled={isLoading}>
                      将来推計印刷
                    </Button>
                  </PrintBar>
                </ResultKbnRow>
              </>
            )}
          </ConditionPanel>
        }
        errorMessage={rateTable.errMsg}
        warnMessage={rateTable.warnMsg}
      >
        <RateTableWrapper>
          {/* 表を切り替えると列・行のキーも変わるため、表ごとに別のテーブルとして描画する */}
          <CustomTable
            key={resultKbn}
            columns={rateTable.columns}
            dataSource={rateTable.list}
            rowKey={table.rowKey}
            pagination
            stickyHeader
            loading={isLoading}
            size="middle"
            current={rateTable.currentPage}
            pageSize={rateTable.pageSize}
            total={rateTable.totalRecord}
            onPaginationChange={rateTable.onPaginationChange}
          />
        </RateTableWrapper>
      </ListPageLayout>

      {/* 修正登録の確認ダイアログ */}
      <Dialog
        mode="import"
        open={updateConfirmDialogOpen}
        onClose={() => setUpdateConfirmDialogOpen(false)}
        onConfirm={onUpdate}
        confirmText="登録"
        showCancel={true}
      >
        <p>{CONFIRM_MESSAGE.UPDATE_MSG}</p>
      </Dialog>

      {/* 登録完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
