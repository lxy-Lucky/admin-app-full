import {
  AdoptRateKbn,
  RateListInfo,
  RateUpdateReqInfo,
  RateUpdateValues,
} from "@/components/RateTable/type";

/** 小学校増減率表リスト取得のリクエスト情報 */
export type ElemChangeRateReqInfo = {
  /** 対象年度 */
  year: number;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

/** 小学校増減率表リストの1行 */
export type ElemChangeRates = {
  /** 小学校増減率表データID（画面には出さない） */
  elem_change_rates_id: string;
  /** 対象年度 */
  year: number;
  /** 区コード */
  ward_code: string;
  /** 学校コード */
  school_code: string;
  /** 学校名 */
  school_nm: string;

  /** 昨年度小1～小5（前年度データが無い学校はnull） */
  last_year_students_1: number | null;
  last_year_students_2: number | null;
  last_year_students_3: number | null;
  last_year_students_4: number | null;
  last_year_students_5: number | null;
  /** 昨年度計（小1～小5） */
  last_year_total: number | null;

  /** 今年度小2～小6 */
  this_year_students_2: number | null;
  this_year_students_3: number | null;
  this_year_students_4: number | null;
  this_year_students_5: number | null;
  this_year_students_6: number | null;
  /** 今年度計（小2～小6） */
  this_year_total: number | null;

  /** 増減率（4年前～今年） */
  change_rate_4y_ago: number | null;
  change_rate_3y_ago: number | null;
  change_rate_2y_ago: number | null;
  change_rate_1y_ago: number | null;
  change_rate_this_year: number | null;

  /** 3年平均 */
  avg3_change_rate: number | null;
  /** 5年平均 */
  avg5_change_rate: number | null;
  /** その他率（画面で手入力した率） */
  misc_change_rate: number | null;
  /** 前年採用率 */
  last_year_rate: number | null;
  /** 本年採用率（ラジオボタンで選択した率の値） */
  this_year_rate: number | null;
  /** 採用率区分（未選択の場合はnull） */
  adopt_rate_kbn: AdoptRateKbn | null;
  /** 備考 */
  note: string | null;
};

/** 小学校増減率表リスト取得のレスポンス情報（info） */
export type ElemChangeRatesInfo = RateListInfo<ElemChangeRates>;

/** 小学校増減率表 修正登録のリクエスト情報 */
export type ElemChangeRateUpdateReqInfo = RateUpdateReqInfo<
  RateUpdateValues & {
    /** 小学校増減率表データID */
    elem_change_rates_id: string;
    /** その他率（画面の入力値。採用率区分が「その他」の場合は本年採用率にもなる） */
    misc_change_rate: number | null;
  }
>;
