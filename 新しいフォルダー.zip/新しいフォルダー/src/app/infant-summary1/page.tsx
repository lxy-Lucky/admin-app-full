"use client";

import { useEffect, useMemo, useState } from "react";
import { message, Select, UploadFile } from "antd";
import type { ColumnsType } from "antd/es/table";
import AppLayout from "@/components/AppLayout/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import CustomTable from "@/components/Table/page";
import { numberSorter, sorter } from "@/components/Table/utils";
import Button from "@/components/Button/page";
import Dialog from "@/components/Modal/Dialog";
import { CommonResponse, MessageLevel } from "@/constants/common";
import { execute, executeInfo, listPrint } from "@/services/infant-summary1Service";
import { usePagination } from "@/components/Table/pagination";
import { getCurrentYear, saveBlobResponse } from "@/utils/common";
import {
  ConditionPanel,
  ExecuteInfoText,
  ExecuteRow,
  PanelHeader,
  PrintBar,
  YearRow,
} from "./styles";
import { FumeiAreaDetail, FumeiAreaExecuteInfo, FumeiAreaInputReqInfo } from "./type";
import { ERROR_MESSAGE } from "@/constants/message";
import CsvImportModal from "@/components/Modal/ImportModal/ImportModal";
import { ROUTES } from "@/constants/routes";

/** 幼児>学区域不明児 入力票取込 */
export default function FumeiAreaInputListPage() {
  const [year, setYear] = useState<number>(new Date().getFullYear());
  // 集計実行情報（集計実行日・集計実行者・不明児リスト）。未集計の場合はnull
  const [fumeiInfo, setFumeiInfo] = useState<FumeiAreaExecuteInfo | null>(null);

  const [data, setData] = useState<FumeiAreaDetail[]>([]);
  const [errMsg, setErrMsg] = useState("");
  // 集計未実行など、エラーではないが利用者に対応を促すメッセージ（msg_level=WARN相当）
  const [warnMsg, setWarnMsg] = useState("");
  // 初期表示時に必ず集計実行情報を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(false);

  // 取り込み完了ダイアログ表示
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  // ファイルアップロードダイアログ
  const [fileUploadModalOpen, setFileUploadModalOpen] = useState(false);

  // インポート中の場合、Modalの実行ボタンを非活性のため
  const [isImporting, setIsImporting] = useState(false);

  const yearOptions = getCurrentYear();

  // 集計結果詳細の折りたたみ状態
  const [executeAreaFolded, setExecutedAreaFolded] = useState(true);

  // ページネーション（BE側でページ分のみ返却されるため、ページ状態をここで管理する）
  const {
    currentPage,
    pageSize,
    totalRecord,
    setCurrentPage,
    setTotalRecord,
    handlePaginationChange,
  } = usePagination({});

  const columns = useMemo<ColumnsType<FumeiAreaDetail>>(
    () => [
      {
        title: "区名",
        dataIndex: "ward_nm",
        key: "ward_nm",
        width: 160,
        sorter: sorter("ward_nm"),
      },
      {
        title: "町字名",
        dataIndex: "machi_aza_nm",
        key: "machi_aza_nm",
        width: 80,
        sorter: sorter("machi_aza_nm"),
      },
      {
        title: "番地コードFROM",
        dataIndex: "banchi_code_from_fix",
        key: "banchi_code_from_fix",
        width: 100,
        sorter: sorter("banchi_code_from_fix"),
      },
      {
        title: "番地コードTO",
        dataIndex: "banchi_code_to_fix",
        key: "banchi_code_to_fix",
        width: 120,
        sorter: sorter("banchi_code_to_fix"),
      },
      {
        title: "0歳児人数",
        dataIndex: "count_age_0",
        key: "count_age_0",
        width: 180,
        sorter: numberSorter("count_age_0"),
      },
      {
        title: "1歳児人数",
        dataIndex: "count_age_1",
        key: "count_age_1",
        width: 140,
        sorter: numberSorter("count_age_1"),
      },
      {
        title: "2歳児人数",
        dataIndex: "count_age_2",
        key: "count_age_2",
        width: 140,
        sorter: numberSorter("count_age_2"),
      },
      {
        title: "3歳児人数",
        dataIndex: "count_age_3",
        key: "count_age_3",
        width: 140,
        sorter: numberSorter("count_age_3"),
      },
      {
        title: "4歳児人数",
        dataIndex: "count_age_4",
        key: "count_age_4",
        width: 140,
        sorter: numberSorter("count_age_4"),
      },
      {
        title: "5歳児人数",
        dataIndex: "count_age_5",
        key: "count_age_5",
        width: 140,
        sorter: numberSorter("count_age_5"),
      },
    ],
    [],
  );

  const fetchExecuteInfo = (page: number, size: number) => {
    clearMessage();
    const req: FumeiAreaInputReqInfo = {
      year: year,
      current_page: page,
      page_size: size,
    };

    return executeInfo(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          const info: FumeiAreaExecuteInfo | null = data.info ?? null;

          const infoList: FumeiAreaDetail[] = data.info?.summary_1_list ?? [];
          const tableData = infoList.map((item, index) => ({
            ...item,
            rowKey: index,
          }));

          setFumeiInfo(info);
          setData(tableData);

          // 全ページ分の総件数（未集計の場合は0件）
          setTotalRecord(info?.total_size ?? 0);
          // 未集計（info=null）の場合のみ注意メッセージを表示する
          setWarnMsg(info ? "" : data?.message || ERROR_MESSAGE.NOT_EXECUTED_MESSAGE);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 初期表示および年度変更時に集計実行情報を取得する
  // （初期表示時点でisLoading=true・メッセージ無しのため、ここでは取得のみを行う）
  useEffect(() => {
    fetchExecuteInfo(currentPage, pageSize);
  }, [year]);

  // 年度変更。取得完了まで前年度の結果・メッセージを残さないようここでクリアする
  const onChangeYear = (value: number) => {
    clearMessage();
    setIsLoading(true);
    // 年度が変わると件数も変わるため、1ページ目から表示し直す
    setCurrentPage(1);
    setYear(value);
  };

  // ページ番号・ページサイズ変更時はBEから該当ページを取得し直す
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      setErrMsg("");

      setIsLoading(true);
      fetchExecuteInfo(nextPage, nextSize);
    });
  };

  // 集計実行ボタン
  const onExecute = () => {
    setFileUploadModalOpen(true);
  };

  // 印刷ボタン（学区域不明児リストのExcel出力）
  const onPrint = () => {
    clearMessage();
    setIsLoading(true);

    const req: FumeiAreaInputReqInfo = {
      year: year,
    };

    listPrint(req)
      .then(async (res) => {
        // ファイルを受け取れなかった場合は理由がメッセージとして返るため、エラー表示する
        const failedMsg = await saveBlobResponse(res, `学区域不明児一覧_${year}.xlsx`);

        if (failedMsg) {
          setErrMsg(failedMsg);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // データ取込（Excel取込）ボタン押下時の処理
  const onImport = (file: UploadFile) => {
    setIsImporting(true);

    // 前回取込失敗時のエラーメッセージが残っていればクリアする
    clearMessage();

    // multipart/form-data形式でJSONデータ(data)とExcelファイル(file)を送信する
    const formData = new FormData();
    formData.append(
      "data",
      new Blob(
        [
          JSON.stringify({
            year: year,
          }),
        ],
        { type: "application/json" },
      ),
    );

    formData.append("file", file.originFileObj!);

    execute(formData)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO) {
          setCompleteMsg(data.message);
          setCompleteDialogOpen(true);
        } else {
          setErrMsg(data?.message);
        }

        setIsLoading(false);
      })
      .catch((err) => {
        setErrMsg(err.message);
        setIsLoading(false);
      })
      .finally(() => {
        setIsImporting(false);
        setFileUploadModalOpen(false);
      });
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    //住基データリスト取得
    fetchExecuteInfo(currentPage, pageSize);
  };

  //画面に表示されるメッセージをクリア
  const clearMessage = () => {
    setErrMsg("");
    setWarnMsg("");
  };

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ConditionPanel>
            <PanelHeader onClick={() => setExecutedAreaFolded((prev) => !prev)}>
              <span>{executeAreaFolded ? "▼" : "▲"}</span>
              <span>集計結果詳細</span>
            </PanelHeader>

            {!executeAreaFolded && (
              <div>
                <YearRow>
                  <Select
                    style={{ width: 120 }}
                    placeholder="年を選択してください"
                    options={yearOptions}
                    value={year}
                    onChange={onChangeYear}
                  />
                  <span>年度</span>
                </YearRow>

                <ExecuteRow>
                  <Button type="primary" onClick={onExecute} disabled={isLoading}>
                    集計実行
                  </Button>

                  {/* 集計済みの場合のみ、集計実行日・集計実行者を表示する */}
                  {fumeiInfo && (
                    <ExecuteInfoText>
                      {/* BEは「yyyy/MM/dd HH:mm:ss」形式で返すため、時分秒までそのまま表示する */}
                      <span>集計実行日：{fumeiInfo.update_date}</span>
                      <span>集計実行者：{fumeiInfo.update_user_nm}</span>
                    </ExecuteInfoText>
                  )}
                </ExecuteRow>
              </div>
            )}
            <PrintBar>
              {/* 集計結果が無い状態では出力対象が無いため押せないようにする */}
              <Button type="primary" onClick={onPrint} disabled={isLoading || data.length === 0}>
                印刷
              </Button>
            </PrintBar>
          </ConditionPanel>
        }
        errorMessage={errMsg}
        warnMessage={warnMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={data}
          rowKey="rowKey"
          pagination
          stickyHeader
          loading={isLoading}
          size="middle"
          current={currentPage}
          pageSize={pageSize}
          total={totalRecord}
          onPaginationChange={onPaginationChange}
          // add_fumei_flg"1"ならレコード色を変える
          rowClassName={(record) => (record.add_fumei_flg === "1" ? "highlight-row" : "")}
        />
      </ListPageLayout>

      {/* データ取込（Excel取込）ダイアログ */}
      <CsvImportModal
        open={fileUploadModalOpen}
        accept=".xlsx"
        onClose={() => setFileUploadModalOpen(false)}
        onImport={onImport}
        inOperation={isImporting}
      >
        <p>
          【{year}年度】の【学区域不明児入力票】
          <br />
          を選択してください
          <br />
        </p>
      </CsvImportModal>

      {/* 登録完了報告ダイアログ */}
      <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
        <p>{completeMsg}</p>
      </Dialog>
    </AppLayout>
  );
}
