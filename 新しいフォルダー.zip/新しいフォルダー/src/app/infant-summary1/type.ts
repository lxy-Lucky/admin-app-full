export type FumeiAreaInputReqInfo = {
  /** 対象年度 */
  year: number;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

export type FumeiAreaDetail = {
  /** 区名 */
  ward_nm: string;
  /** 町字名 */
  machi_aza_nm: number;
  /** 番地号 */
  banchigou: string;
  /** 番地コードFROM */
  banchi_code_from_fix: string;
  /** 番地コードTO */
  banchi_code_to_fix: string;
  /** 0歳児人数 */
  count_age_0: string;
  /** 1歳児人数 */
  count_age_1: string;
  /** 2歳児人数 */
  count_age_2: string;
  /** 3歳児人数*/
  count_age_3: string;
  /** 4歳児人数*/
  count_age_4: string;
  /** 5歳児人数*/
  count_age_5: string;
  /** 学区域不明児入力票追加フラグ。"1"なら、追加を意味する*/
  add_fumei_flg: string;
};

export type FumeiAreaExecuteInfo = {
  /** 更新日付（＝集計実行日） */
  update_date: string;
  /** 更新者ID */
  update_user_id: string;
  /** 更新者名（＝集計実行者） */
  update_user_nm: string;
  /** 学区域不明児リスト（リクエストのページ分のみ） */
  fumei_list: FumeiAreaDetail[];
  /** ページサイズ */
  page_size: number;
  /** 現在表示ページ */
  current_page: number;
  /** 総件数（全ページ分） */
  total_size: number;
};
