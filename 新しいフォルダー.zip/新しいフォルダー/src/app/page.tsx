"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Spin } from "antd";
import { login } from "@/services/loginService";
import { ROUTES } from "@/constants/routes";
import LocalStorage from "@/utils/LocalStorage";
import "@/styles/globals.scss";
import { ELapseFlag, LoginReqInfo } from "./type";
import { CommonResponse, ELocalStorgeKey, MessageLevel } from "@/constants/common";
import { VALIDATION_MESSAGE } from "@/constants/message";
import { ButtonWrapper, Form, FormItem, LoginButtonWrapper, LoginWrapper } from "./styles";
import { useForm } from "react-hook-form";
import Button from "@/components/Button/page";

export default function Login() {
  const router = useRouter();

  //ユーザーID
  const [userId, setUserId] = useState("");

  //password
  const [password, setPassword] = useState("");

  const [errMsg, setErrMsg] = useState("");

  const [isLoading, setIsLoading] = useState(false);
  let isBlockedAccount = false;

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
    shouldFocusError: true,
    reValidateMode: "onSubmit",
  });

  //ログイン
  const handleLogin = () => {
    //前回のAPIエラーをクリア
    setErrMsg("");

    setIsLoading(true);
    const req: LoginReqInfo = {
      user_id: userId,
      password: password,
      language: "ja",
    };
    login(req)
      .then((res) => {
        const data: CommonResponse = res.data;
        const userInfo = data?.info;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          if (userInfo.lapse_flg === ELapseFlag.SUSPEND) {
            isBlockedAccount = true;
          }

          LocalStorage.set(ELocalStorgeKey.USER_INFO, JSON.stringify(userInfo));
          router.replace(ROUTES.TOP);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return (
    <Spin classNames={{ root: "spin_loading" }} spinning={isLoading} style={{ maxHeight: "unset" }}>
      <LoginWrapper>
        <Form>
          <div className="login">
            <h3>Y-POP</h3>
            <span>~義務教育人口推計作成システム~</span>
          </div>

          <form
            onSubmit={handleSubmit(
              //APIエラークリア
              handleLogin,
              () => {
                setErrMsg("");
              },
            )}
            className="form"
          >
            <div className="error-div">
              <span className="mess-error">{errMsg}</span>
            </div>
            <FormItem>
              <div>
                <label htmlFor="userId" className="">
                  ユーザーID
                </label>
                {errors.user_id && (
                  <span className="mess-error">{errors.user_id.message as string}</span>
                )}
                <input
                  id="user_id"
                  value={userId}
                  onInput={(e: any) => setUserId(e.target.value)}
                  type="text"
                  {...register("user_id", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.user_id ? "error" : ""}
                />
              </div>
            </FormItem>
            <FormItem>
              <div>
                <label htmlFor="password" className="">
                  パスワード
                </label>
                {errors.password && (
                  <span className="mess-error">{errors.password.message as string}</span>
                )}
                <input
                  id="password"
                  type="password"
                  value={password}
                  onInput={(e: any) => setPassword(e.target.value)}
                  {...register("password", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.password ? "error" : ""}
                />
              </div>
            </FormItem>
            <LoginButtonWrapper>
              <Button
                type="primary"
                htmlType="submit"
                disabled={isLoading}
                className="login-button"
              >
                ログイン
              </Button>
            </LoginButtonWrapper>
          </form>
        </Form>
      </LoginWrapper>
    </Spin>
  );
}
