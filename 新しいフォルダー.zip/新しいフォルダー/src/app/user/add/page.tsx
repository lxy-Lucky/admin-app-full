"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout/page";
import { UserRegitButton, ContentWrapper } from "./styles";
import Button from "@/components/Button/page";
import { ROUTES } from "@/constants/routes";
import { useRouter } from "next/navigation";
import { Form, FormItem, CustomeTextArea } from "./styles";
import { useForm } from "react-hook-form";
import { VALIDATION_MESSAGE } from "@/constants/message";
import { FormData, UserRequestInfo } from "../type";
import { CheckBox } from "@/app/styles";
import { add } from "@/services/userService";
import { CommonResponse, MAX_LENGTH, MessageLevel } from "@/constants/common";
import TextAreaCustom from "@/components/TextArea/page";
import { Spin } from "antd";
import Dialog from "@/components/Modal/Dialog";

export default function UserAddPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [errMsg, setErrMsg] = useState("");
  const {
    register,
    handleSubmit,
    watch,
    control,
    formState: { errors },
  } = useForm<FormData>({
    mode: "onSubmit",
    shouldFocusError: true,
    reValidateMode: "onSubmit",
  });

  //エラーメッセージ表示
  const displayError = Object.values(errors)[0]?.message || errMsg;
  const [completeMsg, setCompleteMsg] = useState("");
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);

  //登録処理
  const onSubmit = (formData: FormData) => {
    //フォームデータセット
    const req = createRequestData(formData);

    setIsLoading(true);

    add(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          //戻り先詳細画面に必要なuser_idセット
          sessionStorage.setItem("user_id", req.user_id);
          //完了ダイアログ開く
          setCompleteMsg(data?.message);
          setCompleteDialogOpen(true);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //フォームデータからAPIリクエストオブジェクト変換
  const createRequestData = (formData: FormData): UserRequestInfo => {
    return {
      user_id: formData.user_id,
      user_nm: formData.user_nm,
      email: formData.email,
      admin_permission: formData.admin_permission ? "1" : "0",
      note: formData.note,
    };
  };

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    router.replace(ROUTES.USERUPDATE);
  };

  useEffect(() => {});
  return (
    <Spin classNames={{ root: "spin_loading" }} spinning={isLoading} style={{ maxHeight: "unset" }}>
      <AppLayout>
        <ContentWrapper>
          <Form
            onSubmit={handleSubmit(
              //APIエラークリア
              onSubmit,
              () => {
                setErrMsg("");
              },
            )}
            className="form"
          >
            <div className="err-msg-div">
              {displayError && <span className="mess-error">{displayError as string}</span>}
            </div>
            <FormItem>
              {/* ユーザーID */}
              <div className="label">
                <label htmlFor="user_id">
                  ユーザーID<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <input
                  id="user_id"
                  type="text"
                  maxLength={MAX_LENGTH.MAX_LENGTH_12}
                  {...register("user_id", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.user_id ? "error" : ""}
                />
              </div>
            </FormItem>

            {/* 氏名 */}
            <FormItem>
              <div className="label">
                <label htmlFor="user_name">
                  氏名<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <input
                  id="user_name"
                  type="text"
                  maxLength={MAX_LENGTH.MAX_LENGTH_40}
                  {...register("user_nm", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.user_nm ? "error" : ""}
                />
              </div>
            </FormItem>

            {/* E-mail */}
            <FormItem>
              <div className="label">
                <label htmlFor="email">E-mail</label>
              </div>

              <div className="input">
                <input
                  id="email"
                  type="text"
                  {...register("email", {
                    // pattern: {
                    //     value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                    //     message: VALIDATION_MESSAGE.EMAIL_FORMAT,
                    // },
                  })}
                />
              </div>
            </FormItem>

            {/* システム管理者 */}
            <FormItem>
              <div className="label">
                <label htmlFor="is_kanrisha">システム管理者</label>
              </div>

              <div className="input">
                <CheckBox id="admin_permission" type="checkbox" {...register("admin_permission")} />
              </div>
            </FormItem>

            {/* 備考 */}
            <FormItem>
              <div className="label">
                <label htmlFor="note">備考</label>
              </div>

              <div className="input">
                <TextAreaCustom
                  name={"note"}
                  control={control}
                  value={watch("note") || ""}
                  maxLength={MAX_LENGTH.MAX_LENGTH_500}
                />
              </div>
            </FormItem>

            <UserRegitButton>
              <Button type="primary" htmlType="submit" disabled={isLoading}>
                登録
              </Button>
            </UserRegitButton>
          </Form>

          {/* 登録完了報告ダイアログ */}
          <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
            {completeMsg}
          </Dialog>
        </ContentWrapper>
      </AppLayout>
    </Spin>
  );
}
