"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout/page";
import Button from "@/components/Button/page";
import { ROUTES } from "@/constants/routes";
import { useRouter } from "next/navigation";
import { list } from "@/services/userService";
import { CommonResponse, MessageLevel } from "@/constants/common";
import { SORT_TYPE, UserInfo } from "./type";
import { ButtonWrapper, CheckBox } from "@/app/styles";
import { sorter } from "@/components/Table/utils";
import type { ColumnsType } from "antd/es/table";
import CustomTable from "@/components/Table/page";
import ListPageLayout from "@/components/ListPageLayout/page";
import Link from "next/link";

export default function UserListPage() {
  const router = useRouter();
  const [users, setUsers] = useState<UserInfo[]>([]);
  const [errMsg, setErrMsg] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  const registUser = () => {
    router.replace(ROUTES.USERADD);
  };

  //テーブルカラム
  const columns: ColumnsType<UserInfo> = [
    {
      title: "ユーザーID",
      dataIndex: "user_id",
      key: "user_id",
      width: 180,
      sorter: sorter(SORT_TYPE.USER_ID),
      render: (value: string) => (
        <Link
          href="/user/update"
          onClick={() => {
            sessionStorage.setItem("user_id", value);
          }}
        >
          {value}
        </Link>
      ),
    },

    {
      title: "ユーザー名",
      dataIndex: "user_nm",
      key: "user_nm",
      width: 180,
      sorter: sorter(SORT_TYPE.USER_NAME),
    },

    {
      title: "メールアドレス",
      dataIndex: "email",
      key: "email",
      width: 260,
      sorter: sorter(SORT_TYPE.EMAIL),
    },

    {
      title: "システム管理者",
      dataIndex: "admin_permission",
      key: "admin_permission",
      width: 120,
      sorter: sorter(SORT_TYPE.ADMIN_PERMISSION),

      render: (value, user) => (
        <CheckBox
          id={`admin_permission_${user.user_id}`}
          type="checkbox"
          checked={value === "1"}
          disabled
        />
      ),
    },
    {
      title: "利用停止",
      dataIndex: "lapse_flg",
      key: "lapse_flg",
      width: 100,
      sorter: sorter(SORT_TYPE.LAPSE_FLG),

      render: (value, user) => (
        <CheckBox
          id={`lapse_flag_${user.user_id}`}
          type="checkbox"
          checked={value === "1"}
          disabled
        />
      ),
    },
  ];

  //リスト取得
  useEffect(() => {
    list()
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          setUsers(data.info.return_list);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        console.log("API FINALLY");
        setIsLoading(false);
      });
  }, []);

  return (
    <AppLayout>
      <ListPageLayout
        actions={
          <ButtonWrapper>
            <Button
              type="primary"
              onClick={() => {
                registUser();
              }}
            >
              新規登録
            </Button>
          </ButtonWrapper>
        }
        errorMessage={errMsg}
      >
        <CustomTable
          columns={columns}
          dataSource={users}
          rowKey="user_id"
          stickyHeader
          loading={isLoading}
          size="middle"
        />
      </ListPageLayout>
    </AppLayout>
  );
}
