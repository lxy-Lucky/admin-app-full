//画面フォームデータ
export type FormData = {
  user_id: string;
  user_nm: string;
  email: string;
  admin_permission: boolean;
  note: string;
};

// APIリクエストのオブジェクト
export type UserRequestInfo = {
  user_id: string;
  user_nm: string;
  admin_permission: string;
  email: string;
  note: string;
};

//リストデータ
export type UserInfo = {
  user_id: string;
  user_nm: string;
  admin_permission: string;
  email: string;
  lapse_flg: string;
  note: string;
  update_user_nm: string;
  update_date: string;
};

export enum SORT_TYPE {
  USER_NAME = "user_nm",
  USER_ID = "user_id",
  EMAIL = "email",
  ADMIN_PERMISSION = "admin_permission",
  LAPSE_FLG = "lapse_flg",
}
