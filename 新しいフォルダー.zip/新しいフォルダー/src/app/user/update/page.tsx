"use client";
import { useEffect, useState } from "react";
import AppLayout from "@/components/AppLayout/page";
import Button from "@/components/Button/page";
import { Form, FormItem, CustomeTextArea } from "@/app/user/add/styles";
import { useForm } from "react-hook-form";
import { VALIDATION_MESSAGE } from "@/constants/message";
import { CONFIRM_MESSAGE } from "@/constants/common";
import { FormData, UserInfo, UserRequestInfo } from "@/app/user/type";
import { CheckBox } from "@/app/styles";
import { deleteUser, detail, update } from "@/services/userService";
import { CommonResponse, ELocalStorgeKey, MAX_LENGTH, MessageLevel } from "@/constants/common";
import { ButtonWrapper, ContentWrapper, TextAreaWrapper, UpdateInfoAreaWrapper } from "./styles";
import { ROUTES } from "@/constants/routes";
import { useRouter } from "next/navigation";
import TextAreaCustom from "@/components/TextArea/page";
import { Spin } from "antd";
import LocalStorage from "@/utils/LocalStorage";
import Dialog from "@/components/Modal/Dialog";
import DeleteIcon from "@/components/Icons/DeleteIcon";
import { DeleteMessage } from "@/components/Icons/styles";

export default function UserDetailPage() {
  const router = useRouter();
  //ユーザーID
  const [isLoading, setIsLoading] = useState(false);
  const [errMsg, setErrMsg] = useState("");
  const [data, setData] = useState<UserInfo>();
  const [registData, setRegistData] = useState<UserRequestInfo>();
  const [id, setUserId] = useState("");
  const {
    control,
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors },
  } = useForm<FormData>({
    mode: "onSubmit",
    shouldFocusError: true,
    reValidateMode: "onSubmit",
  });

  //エラーメッセージ表示
  const displayError = Object.values(errors)[0]?.message || errMsg;
  const loginUserInfo = LocalStorage.get(ELocalStorgeKey.USER_INFO);
  const loginUserId = loginUserInfo?.user_id;
  const adminPermission = loginUserInfo?.admin_permission;
  const [deleteConfDialogOpen, setDeleteConfDialogOpen] = useState(false);
  const [updateConfDialogOpen, setUpdateConfDialogOpen] = useState(false);
  const [completeDialogOpen, setCompleteDialogOpen] = useState(false);
  const [completeMsg, setCompleteMsg] = useState("");

  // 修正処理
  const onSubmit = (formData: FormData) => {
    //フォームデータセット
    createRequestData(formData);

    // 修正確認ダイアログ開く
    setUpdateConfDialogOpen(true);
  };

  // 修正確認OKの場合、修正処理
  const handleUpdate = () => {
    if (!registData) return;

    // 修正確認ダイアログ閉じる
    setUpdateConfDialogOpen(false);
    setIsLoading(true);
    //リクエスト作成

    //APIリクエスト
    update(registData)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          // 戻り先詳細画面に必要なuser_idセット
          sessionStorage.setItem("user_id", registData.user_id);
          //完了ダイアログメッセージセット
          setCompleteMsg(data.message);
          //完了ダイアログ開く
          setCompleteDialogOpen(true);
        } else {
          //エラーメッセージセット
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        //エラーメッセージセット
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //削除
  const handleDelete = () => {
    setDeleteConfDialogOpen(false);
    setIsLoading(true);

    //リクエスト作成
    const req: UserRequestInfo = {
      ...emptyUserRequest,
      user_id: id,
    };

    //APIリクエスト
    deleteUser(req)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.ERROR) {
          setErrMsg(data?.message);
        } else {
          //完了ダイアログ開く
          setCompleteDialogOpen(true);
          setCompleteMsg(data.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  //パスワードリセット
  const passwordReset = () => {};

  //詳細
  useEffect(() => {
    const id = sessionStorage.getItem("user_id");

    if (id) {
      setUserId(id);
    }
    setIsLoading(true);
    //リクエスト作成
    const req: UserRequestInfo = {
      ...emptyUserRequest,
      user_id: id!,
    };

    //API
    detail(req)
      .then((res) => {
        const data: CommonResponse = res.data;
        //const userInfo = data?.info;

        if (data?.msg_level === MessageLevel.ERROR) {
          setErrMsg(data?.message);
        } else {
          setData(data.info);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);

  //APIユーザーデータを画面上セット
  useEffect(() => {
    if (data) {
      reset({
        user_id: data.user_id,
        user_nm: data.user_nm,
        email: data.email,
        admin_permission: data.admin_permission === "1" ? true : false,
        note: data.note,
      });
    }
  }, [data, reset]);

  //報告ダイアログ閉じる
  const closeConfDialog = () => {
    setCompleteDialogOpen(false);
    router.replace(ROUTES.USERUPDATE);
  };

  //フォームデータからAPIリクエストオブジェクト変換
  const createRequestData = (formData: FormData) => {
    const req: UserRequestInfo = {
      user_id: formData.user_id,
      user_nm: formData.user_nm,
      email: formData.email,
      admin_permission: formData.admin_permission ? "1" : "0",
      note: formData.note,
    };

    setRegistData(req);
  };

  //
  const emptyUserRequest: UserRequestInfo = {
    user_id: id,
    user_nm: "",
    email: "",
    admin_permission: "",
    note: "",
  };

  return (
    <Spin classNames={{ root: "spin_loading" }} spinning={isLoading} style={{ maxHeight: "unset" }}>
      <AppLayout>
        {data && (
          <UpdateInfoAreaWrapper>
            <label htmlFor="update_user_nm">修正者：{data?.update_user_nm}</label>
            <br />
            <label htmlFor="update_date">修正日：{data?.update_date}</label>
          </UpdateInfoAreaWrapper>
        )}
        <ContentWrapper>
          <Form
            onSubmit={handleSubmit(
              //APIエラークリア
              onSubmit,
              () => {
                setErrMsg("");
              },
            )}
            className="form"
          >
            <div className="err-msg-div">
              {displayError && <span className="mess-error">{displayError as string}</span>}
            </div>
            <FormItem>
              {/* ユーザーID */}
              <div className="label">
                <label htmlFor="user_id">
                  ユーザーID<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <input
                  id="user_id"
                  type="text"
                  disabled={true}
                  {...register("user_id", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.user_id ? "error" : ""}
                />
              </div>
            </FormItem>

            {/* 氏名 */}
            <FormItem>
              <div className="label">
                <label htmlFor="user_name">
                  氏名<span className="required">※</span>
                </label>
              </div>

              <div className="input">
                <input
                  id="user_name"
                  type="text"
                  maxLength={MAX_LENGTH.MAX_LENGTH_40}
                  {...register("user_nm", {
                    required: {
                      value: true,
                      message: VALIDATION_MESSAGE.REQUIRED_FIELD,
                    },
                  })}
                  className={errors.user_nm ? "error" : ""}
                />
              </div>
            </FormItem>

            {/* E-mail */}
            <FormItem>
              <div className="label">
                <label htmlFor="email">E-mail</label>
              </div>

              <div className="input">
                <input id="email" type="text" {...register("email")} />
              </div>
            </FormItem>

            {/* システム管理者 */}
            <FormItem>
              <div className="label">
                <label htmlFor="is_kanrisha">システム管理者</label>
              </div>

              <div className="input">
                <CheckBox id="admin_permission" type="checkbox" {...register("admin_permission")} />
              </div>
            </FormItem>

            {/* 備考 */}
            <FormItem>
              <div className="label">
                <label htmlFor="note">備考</label>
              </div>

              <TextAreaWrapper>
                <TextAreaCustom
                  name={"note"}
                  control={control}
                  errorMessage={errors?.note?.message?.toString()}
                  value={watch("note") || ""}
                  maxLength={MAX_LENGTH.MAX_LENGTH_500}
                />
              </TextAreaWrapper>
            </FormItem>

            {/* パスワードリセット */}
            <FormItem>
              <div className="label">
                <label htmlFor="passord-reset">パスワードリセット</label>
              </div>
              <div className="input">
                <Button
                  type="primary"
                  typeButton="gray"
                  htmlType="button"
                  disabled={isLoading}
                  className="right-align-btn"
                  onClick={passwordReset}
                >
                  リセット
                </Button>
              </div>
            </FormItem>
            <ButtonWrapper>
              <Button type="primary" typeButton="green" htmlType="submit" disabled={isLoading}>
                修正
              </Button>
              <Button
                type="primary"
                typeButton="gray"
                htmlType="button"
                className="right-align-btn"
                onClick={() => setDeleteConfDialogOpen(true)}
                disabled={id === loginUserId || adminPermission === "0"}
              >
                削除
              </Button>
            </ButtonWrapper>
          </Form>

          {/* 修正確認ダイアログ */}
          <Dialog
            mode="update"
            open={updateConfDialogOpen}
            onClose={() => setUpdateConfDialogOpen(false)}
            onConfirm={handleUpdate}
            confirmText="OK"
            cancelText="キャンセル"
            showCancel={true}
          >
            <p>{CONFIRM_MESSAGE.UPDATE_MSG}</p>
          </Dialog>

          {/* 削除確認ダイアログ */}
          <Dialog
            mode="delete"
            open={deleteConfDialogOpen}
            onClose={() => setDeleteConfDialogOpen(false)}
            onConfirm={handleDelete}
            confirmText="削除"
            cancelText="キャンセル"
            showCancel={true}
          >
            <DeleteMessage>
              <DeleteIcon size={26} />
              <span>{CONFIRM_MESSAGE.DELETE_MSG}</span>
            </DeleteMessage>
          </Dialog>

          {/* 処理完了ダイアログ */}
          <Dialog open={completeDialogOpen} onClose={closeConfDialog}>
            {completeMsg}
          </Dialog>
        </ContentWrapper>
      </AppLayout>
    </Spin>
  );
}
