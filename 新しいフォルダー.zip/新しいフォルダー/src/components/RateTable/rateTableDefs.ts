import type { AxiosResponse } from "axios";
import type { ColumnsType } from "antd/es/table";
import { CommonResponse } from "@/constants/common";
import { ERROR_MESSAGE } from "@/constants/message";
import {
  getSummaryChangeRateList,
  getSummaryEnrollRateList,
  updateChangeRateList,
  updateEnrollRateList,
} from "@/services/infantSummaryRatesService";
import { getElemChangeRateList, updateElemChangeRateList } from "@/services/elemChangeRatesService";
import { getJhsChangeRateList, updateJhsChangeRateList } from "@/services/jhsChangeRatesService";
import { EnrolRateList, InfantChangeRates } from "@/app/infant-summary-rates/type";
import { ElemChangeRates } from "@/app/elem-change-rates/type";
import { JhsChangeRates } from "@/app/jhs-change-rates/type";
import { RateEditStore } from "./rateEditStore";
import { countColumn, RateColumnKeys, rateColumns, schoolColumns } from "./rateColumns";
import { RateListReqInfo, RateRow } from "./type";

// 率表（幼児増減率表・就学率表・小学校増減率表・中学校増減率表）ごとの定義
// ※一覧取得・修正登録の処理（useRateTable）は共通で、表ごとに違う部分（API・項目名・列）だけをここで定義する

/** 率表の定義 */
export type RateTableDef<T extends RateRow> = {
  /** 行のデータIDの項目名（テーブルのrowKey） */
  rowKey: keyof T & string;
  /** データが無い（集計未実行）場合に、BEからメッセージが返らなかった時の注意メッセージ */
  noDataMessage: string;
  /** 行のデータID */
  getId(row: T): string;
  /** 行のその他率（画面で手入力した率） */
  getMiscRate(row: T): number | null;
  /** 一覧取得 */
  getList(req: RateListReqInfo): Promise<AxiosResponse<CommonResponse>>;
  /** 修正登録（表示中ページの全行の採用率・その他率・備考を送る） */
  update(year: number, list: T[], store: RateEditStore): Promise<AxiosResponse<CommonResponse>>;
  /** 一覧の列 */
  columns(year: number, store: RateEditStore): ColumnsType<T>;
};

/**
 * 率表の定義を作る
 * ※定義は表ごとの型（T）で型チェックし、共通処理（useRateTable）には共通の行の型（RateRow）として渡す
 *   （共通処理は行を表ごとの定義の関数にそのまま渡すだけなので、型を共通化しても問題ない）
 */
const defineRateTable = <T extends RateRow>(def: RateTableDef<T>) =>
  def as unknown as RateTableDef<RateRow>;

/** 増減率（4年前～今年）・3年平均・5年平均の列の項目名（幼児・小学校・中学校増減率表で共通） */
const CHANGE_RATE_KEYS: RateColumnKeys = {
  history: [
    "change_rate_4y_ago",
    "change_rate_3y_ago",
    "change_rate_2y_ago",
    "change_rate_1y_ago",
    "change_rate_this_year",
  ],
  avg3: "avg3_change_rate",
  avg5: "avg5_change_rate",
};

/** 就学率（4年前～今年）・3年平均・5年平均の列の項目名 */
const ENROL_RATE_KEYS: RateColumnKeys = {
  history: [
    "enrol_rate_4y_ago",
    "enrol_rate_3y_ago",
    "enrol_rate_2y_ago",
    "enrol_rate_1y_ago",
    "enrol_rate_this_year",
  ],
  avg3: "avg3_enrol_rate",
  avg5: "avg5_enrol_rate",
};

/** 幼児増減率表 */
export const INFANT_CHANGE_RATE_TABLE = defineRateTable<InfantChangeRates>({
  rowKey: "infant_change_rates_id",
  noDataMessage: ERROR_MESSAGE.ANBURITSU_NOT_EXECUTED_MESSAGE,
  getId: (row) => row.infant_change_rates_id,
  getMiscRate: (row) => row.misc_change_rate,
  getList: (req) => getSummaryChangeRateList(req),
  update: (year, list, store) =>
    updateChangeRateList({
      year: year,
      update_list: list.map((row) => {
        const edit = store.get(row.infant_change_rates_id);
        return {
          infant_change_rates_id: row.infant_change_rates_id,
          adopt_rate_kbn: edit.adopt_rate_kbn,
          // その他率は、その他を選んでいなくても入力値を保存する
          misc_change_rate: edit.other_rate,
          note: edit.note,
        };
      }),
    }),
  columns: (year, store) => [
    ...schoolColumns<InfantChangeRates>(),
    ...[0, 1, 2, 3, 4].map((age) =>
      countColumn<InfantChangeRates>(`昨年度${age}歳児`, `last_year_age_${age}`, 110),
    ),
    countColumn<InfantChangeRates>("昨年度計", "last_year_total"),
    ...[1, 2, 3, 4, 5].map((age) =>
      countColumn<InfantChangeRates>(`今年度${age}歳児`, `this_year_age_${age}`, 110),
    ),
    countColumn<InfantChangeRates>("今年度計", "this_year_total"),
    ...rateColumns<InfantChangeRates>(
      year,
      store,
      (row) => row.infant_change_rates_id,
      CHANGE_RATE_KEYS,
    ),
  ],
});

/** 幼児就学率表 */
export const INFANT_ENROL_RATE_TABLE = defineRateTable<EnrolRateList>({
  rowKey: "infant_enrolment_rates_id",
  noDataMessage: ERROR_MESSAGE.ANBURITSU_NOT_EXECUTED_MESSAGE,
  getId: (row) => row.infant_enrolment_rates_id,
  getMiscRate: (row) => row.misc_enrol_rate,
  getList: (req) => getSummaryEnrollRateList(req),
  update: (year, list, store) =>
    updateEnrollRateList({
      year: year,
      update_list: list.map((row) => {
        const edit = store.get(row.infant_enrolment_rates_id);
        return {
          infant_enrolment_rates_id: row.infant_enrolment_rates_id,
          adopt_rate_kbn: edit.adopt_rate_kbn,
          // その他率は、その他を選んでいなくても入力値を保存する
          misc_enrol_rate: edit.other_rate,
          note: edit.note,
        };
      }),
    }),
  columns: (year, store) => [
    ...schoolColumns<EnrolRateList>(),
    countColumn<EnrolRateList>("昨年度5歳児", "count_age_5", 110),
    countColumn<EnrolRateList>("今年度小1", "students_1"),
    ...rateColumns<EnrolRateList>(
      year,
      store,
      (row) => row.infant_enrolment_rates_id,
      ENROL_RATE_KEYS,
    ),
  ],
});

/** 小学校増減率表 */
export const ELEM_CHANGE_RATE_TABLE = defineRateTable<ElemChangeRates>({
  rowKey: "elem_change_rates_id",
  noDataMessage: ERROR_MESSAGE.NOT_EXECUTED_MESSAGE,
  getId: (row) => row.elem_change_rates_id,
  getMiscRate: (row) => row.misc_change_rate,
  getList: (req) => getElemChangeRateList(req),
  update: (year, list, store) =>
    updateElemChangeRateList({
      year: year,
      update_list: list.map((row) => {
        const edit = store.get(row.elem_change_rates_id);
        return {
          elem_change_rates_id: row.elem_change_rates_id,
          adopt_rate_kbn: edit.adopt_rate_kbn,
          // その他率は、その他を選んでいなくても入力値を保存する
          misc_change_rate: edit.other_rate,
          note: edit.note,
        };
      }),
    }),
  columns: (year, store) => [
    ...schoolColumns<ElemChangeRates>(),
    ...[1, 2, 3, 4, 5].map((grade) =>
      countColumn<ElemChangeRates>(`昨年度小${grade}`, `last_year_students_${grade}`),
    ),
    countColumn<ElemChangeRates>("昨年度計", "last_year_total"),
    ...[2, 3, 4, 5, 6].map((grade) =>
      countColumn<ElemChangeRates>(`今年度小${grade}`, `this_year_students_${grade}`),
    ),
    countColumn<ElemChangeRates>("今年度計", "this_year_total"),
    ...rateColumns<ElemChangeRates>(
      year,
      store,
      (row) => row.elem_change_rates_id,
      CHANGE_RATE_KEYS,
    ),
  ],
});

/** 中学校増減率表 */
export const JHS_CHANGE_RATE_TABLE = defineRateTable<JhsChangeRates>({
  rowKey: "jhs_change_rates_id",
  noDataMessage: ERROR_MESSAGE.NOT_EXECUTED_MESSAGE,
  getId: (row) => row.jhs_change_rates_id,
  getMiscRate: (row) => row.misc_change_rate,
  getList: (req) => getJhsChangeRateList(req),
  update: (year, list, store) =>
    updateJhsChangeRateList({
      year: year,
      update_list: list.map((row) => {
        const edit = store.get(row.jhs_change_rates_id);
        return {
          jhs_change_rates_id: row.jhs_change_rates_id,
          adopt_rate_kbn: edit.adopt_rate_kbn,
          // その他率は、その他を選んでいなくても入力値を保存する
          misc_change_rate: edit.other_rate,
          note: edit.note,
        };
      }),
    }),
  columns: (year, store) => [
    ...schoolColumns<JhsChangeRates>(),
    ...[1, 2].map((grade) =>
      countColumn<JhsChangeRates>(`昨年度中${grade}`, `last_year_jhs${grade}_students`),
    ),
    countColumn<JhsChangeRates>("昨年度計", "last_year_jhs_total"),
    ...[2, 3].map((grade) =>
      countColumn<JhsChangeRates>(`今年度中${grade}`, `this_year_jhs${grade}_students`),
    ),
    countColumn<JhsChangeRates>("今年度計", "this_year_jhs_total"),
    ...rateColumns<JhsChangeRates>(
      year,
      store,
      (row) => row.jhs_change_rates_id,
      CHANGE_RATE_KEYS,
    ),
  ],
});
