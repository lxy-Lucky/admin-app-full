// 率表（幼児増減率表・就学率表・小学校増減率表）で共通の型

/** 採用率区分（どの率をラジオボタンで選択したか）
 *  ※未選択の場合はnull */
export const ADOPT_RATE_KBN = {
  /** 3年平均 */
  AVG3: "1",
  /** 5年平均 */
  AVG5: "2",
  /** その他（手入力の率） */
  OTHER: "9",
} as const;

export type AdoptRateKbn = (typeof ADOPT_RATE_KBN)[keyof typeof ADOPT_RATE_KBN];

/** 率表リスト取得のリクエスト情報 */
export type RateListReqInfo = {
  /** 対象年度 */
  year: number;
  /** ページサイズ（一覧における1ページの表示件数。0または未指定で全件） */
  page_size?: number;
  /** 現在表示ページ */
  current_page?: number;
};

/** 率表リストの1行（各率表で共通の項目）
 *  ※率表ごとの項目（人数・率・データID等）はRecordとして持つ */
export type RateRow = Record<string, unknown> & {
  /** 学校名 */
  school_nm: string;
  /** 前年採用率 */
  last_year_rate: number | null;
  /** 本年採用率（ラジオボタンで選択した率の値） */
  this_year_rate: number | null;
  /** 採用率区分（未選択の場合はnull） */
  adopt_rate_kbn: AdoptRateKbn | null;
  /** 備考 */
  note: string | null;
};

/** 率表リスト取得のレスポンス情報（info）
 *  ※データが無い（集計未実行）場合はinfo=nullが返る */
export type RateListInfo<T> = {
  /** 対象年度 */
  year: number;
  /** ページサイズ（0=全件） */
  page_size: number;
  /** 現在表示ページ */
  current_page: number;
  /** 総件数 */
  total_size: number;
  /** 更新日時（BEは「yyyy/MM/dd HH:mm:ss」形式で返す） */
  update_date: string | null;
  /** 更新者ID */
  update_user_id: string | null;
  /** 更新者名 */
  update_user_nm: string | null;
  /** リスト */
  return_list: T[];
};

/** 率表 修正登録のリクエスト情報（1行分の共通項目） */
export type RateUpdateValues = {
  /** 採用率区分（未選択の場合はnull） */
  adopt_rate_kbn: AdoptRateKbn | null;
  /** 備考 */
  note: string;
};

/** 率表 修正登録のリクエスト情報 */
export type RateUpdateReqInfo<T> = {
  /** 対象年度 */
  year: number;
  /** 修正内容（表示中ページの全行） */
  update_list: T[];
};
