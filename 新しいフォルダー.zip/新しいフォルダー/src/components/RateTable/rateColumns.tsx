"use client";

import type { ColumnsType } from "antd/es/table";
import { numberSorter, sorter } from "@/components/Table/utils";
import { RateEditStore } from "./rateEditStore";
import { AvgRateCell, NoteCell, OtherRateCell } from "./RateEditCells";
import { ADOPT_RATE_KBN, AdoptRateKbn } from "./type";

// 率表（幼児増減率表・就学率表・小学校増減率表）で共通の列定義

/** 率を小数第3位まで表示する（値が無い場合は空欄） */
export const renderRate = (value: number | null) => (value == null ? "" : value.toFixed(3));

/** 率の列見出し（例：2040年度の今年 → 「R22率」）
 *  @param year 対象年度
 *  @param yearsAgo 何年前の率か（今年=0） */
const rateTitle = (year: number, yearsAgo: number) => `R${year - 2018 - yearsAgo}率`;

/** 数値の列のセル（右寄せ） */
const numberCell = () => ({ className: "rate-cell" });

/** 区コード・学校コード・学校名の列 */
export const schoolColumns = <T extends Record<string, unknown>>(): ColumnsType<T> => [
  {
    title: "区コード",
    dataIndex: "ward_code",
    key: "ward_code",
    width: 90,
    sorter: sorter("ward_code"),
  },
  {
    title: "学校コード",
    dataIndex: "school_code",
    key: "school_code",
    width: 100,
    sorter: sorter("school_code"),
  },
  {
    title: "学校名",
    dataIndex: "school_nm",
    key: "school_nm",
    width: 140,
    sorter: sorter("school_nm"),
  },
];

/** 人数の列（右寄せ・数値ソート） */
export const countColumn = <T extends Record<string, unknown>>(
  title: string,
  dataIndex: string,
  width = 100,
): ColumnsType<T>[number] => ({
  title,
  dataIndex,
  key: dataIndex,
  width,
  sorter: numberSorter(dataIndex),
  onCell: numberCell,
});

/** 率の列の項目名（率表ごとに項目名だけが違う） */
export type RateColumnKeys = {
  /** 4年前・3年前・2年前・1年前・今年の率 */
  history: readonly [string, string, string, string, string];
  /** 3年平均 */
  avg3: string;
  /** 5年平均 */
  avg5: string;
};

/**
 * 率（4年前～今年）・3平均・5平均・その他率・前年採用率・備考の列
 * ※3平均・5平均・その他率・備考は、編集内容をstoreから取得する（操作した行だけ再描画するため）
 * @param getId 行のデータID（増減率表データID／就学率表データID／小学校増減率表データID）
 */
export const rateColumns = <T extends Record<string, unknown> & { last_year_rate: number | null }>(
  year: number,
  store: RateEditStore,
  getId: (record: T) => string,
  keys: RateColumnKeys,
): ColumnsType<T> => {
  /** 平均値（3年平均・5年平均）を採用するラジオボタンの列 */
  const avgRateColumn = (title: string, dataIndex: string, kbn: AdoptRateKbn) => ({
    title,
    dataIndex,
    key: dataIndex,
    width: 110,
    sorter: numberSorter(dataIndex),
    onCell: numberCell,
    render: (value: number | null, record: T) => (
      <AvgRateCell
        store={store}
        id={getId(record)}
        kbn={kbn}
        value={value}
        label={renderRate(value)}
      />
    ),
  });

  return [
    ...keys.history.map((dataIndex, index) => ({
      title: rateTitle(year, keys.history.length - 1 - index),
      dataIndex,
      key: dataIndex,
      width: 90,
      sorter: numberSorter(dataIndex),
      onCell: numberCell,
      render: renderRate,
    })),
    avgRateColumn("3平均", keys.avg3, ADOPT_RATE_KBN.AVG3),
    avgRateColumn("5平均", keys.avg5, ADOPT_RATE_KBN.AVG5),
    {
      // 手入力値は画面上の編集内容のため、ソート対象外
      title: "その他率",
      key: "other_rate",
      width: 150,
      onCell: numberCell,
      render: (_: unknown, record: T) => <OtherRateCell store={store} id={getId(record)} />,
    },
    {
      title: "前年採用率",
      dataIndex: "last_year_rate",
      key: "last_year_rate",
      width: 110,
      sorter: numberSorter("last_year_rate"),
      onCell: numberCell,
      render: renderRate,
    },
    {
      title: "備考",
      key: "note",
      width: 280,
      render: (_: unknown, record: T) => <NoteCell store={store} id={getId(record)} />,
    },
  ];
};
