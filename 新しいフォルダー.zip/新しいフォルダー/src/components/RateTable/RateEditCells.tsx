"use client";

import { memo } from "react";
import { Input, InputNumber, Radio } from "antd";
import { RateEditStore, useRateEdit } from "./rateEditStore";
import { ADOPT_RATE_KBN, AdoptRateKbn } from "./type";

// 率表（幼児増減率表・就学率表・小学校増減率表）の編集用セル
// ※各セルは自分の行の編集内容だけを購読するため、操作した行のセルだけが再描画される

/** 選択中の率のセルに付けるクラス（styles.tsで黄色に塗る） */
const selectedClass = (selected: boolean) => (selected ? "adopt-rate-selected" : undefined);

type AvgRateCellProps = {
  store: RateEditStore;
  id: string;
  kbn: AdoptRateKbn;
  /** 平均値（3年平均・5年平均） */
  value: number | null;
  /** 表示用の値（小数第3位まで） */
  label: string;
};

/** 平均値（3年平均・5年平均）を採用するラジオボタン */
export const AvgRateCell = memo(function AvgRateCell({
  store,
  id,
  kbn,
  value,
  label,
}: AvgRateCellProps) {
  const edit = useRateEdit(store, id);
  const selected = edit.adopt_rate_kbn === kbn;

  return (
    <span className={selectedClass(selected)}>
      <Radio
        checked={selected}
        // 平均値が無い場合は採用できない
        disabled={value == null}
        onChange={() => store.update(id, { adopt_rate_kbn: kbn, this_year_rate: value })}
      >
        {label}
      </Radio>
    </span>
  );
});

type OtherRateCellProps = {
  store: RateEditStore;
  id: string;
};

/** その他率（手入力）を採用するラジオボタン */
export const OtherRateCell = memo(function OtherRateCell({ store, id }: OtherRateCellProps) {
  const edit = useRateEdit(store, id);
  const selected = edit.adopt_rate_kbn === ADOPT_RATE_KBN.OTHER;

  return (
    <span className={selectedClass(selected)}>
      <Radio
        checked={selected}
        onChange={() =>
          store.update(id, {
            adopt_rate_kbn: ADOPT_RATE_KBN.OTHER,
            this_year_rate: edit.other_rate,
          })
        }
      >
        <InputNumber
          size="small"
          style={{ width: 80 }}
          // DBはdecimal(5,3)のため、整数部2桁・小数第3位まで
          min={0}
          max={99.999}
          step={0.001}
          precision={3}
          value={edit.other_rate}
          // 率を入力したら「その他」を選択したものとする
          onChange={(rate) =>
            store.update(id, {
              adopt_rate_kbn: ADOPT_RATE_KBN.OTHER,
              other_rate: rate,
              this_year_rate: rate,
            })
          }
        />
      </Radio>
    </span>
  );
});

type NoteCellProps = {
  store: RateEditStore;
  id: string;
};

/** 備考 */
export const NoteCell = memo(function NoteCell({ store, id }: NoteCellProps) {
  const edit = useRateEdit(store, id);

  return (
    <Input
      size="small"
      maxLength={300}
      value={edit.note}
      onChange={(e) => store.update(id, { note: e.target.value })}
    />
  );
});
