import { useEffect, useMemo, useState } from "react";
import { usePagination } from "@/components/Table/pagination";
import { CommonResponse, MessageLevel } from "@/constants/common";
import { createRateEditStore } from "./rateEditStore";
import { RateTableDef } from "./rateTableDefs";
import { ADOPT_RATE_KBN, RateListInfo, RateRow } from "./type";

/**
 * 率表（幼児増減率表・就学率表・小学校増減率表）の一覧表示・修正登録の共通処理
 * ・表示する表（table）または年度が変わると、一覧を取得し直す
 * ・メッセージ・ローディングは画面の他の処理（集計実行・印刷など）でも使うため、setterも返す
 * @param table 表示する率表の定義（rateTableDefs）
 * @param year 対象年度
 */
export const useRateTable = (table: RateTableDef<RateRow>, year: number) => {
  // 率表リスト。データが無い場合は空配列
  // ※画面での編集内容はEditStoreで持つ（このリストは編集しない）
  const [list, setList] = useState<RateRow[]>([]);
  // 編集内容（採用率・その他率・備考）
  const [store] = useState(createRateEditStore);
  // 最終更新情報。データが無い場合はnull
  const [updateInfo, setUpdateInfo] = useState<RateListInfo<RateRow> | null>(null);

  const [errMsg, setErrMsg] = useState("");
  // 集計未実行など、エラーではないが利用者に対応を促すメッセージ（msg_level=WARN相当）
  const [warnMsg, setWarnMsg] = useState("");
  // 初期表示時に必ず一覧を取得するため、初期値はtrue
  const [isLoading, setIsLoading] = useState(true);

  // ページネーション（BE側でページ分のみ返却されるため、ページ状態をここで管理する）
  const {
    currentPage,
    pageSize,
    totalRecord,
    setCurrentPage,
    setTotalRecord,
    handlePaginationChange,
  } = usePagination({});

  // 一覧の列
  const columns = useMemo(() => table.columns(year, store), [table, year, store]);

  // 一覧にデータがあるか
  const hasListData = list.length > 0;

  //画面に表示されるメッセージをクリア
  const clearMessage = () => {
    setErrMsg("");
    setWarnMsg("");
  };

  // 率表リストを画面に反映する（info=nullの場合は空にする）
  const applyInfo = (info: RateListInfo<RateRow> | null) => {
    const rows = info?.return_list ?? [];
    // 編集内容は取得したリストの値で初期化する
    store.reset(
      rows.map((row) => ({ ...row, id: table.getId(row), misc_rate: table.getMiscRate(row) })),
    );
    setList(rows);
    setUpdateInfo(info);
    // 総件数（データ無しの場合は0件）
    setTotalRecord(info?.total_size ?? 0);
  };

  // 率表リスト取得
  // ※ローディング開始・メッセージのクリアは呼び出し側で行う
  const fetchList = (page: number, size: number) => {
    return table
      .getList({ year: year, current_page: page, page_size: size })
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO || data?.msg_level === MessageLevel.WARN) {
          // データが無い（集計未実行）場合はinfo=null
          const info: RateListInfo<RateRow> | null = data.info ?? null;

          applyInfo(info);
          // データ無し（info=null）の場合のみ注意メッセージを表示する
          setWarnMsg(info ? "" : data?.message || table.noDataMessage);
        } else {
          // エラー時は前回の一覧・件数を残さない
          applyInfo(null);
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        applyInfo(null);
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  // 初期表示および年度・表示する表の変更時に一覧を取得する
  // （メッセージのクリア・ローディング開始はprepareReloadで行うため、ここでは取得のみを行う）
  useEffect(() => {
    fetchList(currentPage, pageSize);
    // ページの変更はonPaginationChangeで取得するため、ここでは年度・表示する表の変更時のみ実行する
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, table]);

  /** 年度・表示する表を変更する前に呼ぶ
   *  取得完了まで変更前の一覧・メッセージを残さず、1ページ目から表示し直す
   *  ※表を変更すると列も変わるため、変更前の表の行は残さない */
  const prepareReload = () => {
    clearMessage();
    applyInfo(null);
    setIsLoading(true);
    setCurrentPage(1);
  };

  // ページ番号・ページサイズ変更時はBEから該当ページを取得し直す
  // ※未登録の編集内容は、取得し直したページの値で上書きされる
  const onPaginationChange = (page: number, size: number) => {
    handlePaginationChange(page, size, (nextPage, nextSize) => {
      clearMessage();
      setIsLoading(true);
      fetchList(nextPage, nextSize);
    });
  };

  /** 表示中のページを取得し直す（修正登録・集計実行の完了後など） */
  const reload = () => {
    clearMessage();
    setIsLoading(true);
    fetchList(currentPage, pageSize);
  };

  /** 修正登録前の入力チェック。入力漏れがあればエラーを表示してfalseを返す */
  const validateUpdate = () => {
    clearMessage();

    const noRateRow = list.find((row) => {
      const edit = store.get(table.getId(row));
      return edit.adopt_rate_kbn === ADOPT_RATE_KBN.OTHER && edit.other_rate == null;
    });
    if (noRateRow) {
      setErrMsg(
        `その他を選択した場合は、その他率を入力してください（学校名：${noRateRow.school_nm}）`,
      );
      return false;
    }
    return true;
  };

  /** 修正登録（表示中ページの全行の採用率・その他率・備考を送る）
   *  @param onSuccess 登録成功時の処理（完了メッセージを受け取る） */
  const update = (onSuccess: (message: string) => void) => {
    clearMessage();
    setIsLoading(true);

    table
      .update(year, list, store)
      .then((res) => {
        const data: CommonResponse = res.data;

        if (data?.msg_level === MessageLevel.INFO) {
          onSuccess(data.message);
        } else {
          setErrMsg(data?.message);
        }
      })
      .catch((err) => {
        setErrMsg(err.message);
      })
      .finally(() => {
        setIsLoading(false);
      });
  };

  return {
    list,
    columns,
    updateInfo,
    hasListData,
    errMsg,
    setErrMsg,
    warnMsg,
    setWarnMsg,
    isLoading,
    setIsLoading,
    clearMessage,
    currentPage,
    pageSize,
    totalRecord,
    onPaginationChange,
    prepareReload,
    reload,
    validateUpdate,
    update,
  };
};
