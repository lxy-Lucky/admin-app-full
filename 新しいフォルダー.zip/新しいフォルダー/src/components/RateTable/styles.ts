import styled from "styled-components";

// 率表の一覧。採用している率のセルを黄色で塗る（Excelの運用に合わせる）
// ※選択状態はセル内の要素（RateEditCells）が持つため、:hasでセル（td）ごと塗る
export const RateTableWrapper = styled.div`
  .ant-table-tbody > tr > td:has(.adopt-rate-selected) {
    background: ${(props) => props.theme.colors.light_yellow1};
  }

  .ant-table-tbody > tr > td.rate-cell {
    text-align: right;
    white-space: nowrap;
  }
`;
