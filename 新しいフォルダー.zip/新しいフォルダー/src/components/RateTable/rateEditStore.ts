import { useSyncExternalStore } from "react";
import { AdoptRateKbn } from "./type";

/** 率表（幼児増減率表・就学率表・小学校増減率表）の1行分の編集内容 */
export type RateEdit = {
  /** 採用率区分（未選択の場合はnull） */
  adopt_rate_kbn: AdoptRateKbn | null;
  /** 本年採用率（ラジオボタンで選択した率の値） */
  this_year_rate: number | null;
  /** その他率（手入力値。DBのMISC_CHANGE_RATE／MISC_ENROL_RATE）
   *  ※小学校増減率表もMISC_CHANGE_RATE
   *  ※他の率を選んでいても保存されるよう、本年採用率とは別に持つ */
  other_rate: number | null;
  /** 備考 */
  note: string;
};

/** 編集内容の初期値（取得したリストの1行から作る） */
export type RateEditSource = {
  /** データID（増減率表データID／就学率表データID／小学校増減率表データID） */
  id: string;
  adopt_rate_kbn: AdoptRateKbn | null;
  this_year_rate: number | null;
  /** その他率（増減率表・小学校増減率表はmisc_change_rate、就学率表はmisc_enrol_rate） */
  misc_rate: number | null;
  note: string | null;
};

/** 編集内容が無い行（リスト取得前など）用 */
const EMPTY_EDIT: RateEdit = {
  adopt_rate_kbn: null,
  this_year_rate: null,
  other_rate: null,
  note: "",
};

/**
 * 率表の編集内容を保持するストア
 *
 * 編集内容を一覧のデータ（テーブルのdataSource）に持たせると、1行の変更でも
 * テーブル全体が再描画され、件数が多いと操作のたびに画面が固まる。
 * そのため編集内容はここで行IDごとに持ち、変更した行のセルにだけ通知する。
 */
export const createRateEditStore = () => {
  let edits = new Map<string, RateEdit>();
  const listeners = new Map<string, Set<() => void>>();

  const notify = (id: string) => listeners.get(id)?.forEach((listener) => listener());

  const get = (id: string): RateEdit => edits.get(id) ?? EMPTY_EDIT;

  return {
    /** 取得したリストで編集内容を初期化する */
    reset(list: RateEditSource[]) {
      edits = new Map(
        list.map((item) => [
          item.id,
          {
            adopt_rate_kbn: item.adopt_rate_kbn,
            this_year_rate: item.this_year_rate,
            other_rate: item.misc_rate,
            note: item.note ?? "",
          },
        ]),
      );
      listeners.forEach((_, id) => notify(id));
    },

    /** 1行分の編集内容を取得する */
    get,

    /** 1行分の編集内容を更新し、その行のセルにだけ通知する */
    update(id: string, patch: Partial<RateEdit>) {
      edits.set(id, { ...get(id), ...patch });
      notify(id);
    },

    /** 1行分の編集内容の変更を購読する */
    subscribe(id: string, listener: () => void) {
      const set = listeners.get(id) ?? new Set();
      set.add(listener);
      listeners.set(id, set);

      return () => {
        set.delete(listener);
        if (set.size === 0) {
          listeners.delete(id);
        }
      };
    },
  };
};

export type RateEditStore = ReturnType<typeof createRateEditStore>;

/** 1行分の編集内容を参照する（その行が変更された時だけ再描画される） */
export const useRateEdit = (store: RateEditStore, id: string): RateEdit =>
  useSyncExternalStore(
    (listener) => store.subscribe(id, listener),
    () => store.get(id),
    () => store.get(id),
  );
