"use client";

import { Controller, Control, FieldPathValues, FieldValues, Path } from "react-hook-form";
import { Upload, Button } from "antd";
import type { UploadFile, UploadProps } from "antd";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
import { VALIDATION_MESSAGE } from "@/constants/message";

type FileUploaderProps<T extends FieldValues> = {
  name: Path<T>;
  control: Control<T>;
  accept?: string;
  maxCount?: number;
  disabled?: boolean;
  downloadOnly?: boolean;
  fileName?: string;
  onDownload?: () => void;
};

const FileUploader = <T extends FieldValues>({
  name,
  control,
  accept,
  maxCount = 1,
  disabled = false,
  downloadOnly = false,
  fileName,
  onDownload,
}: FileUploaderProps<T>) => {
  return (
    <Controller
      name={name}
      control={control}
      rules={{
        validate: {
          required: (value) => {
            if (value?.length <= 0) {
              return VALIDATION_MESSAGE.REQUIRED_FILE;
            }
          },

          maxFileSize: (value) => {
            const MAX_FILE_SIZE = 100 * 1024 * 1024; //ファイルサイズは100MBを超えるとエラー表示

            const file = value?.[0];

            if (!file) return true;

            if ((name == null && !file) || file.size === undefined) {
              return VALIDATION_MESSAGE.REQUIRED_FILE;
            }

            if (file.size > MAX_FILE_SIZE) {
              return VALIDATION_MESSAGE.FILE_SIZE_ERROR;
            }
          },
        },
      }}
      render={({ field, fieldState }) => {
        const fileList: UploadFile[] = field.value ?? [];
        const handleChange: UploadProps["onChange"] = (info) => {
          const newFileList = info.fileList.slice(-maxCount);
          field.onChange(newFileList);
        };

        const beforeUpload: UploadProps["beforeUpload"] = () => {
          return false;
        };

        return (
          <div>
            <Upload
              multiple={maxCount > 1}
              fileList={fileList}
              onChange={handleChange}
              accept={accept}
              maxCount={maxCount}
              disabled={disabled}
              showUploadList={{
                showPreviewIcon: false,
                showRemoveIcon: !downloadOnly,
                showDownloadIcon: downloadOnly,
                downloadIcon: <DownloadOutlined />,
              }}
              beforeUpload={() => false}
            >
              <Button
                icon={<UploadOutlined />}
                className={fieldState.error ? "error" : ""}
                disabled={disabled}
              >
                {" "}
                ファイルを選択
              </Button>
            </Upload>
            {fieldState.error && (
              <p className={fieldState.error ? "mess-error" : ""}>{fieldState.error.message}</p>
            )}
          </div>
        );
      }}
    />
  );
};
export default FileUploader;
