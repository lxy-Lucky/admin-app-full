import styled from "styled-components";

/** antdのstickyヘッダーはz-indexが「列数×2+3」で増えるため（列の多い一覧では50を超える）、
 *  メニュー全体を重なり順の上位に置き、サブメニューが一覧の裏に隠れないようにする。
 *  ※ダイアログ(1000)・antdのポップアップ(1050)より下になる値にしている */
export const LeftMenuWrapper = styled.nav`
  position: relative;
  z-index: 900;
  width: 15%;
  min-width: 153px;
  height: 100vh;
  background-color: ${(props) => props.theme.colors.absolute_black};
`;

export const MenuList = styled.ul`
  margin: 0;
  padding: 0;
  list-style: none;
`;

export const MenuItem = styled.li`
  height: 60px;
  position: relative;
  border-left: 1px solid ${(props) => props.theme.colors.absolute_black};
  font-size: ${(props) => props.theme.fontSizes.base};
  color: ${(props) => props.theme.colors.light_blue3};

  &:hover > ul {
    visibility: visible;
    opacity: 1;
    pointer-events: auto;
  }
`;

export const MenuTitle = styled.div`
  color: ${(props) => props.theme.colors.light_blue3};
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1rem;
  cursor: pointer;

  &:hover {
    background-color: ${(props) => props.theme.colors.strong_gray4};
    color: ${(props) => props.theme.colors.light_blue3};
  }

  .menu-link {
    display: block;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    color: ${(props) => props.theme.colors.light_blue3};
  }
`;

export const Arrow = styled.span`
  color: ${(props) => props.theme.colors.light_blue3};
  font-size: 0.75rem;
`;

export const SubMenu = styled.ul`
  position: absolute;
  top: 0;
  left: 100%;
  width: 250px;
  margin: 0;
  padding: 0;
  list-style: none;
  background-color: ${(props) => props.theme.colors.absolute_black};
  z-index: 50;

  visibility: hidden;
  opacity: 0;

  .submenu-link {
    display: block;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    padding: 0.75rem 1rem 0.75rem 2rem;
    color: ${(props) => props.theme.colors.light_blue3};
  }
`;

export const SubMenuItem = styled.li`
  height: 60px;
  color: ${(props) => props.theme.colors.light_blue3};
  padding: 0;
  cursor: pointer;
  //border-top: 1px solid ${(props) => props.theme.colors.absolute_white};

  &:hover {
    background-color: ${(props) => props.theme.colors.strong_gray4};
    color: ${(props) => props.theme.colors.light_blue3};
  }
`;
