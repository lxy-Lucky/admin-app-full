"use client";

import {
  LeftMenuWrapper,
  MenuList,
  MenuItem,
  MenuTitle,
  Arrow,
  SubMenu,
  SubMenuItem,
} from "./styles";
import NextLink from "next/link";
import { usePathname } from "next/navigation";
import type { ComponentProps } from "react";
import { ROUTES } from "@/constants/routes";

// 表示中のページと同じメニューを押したときはリロードする
function Link({ href, onClick, ...props }: ComponentProps<typeof NextLink>) {
  const pathName = usePathname();

  return (
    <NextLink
      href={href}
      onClick={(e) => {
        onClick?.(e);
        if (href && href === pathName) {
          e.preventDefault();
          window.location.reload();
        }
      }}
      {...props}
    />
  );
}

export default function LeftMenu() {
  return (
    <LeftMenuWrapper>
      <MenuList>
        <MenuItem>
          <MenuTitle>
            <span>マスタ管理</span>
            <Arrow>▶</Arrow>
          </MenuTitle>
          <SubMenu>
            <SubMenuItem>
              <Link href={ROUTES.JUKIDBLIST} className="submenu-link">
                住民基本台帳DB登録
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.SCHOOL_AREA_INFO_LIST} className="submenu-link">
                学区域情報登録
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.GAKUSEKI_DB} className="submenu-link">
                学籍DB登録
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.SCHOOLLIST} className="submenu-link">
                学校マスタ登録
              </Link>
            </SubMenuItem>
          </SubMenu>
        </MenuItem>

        <MenuItem>
          <MenuTitle>
            <span>幼児数集計</span>
            <Arrow>▶</Arrow>
          </MenuTitle>
          <SubMenu>
            <SubMenuItem>
              <Link href={ROUTES.FUMEI_AREA_LIST} className="submenu-link">
                学区域不明児抽出
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.INFANT_SUMMARY1} className="submenu-link">
                1次集計<br></br>学区域不明児入力票取込
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.TOKUCHOUKOU_ANBUN_TOROKU} className="submenu-link">
                2次集計<br></br>特調校按分登録
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.INFANT_SUMMARY2} className="submenu-link">
                2次集計実行
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.INFANT_ROUTINE_ANBUN} className="submenu-link">
                3次集計<br></br>
                常態化指定地区外の按分登録
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.INFANT_SUMMARY3} className="submenu-link">
                3次集計実行
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.INFANT_SUMMARY_RATES} className="submenu-link">
                増減率表・就学率表
              </Link>
            </SubMenuItem>
          </SubMenu>
        </MenuItem>

        <MenuItem>
          <MenuTitle>
            <span>小学校推計</span>
            <Arrow>▶</Arrow>
          </MenuTitle>
          <SubMenu>
            <SubMenuItem>
              <Link href={ROUTES.ELEM_JSH_STUDENT_CLASS} className="submenu-link">
                児童生徒学級数
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href="" className="submenu-link">
                増減表作成
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href={ROUTES.ELEM_CHANGE_RATES} className="submenu-link">
                採用率修正
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href="" className="submenu-link">
                推計表作成
              </Link>
            </SubMenuItem>
            <SubMenuItem>
              <Link href="" className="submenu-link">
                編成表作成
              </Link>
            </SubMenuItem>
          </SubMenu>
        </MenuItem>

        <MenuItem>
          <MenuTitle>
            <span>中学校推計</span>
            <Arrow>▶</Arrow>
          </MenuTitle>
          <SubMenu>
            <SubMenuItem>
              <Link href={ROUTES.JHS_CHANGE_RATES} className="submenu-link">
                採用率修正
              </Link>
            </SubMenuItem>
          </SubMenu>
        </MenuItem>

        {/* サブメニューの無いメニュー（中学校推計のサブメニューが開かないよう、別の項目にする） */}
        <MenuItem>
          <MenuTitle>
            <Link href={ROUTES.USERLIST} className="menu-link">
              ユーザー管理
            </Link>
          </MenuTitle>
        </MenuItem>
      </MenuList>
    </LeftMenuWrapper>
  );
}
