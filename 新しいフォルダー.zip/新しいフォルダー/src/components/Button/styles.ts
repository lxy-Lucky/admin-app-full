import { Button } from "antd";
import styled from "styled-components";

export const ButtonStyle = styled(Button)`
  height: 40px;
  min-width: 100px;
  font-weight: ${(props) => props.theme.fontWeights?.semi_bold};
  padding: 4px 15px;
  border: none;
  cursor: pointer;
  border-radius: 6px;
  box-sizing: border-box;
  border: 1px solid transparent;
  &:disabled {
    color: ${(props) => props.theme.colors?.strong_gray1};
    background-color: ${(props) => props.theme?.colors?.light_gray7};
    &:hover {
      color: ${(props) => props.theme.colors?.strong_gray1};
      border-width: 1px;
    }
  }
  &:not(:disabled) {
    &.custom_primary_button {
      background-color: ${(props) => props.theme.colors?.strong_blue1};
      color: ${(props) => props.theme.colors?.absolute_white};
      &:hover:not(.ant-btn-loading) {
        background-color: ${(props) => props.theme.colors?.strong_blue3};
        color: ${(props) => props.theme.colors?.absolute_white};
        border-width: 1px;
      }
    }
    &.custom_cancel_button {
      background-color: ${(props) => props.theme.colors?.strong_gray3};
      color: ${(props) => props.theme.colors?.absolute_white};
      &:hover:not(.ant-btn-loading) {
        background-color: ${(props) => props.theme.colors?.strong_gray4};
        color: ${(props) => props.theme.colors?.absolute_white};
        border-width: 1px;
      }
    }
    &.custom_green_button {
      background-color: ${(props) => props.theme.colors?.success2};
      color: ${(props) => props.theme.colors?.absolute_white};
      &:hover:not(.ant-btn-loading) {
        background-color: ${(props) => props.theme.colors?.success1};
        color: ${(props) => props.theme.colors?.absolute_white};
        border-width: 1px;
      }
    }
    &.custom_red_button {
      background-color: ${(props) => props.theme.colors?.danger};
      color: ${(props) => props.theme.colors?.absolute_white};
      &:hover:not(.ant-btn-loading) {
        background-color: ${(props) => props.theme.colors?.dark_pink};
        color: ${(props) => props.theme.colors?.absolute_white};
        border-width: 1px;
      }
    }
    &.custom_lightgray_button {
      background-color: ${(props) => props.theme.colors?.light_gray6};
      color: ${(props) => props.theme.colors?.absolute_black};
      &:hover:not(.ant-btn-loading) {
        background-color: ${(props) => props.theme.colors?.light_gray5};
        color: ${(props) => props.theme.colors?.absolute_black};
        border-width: 1px;
      }
    }
    .ant-btn-loading-icon {
      display: none;
    }
  }
`;
