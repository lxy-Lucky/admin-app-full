import React from "react";
import { ButtonStyle } from "./styles";
import { ButtonProps } from "antd";

type Props = ButtonProps & {
  typeButton?: "default" | "gray" | "green" | "red" | "lightgray" | "none";
};

enum TypeButton {
  Default = "default",
  Gray = "gray",
  Green = "green",
  Red = "red",
  LightGray = "lightgray",
  None = "none",
}

const Button = ({ typeButton = "default", className = "", ...props }: Props) => {
  const getClassName = () => {
    let _className = "";
    switch (typeButton) {
      case TypeButton.Default:
        _className = "custom_primary_button";
        break;
      case TypeButton.Gray:
        _className = "custom_cancel_button";
        break;
      case TypeButton.Green:
        _className = "custom_green_button";
        break;
      case TypeButton.Red:
        _className = "custom_red_button";
        break;
      case TypeButton.LightGray:
        _className = "custom_lightgray_button";
        break;
      default:
        _className = "";
    }
    return `${_className} ${className}`;
  };
  return (
    <ButtonStyle {...props} className={getClassName()}>
      {props.children}
    </ButtonStyle>
  );
};

export default Button;
