"use client";

import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { Pagination, Table } from "antd";
import type { ColumnsType, TableProps } from "antd/es/table";
import { useStickyContainer } from "./StickyContainerContext";
import { PaginationBar, StickyTableWrapper } from "./styles";

interface CommonTableProps<T> {
  header?: string;
  columns: ColumnsType<T>;
  dataSource: T[];
  rowKey: string | ((record: T, index?: number) => string);
  /** false を渡すとテーブル内部の縦スクロールを無効化し、高さを親要素に委ねる */
  scrollY?: number | false;
  scrollX?: number | string;
  /** trueの場合、テーブル内部では縦スクロールさせず、ヘッダー行だけをスクロールコンテナの
   *  上部に貼り付けて追従させる。<ListPageLayout>配下で使うとそのListAreaに自動で追従する */
  stickyHeader?: boolean;
  pagination?: boolean | TableProps<T>["pagination"];
  loading?: boolean;
  /** 行の高さ(上下余白)。未指定時はantdのデフォルト(large) */
  size?: TableProps<T>["size"];
  maxRecord?: number | null;

  current?: number;
  pageSize?: number;
  total?: number;
  onPaginationChange?: (page: number, pageSize: number) => void;
  rowClassName?: TableProps<T>["rowClassName"];
}

export default function CustomTable<T>({
  header,
  columns,
  dataSource,
  rowKey,
  scrollY = 500,
  scrollX = "max-content",
  stickyHeader = false,
  pagination = false,
  loading = false,
  size,
  current,
  pageSize,
  total,
  onPaginationChange,
  rowClassName, // レコードの(td)にcssクラスを定義するため
}: CommonTableProps<T>) {
  const stickyContainer = useStickyContainer();
  const paginationRef = useRef<HTMLDivElement>(null);
  const [paginationHeight, setPaginationHeight] = useState(0);

  const paginationEnabled = pagination !== false;
  // pagination=trueの場合のみ有効。オブジェクトで渡された場合はそれを優先（将来の個別上書き用）
  const userPaginationConfig = pagination === true || pagination === false ? {} : pagination;

  // antd Table自身の描画は出さず(position:["none"])、ソート→ページングの内部処理だけを
  // Tableに任せる。見た目のページネーションUIは自前のPaginationBarで表示する
  const tablePagination: TableProps<T>["pagination"] = paginationEnabled
    ? {
        current,
        pageSize,
        total,
        placement: ["none"],
        ...userPaginationConfig,
      }
    : false;

  // stickyHeader時はテーブル内部の縦スクロールを持たず、ページ全体のスクロールに委ねる
  const noInternalScroll = stickyHeader || scrollY === false;

  const hasStickyPagination = stickyHeader && paginationEnabled;

  // 自前のページネーションバーの実測高さ分だけ、ヘッダーのstickyオフセットをずらし、
  // 両者がListArea上部で重ならずに積み重なるようにする
  useLayoutEffect(() => {
    if (!hasStickyPagination) {
      return;
    }

    const el = paginationRef.current;
    if (!el) {
      return;
    }

    const observer = new ResizeObserver(() => setPaginationHeight(el.offsetHeight));
    observer.observe(el);
    return () => observer.disconnect();
  }, [hasStickyPagination]);

  const tableNode = useMemo(
    () => (
      <Table<T>
        // 仮想スクロールは表の内部で縦スクロールする場合のみ使う。
        // 内部スクロール無し(stickyHeader等)で使うと、行が表の枠で切り取られず
        // 右端の列が見切れる・枠外にはみ出す不具合が起きるため通常の表で描画する
        virtual={!noInternalScroll}
        columns={columns}
        dataSource={dataSource}
        rowKey={rowKey}
        loading={loading}
        size={size}
        pagination={tablePagination}
        showSorterTooltip={false}
        scroll={{
          // 内部スクロール無しの場合はyを未指定にする（0を渡すと通常の表では本体の高さが0になる）
          y: noInternalScroll ? undefined : scrollY,
          x: scrollX,
        }}
        sticky={
          stickyHeader
            ? {
                offsetHeader: paginationHeight,
                // ListPageLayout配下でなければ未指定(null)となり、antd側がwindowにフォールバックする。
                // 型定義はnull非許容だが、実装はgetContainer()||windowで吸収するためキャストする
                getContainer: (() => stickyContainer) as () => HTMLElement | Window,
              }
            : false
        }
        rowClassName={rowClassName}
      />
    ),
    [
      columns,
      dataSource,
      rowKey,
      loading,
      size,
      tablePagination,
      noInternalScroll,
      scrollY,
      scrollX,
      stickyHeader,
      paginationHeight,
      stickyContainer,
    ],
  );

  const paginationNode = paginationEnabled ? (
    <PaginationBar ref={paginationRef} $sticky={hasStickyPagination}>
      <Pagination
        current={current}
        pageSize={pageSize}
        total={total}
        showTotal={(t, range) => `${range[0]}-${range[1]} / ${t} 件`}
        onChange={(page, size) => {
          onPaginationChange?.(page, size);
        }}
        // 件数変更プルダウンのデフォルトはtriggerNode.parentNode配下に描画されるため、
        // sticky表示のPaginationBar内に収まりヘッダーの裏に隠れてしまう。bodyへポータルして回避する
        showSizeChanger={{ getPopupContainer: () => document.body }}
        pageSizeOptions={[10, 20, 50, 100, 1000]}
      />
    </PaginationBar>
  ) : null;

  return (
    <div className="common-table">
      {header && <div className="common-table-header">{header}</div>}

      {noInternalScroll ? (
        <StickyTableWrapper>
          {paginationNode}
          {tableNode}
        </StickyTableWrapper>
      ) : (
        <>
          {paginationNode}
          {tableNode}
        </>
      )}
    </div>
  );
}
