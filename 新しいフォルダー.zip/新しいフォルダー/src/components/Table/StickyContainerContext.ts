import { createContext, useContext } from "react";

/** stickyHeader用のスクロールコンテナ(ListPageLayoutのListArea)を
 *  ページ側でrefを書かずにCustomTableへ伝えるためのコンテキスト */
export const StickyContainerContext = createContext<HTMLElement | null>(null);

export const useStickyContainer = () => useContext(StickyContainerContext);
