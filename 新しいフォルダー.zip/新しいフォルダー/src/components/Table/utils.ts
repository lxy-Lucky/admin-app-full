/**
 * 文字列ソート
 */
export const sorter = (field: string) => {
  return (a: Record<string, unknown>, b: Record<string, unknown>): number => {
    const valueA = String(a[field] ?? "");
    const valueB = String(b[field] ?? "");

    return valueA.localeCompare(valueB, "ja");
  };
};

/**
 * 数値ソート
 * 人数・按分率など数値の列用（文字列ソートだと「10」が「9」より前になるため）
 * ※値が無い（null・undefined・空文字・数値に変換できない）場合は、昇順で先頭になるようにする
 */
export const numberSorter = (field: string) => {
  return (a: Record<string, unknown>, b: Record<string, unknown>): number => {
    const valueA = toSortNumber(a[field]);
    const valueB = toSortNumber(b[field]);

    // 値が無い同士（-Infinity同士）の引き算はNaNになるため、大小比較で返す
    if (valueA === valueB) {
      return 0;
    }
    return valueA < valueB ? -1 : 1;
  };
};

/** ソート用に数値へ変換する（値が無い場合は-Infinity） */
const toSortNumber = (value: unknown): number => {
  if (value == null || value === "") {
    return -Infinity;
  }

  const num = Number(value);
  return Number.isNaN(num) ? -Infinity : num;
};
