import { useState } from "react";

interface UsePaginationOptions {
  initialPage?: number;
  initialPageSize?: number;
}

export const usePagination = ({
  initialPage = 1, //デフォルトの初期ページは1
  initialPageSize = 1000, //各ページに設定がなければデフォルト1ページあたり１０００件
}: UsePaginationOptions = {}) => {
  const [currentPage, setCurrentPage] = useState(initialPage ?? 1);
  const [pageSize, setPageSize] = useState(initialPageSize ?? 50);
  const [totalRecord, setTotalRecord] = useState(0);

  const handlePaginationChange = (
    page: number,
    size: number,
    onChange?: (page: number, size: number) => void,
  ) => {
    const isPageSizeChanged = size !== pageSize;

    // ページサイズ変更時は1ページ目に戻す
    const nextPage = isPageSizeChanged ? 1 : page;

    setCurrentPage(nextPage);
    setPageSize(size);

    // State更新を待たず、計算済みの値を渡す
    onChange?.(nextPage, size);
  };

  return {
    currentPage,
    pageSize,
    totalRecord,

    setCurrentPage,
    setPageSize,
    setTotalRecord,

    handlePaginationChange,
  };
};
