import styled, { css } from "styled-components";

/** scrollY=false(antdのsticky機能でヘッダー追従)時、ant-tableのoverflow:hiddenがstickyを阻害するため解除する
 *
 *  横スクロールは表本体ではなく、親のListAreaに任せる。
 *  antdは横スクロール時に表本体(.ant-table-body)へoverflow-x:autoを付けるため、そのままでは
 *  横スクロールバーが表の最下端(縦スクロールが一番下の時)にしか出ない。
 *  antdの追従横スクロールバーがそれを補うが、ListAreaのバーと二重になるため、
 *  表本体のoverflowを解除してListAreaのバー(常に画面下端に表示)だけにする */
export const StickyTableWrapper = styled.div`
  /* 表の幅(横スクロール分)まで広げ、ページネーションバーのstickyの基準を横スクロール範囲全体にする */
  width: max-content;
  min-width: 100%;

  .ant-table,
  .ant-table-container,
  .ant-table-content {
    overflow: visible;
  }

  /* インラインstyle(overflow-x:auto / hidden)を上書きするため!importantが必要 */
  .ant-table-header,
  .ant-table-body {
    overflow: visible !important;
  }

  .ant-table-sticky-scroll {
    display: none;
  }
`;

/** ページネーション（表の上に独自描画）。$sticky時はヘッダー行と同様にListArea上部へ固定表示する */
export const PaginationBar = styled.div<{ $sticky?: boolean }>`
  display: flex;
  justify-content: flex-end;
  padding: 8px 0;
  background: ${(props) => props.theme.colors.absolute_white};

  ${(props) =>
    props.$sticky &&
    css`
      position: sticky;
      top: 0;
      left: 0;
      z-index: 3;
      /* 横スクロールしても画面内に残るよう、ListAreaの表示幅に合わせる */
      width: 100cqw;
    `}
`;
