import Button from "../Button/page";
import { DialogContainer, Body, Footer, Overlay } from "./styles";

interface DialogProps {
  mode?: "delete" | "update" | "import" | "default";
  open: boolean;
  title?: string;
  children: React.ReactNode;
  onClose: () => void;
  onConfirm?: () => void;
  confirmText?: string;
  cancelText?: string;
  confirmType?: "button" | "submit";
  showCancel?: boolean;
  inOperation?: boolean;
}

export default function Dialog({
  mode,
  open,
  children,
  onClose,
  onConfirm,
  confirmText = "閉じる",
  cancelText = "キャンセル",
  confirmType = "button",
  showCancel = false,
  inOperation = false,
}: DialogProps) {
  if (!open) {
    return null;
  }

  return (
    <Overlay onClick={onClose}>
      <DialogContainer onClick={(e) => e.stopPropagation()}>
        {/* {title && <Header>{title}</Header>} */}

        <Body>{children}</Body>

        <Footer>
          {showCancel && (
            <Button type="primary" typeButton="gray" onClick={onClose}>
              {cancelText}
            </Button>
          )}

          <Button
            loading={inOperation}
            type="primary"
            typeButton={
              mode === "delete"
                ? "red"
                : mode === "update"
                  ? "green"
                  : mode === "import"
                    ? "default"
                    : "lightgray"
            }
            htmlType={confirmType}
            onClick={confirmType === "button" ? (onConfirm ?? onClose) : undefined}
            className="confirm-btn"
          >
            {confirmText}
          </Button>
        </Footer>
      </DialogContainer>
    </Overlay>
  );
}
