import styled from "styled-components";

export const Body = styled.div`
  color: ${(props) => props.theme.colors.absolute_black};
`;
