"use client";

import { useForm, Controller } from "react-hook-form";
import { Spin, type UploadFile } from "antd";
import Dialog from "@/components/Modal/Dialog";
import FileUploader from "@/components/FileUploader/page";
import { Body } from "./styles";
import { useEffect } from "react";

type CsvImportForm = {
  files: UploadFile[];
};

type CsvImportModalProps = {
  open: boolean;
  onClose: () => void;
  onImport?: (file: UploadFile) => void;
  onMultiFileImport?: (files: UploadFile[]) => void;
  children: React.ReactNode;
  // 選択可能なファイル種別（未指定時は既存どおりCSV）。Excel取込画面などから上書きして使う
  accept?: string;
  // ファイル未選択時のエラーメッセージ（未指定時は既存どおりCSV向けの文言）
  inOperation?: boolean;

  maxUploadFileCount?: number;
};

export default function CsvImportModal({
  open,
  onClose,
  onImport,
  onMultiFileImport,
  children,
  accept,
  inOperation,
  maxUploadFileCount = 1,
}: CsvImportModalProps) {
  const { control, handleSubmit, reset } = useForm<CsvImportForm>({
    defaultValues: {
      files: [],
    },
  });

  const submit = (data: CsvImportForm) => {
    if (maxUploadFileCount === 1) {
      const file = data.files?.[0];

      if (!file) {
        return;
      }
      if (onImport) {
        onImport(file);
      }
    } else if (maxUploadFileCount > 1) {
      const files = data.files;

      if (!files) {
        return;
      }

      if (onMultiFileImport) {
        onMultiFileImport(files);
      }
    }
  };

  //前回選択したファイル値をクリア
  useEffect(() => {
    if (open) {
      reset({
        files: [],
      });
    }
  }, [open, reset]);

  const handleClose = () => {
    reset({
      files: [],
    });
    onClose();
  };

  return (
    <form onSubmit={handleSubmit(submit)}>
      <Dialog
        mode="import"
        open={open}
        onClose={handleClose}
        confirmText="実行"
        cancelText="キャンセル"
        confirmType="submit"
        showCancel={true}
        inOperation={inOperation}
      >
        <Controller
          name="files"
          control={control}
          render={({ field, fieldState }) => (
            <>
              <Body>{children}</Body>
              <FileUploader
                name={field.name}
                control={control}
                accept={accept}
                maxCount={maxUploadFileCount}
              />
            </>
          )}
        />
      </Dialog>
    </form>
  );
}
