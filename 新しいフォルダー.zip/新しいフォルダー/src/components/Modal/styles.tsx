import styled from "styled-components";

export const Overlay = styled.div`
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.4);

  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

export const DialogContainer = styled.div`
  width: 450px;
  background: ${(props) => props.theme.colors.absolute_white};
  border-radius: 16px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
`;

export const Body = styled.div`
  text-align: center;
  padding: 24px 20px;
  white-space: pre-line;

  color: ${(props) => props.theme.colors.absolute_black};
`;

export const Footer = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding: 12px 20px;
`;
