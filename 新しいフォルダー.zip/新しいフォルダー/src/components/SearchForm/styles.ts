import styled from "styled-components";

export const Panel = styled.div`
  background: ${(props) => props.theme.colors.light_gray8};
  border: 1px solid ${(props) => props.theme.colors.light_gray5};
  border-radius: 4px;
`;

export const PanelHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 16px;
  cursor: pointer;
  user-select: none;
  font-size: ${(props) => props.theme.fontSizes.base};
  font-weight: ${(props) => props.theme.fontWeights.semi_bold};
  color: ${(props) => props.theme.colors.strong_gray3};

  .arrow {
    color: ${(props) => props.theme.colors.strong_blue1};
    font-size: ${(props) => props.theme.fontSizes.small};
  }
`;

export const FieldsGrid = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  gap: 16px;
  padding: 0 16px 12px;
`;

export const FieldItem = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
`;

export const FieldLabel = styled.span`
  font-size: ${(props) => props.theme.fontSizes.small};
  color: ${(props) => props.theme.colors.strong_gray3};
`;

export const FooterRow = styled.div`
  display: flex;
  justify-content: flex-end;
  padding: 0 16px 16px;
`;
