import { FieldValues } from "react-hook-form";

// 対応するフィールド種別
export type SearchFieldKind =
  "text" | "select" | "radio" | "checkbox" | "checkboxGroup" | "dateRange";

export type SearchFieldOption = {
  value: string | number;
  label: string;
};

export type SearchFieldConfig = {
  // react-hook-form上のフィールド名（検索リクエストのキーと合わせる）
  name: string;
  label: string;
  kind: SearchFieldKind;
  // select / radio / checkboxGroup 用の選択肢
  options?: SearchFieldOption[];
  placeholder?: string;
  width?: number | string;
};

export type SearchFormProps<T extends FieldValues> = {
  fields: SearchFieldConfig[];
  defaultValues: T;
  onSearch: (values: T) => void;
  // 初期状態で検索条件を折りたたむか（デフォルトは展開）
  defaultCollapsed?: boolean;
  submitLabel?: string;
};
