"use client";

import { useState } from "react";
import { Controller, DefaultValues, FieldValues, Path, useForm } from "react-hook-form";
import { Checkbox, Input, Radio, Select } from "antd";
import Button from "@/components/Button/page";
import { SearchFieldConfig, SearchFormProps } from "./type";
import { FieldItem, FieldLabel, FieldsGrid, FooterRow, Panel, PanelHeader } from "./styles";

/** 一覧画面共通の検索条件パネル。項目の種類はfieldsで宣言し、ページ固有の
 *  マークアップを持たないようにする（新しい一覧画面でも流用できるようにするため） */
export default function SearchForm<T extends FieldValues>({
  fields,
  defaultValues,
  onSearch,
  defaultCollapsed = false,
  submitLabel = "検索",
}: SearchFormProps<T>) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);
  const { control, handleSubmit } = useForm<T>({
    defaultValues: defaultValues as DefaultValues<T>,
  });

  return (
    <Panel>
      <PanelHeader onClick={() => setCollapsed((prev) => !prev)}>
        <span>検索条件</span>
        <span className="arrow">{collapsed ? "▼" : "▲"}</span>
      </PanelHeader>

      <form onSubmit={handleSubmit((values) => onSearch(values as T))}>
        {/* 閉じている間は検索ボタンも含めて非表示にする */}
        {!collapsed && (
          <>
            <FieldsGrid>
              {fields.map((field) => (
                <FieldItem key={field.name} style={{ width: field.width }}>
                  {/* checkboxは項目名をコントロール自体の横に表示するため、ここでは見えない
                    プレースホルダーを置いて他項目とコントロールの縦位置を揃える */}
                  <FieldLabel aria-hidden={field.kind === "checkbox"}>
                    {field.kind === "checkbox" ? " " : field.label}
                  </FieldLabel>

                  <Controller
                    name={field.name as Path<T>}
                    control={control}
                    render={({ field: rhfField }) => renderField(field, rhfField)}
                  />
                </FieldItem>
              ))}
            </FieldsGrid>

            <FooterRow>
              <Button type="primary" htmlType="submit">
                {submitLabel}
              </Button>
            </FooterRow>
          </>
        )}
      </form>
    </Panel>
  );
}

// react-hook-formのControllerが渡すfield（onChange/onBlur/value/name/ref）を
// フィールド種別ごとにantdのコンポーネントへ橋渡しする
function renderField(
  field: SearchFieldConfig,
  rhfField: {
    name: string;
    value: unknown;
    onChange: (value: unknown) => void;
    onBlur: () => void;
  },
) {
  const width = field.width ?? 200;

  switch (field.kind) {
    case "text":
      return (
        <Input
          value={rhfField.value as string}
          onChange={(e) => rhfField.onChange(e.target.value)}
          onBlur={rhfField.onBlur}
          placeholder={field.placeholder}
          style={{ width }}
        />
      );

    case "select":
      return (
        <Select
          value={rhfField.value}
          onChange={rhfField.onChange}
          onBlur={rhfField.onBlur}
          options={field.options}
          placeholder={field.placeholder}
          style={{ width }}
          allowClear
        />
      );

    case "radio":
      return (
        <Radio.Group
          value={rhfField.value}
          onChange={(e) => rhfField.onChange(e.target.value)}
          options={field.options}
        />
      );

    case "checkbox":
      return (
        <Checkbox checked={!!rhfField.value} onChange={(e) => rhfField.onChange(e.target.checked)}>
          {field.label}
        </Checkbox>
      );

    case "checkboxGroup":
      return (
        <Checkbox.Group
          value={rhfField.value as (string | number)[]}
          onChange={rhfField.onChange}
          options={field.options}
          style={{ width }}
        />
      );

    case "dateRange":
      // TODO: 日付範囲（まだ利用画面が無いため未実装）
      return <></>;

    default:
      return <></>;
  }
}
