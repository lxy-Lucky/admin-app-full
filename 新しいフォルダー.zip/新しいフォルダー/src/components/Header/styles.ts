import styled from "styled-components";

export const HeaderWrapper = styled.div`
  height: 46px;
  background: ${(props) => props.theme.colors.light_blue4};
  font-weight: ${(props) => props.theme.fontWeights.bold};
  font-size: ${(props) => props.theme.fontSizes.base};
  color: ${(props) => props.theme.colors.absolute_white};
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-left: 1.5rem;
  padding-right: 1.5rem;
  overflow: visible;

  .title-btn {
    font-size: ${(props) => props.theme.fontSizes.large};
    font-weight: ${(props) => props.theme.fontWeights.semi_bold};
    cursor: pointer;
  }
`;

export const LoginUserMenu = styled.div`
  position: relative;

  button {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    cursor: pointer;
    line-height: 22px;
  }

  .arrow {
    color: ${(props) => props.theme.colors.absolute_black};
    font-size: ${(props) => props.theme.fontSizes.small};
  }
`;

export const TopRightDropMenu = styled.div`
  position: absolute;
  right: 0;
  top: 100%;
  margin-top: 0.5rem;
  z-index: 50;
  width: 8rem;
  background: ${(props) => props.theme.colors.absolute_white};
  box-shadow: ${(props) => props.theme.boxShadows.strong_gray1};
  width: 200px;

  li {
    padding-left: 1rem;
    padding-right: 1rem;
    padding-top: 0.75rem;
    padding-bottom: 0.75rem;
    cursor: pointer;
    border: 1px solid ${(props) => props.theme.colors.absolute_black};
    color: ${(props) => props.theme.colors.absolute_black};
    font-weight: ${(props) => props.theme.fontWeights.normal};
  }
  li:first-child {
    border-bottom: none;
  }
`;
