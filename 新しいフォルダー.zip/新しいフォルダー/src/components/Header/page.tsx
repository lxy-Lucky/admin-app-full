"use client";
import { useEffect, useState } from "react";
import { removeToken } from "@/utils/api";
import { HeaderWrapper, LoginUserMenu, TopRightDropMenu } from "./styles";
import "@/styles/globals.scss";
import { ELocalStorgeKey } from "@/constants/common";
import LocalStorage from "@/utils/LocalStorage";
import { useRouter } from "next/navigation";
import { ROUTES } from "@/constants/routes";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [userName, setUserName] = useState("");
  const router = useRouter();

  useEffect(() => {
    const userInfo = LocalStorage.get(ELocalStorgeKey.USER_INFO);
    const userName = userInfo?.user_nm;

    if (userName) {
      setUserName(userName);
    }
  }, []);

  // 個人設定画面へ
  const handlePersonalSettings = () => {
    setIsMenuOpen(false);
  };

  //ログアウト
  const handleLogout = () => {
    removeToken();
    localStorage.removeItem("user_info");
    sessionStorage.clear();

    router.replace(ROUTES.LOGIN);
  };

  //トップ画面へ
  const goToTopScreen = () => {
    router.replace(ROUTES.TOP);
  };

  return (
    <HeaderWrapper>
      <div>
        <button className="title-btn" type="button" onClick={goToTopScreen}>
          Y-POP
        </button>
      </div>

      <LoginUserMenu>
        <button type="button" onClick={() => setIsMenuOpen((prev) => !prev)}>
          <span>{userName}</span>

          <span className="arrow">▼</span>
        </button>

        {isMenuOpen && (
          <TopRightDropMenu>
            <ul>
              <li onClick={handlePersonalSettings} className="">
                個人設定
              </li>

              <li onClick={handleLogout}>ログアウト</li>
            </ul>
          </TopRightDropMenu>
        )}
      </LoginUserMenu>
    </HeaderWrapper>
  );
}
