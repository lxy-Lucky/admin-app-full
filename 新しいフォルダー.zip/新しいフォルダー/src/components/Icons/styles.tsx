import styled from "styled-components";

export const DeleteMessage = styled.p`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  margin: 0;
`;
