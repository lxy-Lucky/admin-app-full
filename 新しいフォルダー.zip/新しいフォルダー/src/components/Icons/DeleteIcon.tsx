type DeleteIconProps = {
  size?: number;
};

const DeleteIcon = ({ size = 32 }: DeleteIconProps) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Red circle */}
      <circle cx="16" cy="16" r="16" fill="#FF1F2D" />

      {/* Trash bin */}
      <path d="M9 12H23" stroke="white" strokeWidth="2" strokeLinecap="round" />

      <path
        d="M12 12V9H20V12"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      <path d="M11 12L12 24H20L21 12" stroke="white" strokeWidth="2" strokeLinejoin="round" />

      {/* Lines inside trash bin */}
      <path d="M14 15V21M18 15V21" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
};

export default DeleteIcon;
