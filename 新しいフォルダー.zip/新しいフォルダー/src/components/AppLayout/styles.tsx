import styled from "styled-components";

export const BodyWrapper = styled.div`
  display: flex;
  width: 100%;
  min-height: calc(100vh - 60px);
`;

export const RightFrameWrapper = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  width: 100%;
  min-width: 0;
  min-height: calc(100vh - 60px);

  background-color: ${(props) => props.theme.colors.light_gray2};
`;

export const SubHeader = styled.div`
  width: 100%;
  height: 40px;
  background-color: ${(props) => props.theme.colors.absolute_white};
  display: flex;
  align-items: center;
  color: ${(props) => props.theme.colors.absolute_black};
  font-size: ${(props) => props.theme.fontSizes.base};
  line-height: 22px;

  span {
    margin-left: 20px;
  }

  a {
    color: -webkit-link;
    text-decoration: underline;
  }
`;

export const Main = styled.main``;
