"use client";
import Header from "@/components/Header/page";
import LeftMenu from "@/components/Menu/page";
import { RightFrameWrapper, BodyWrapper, SubHeader, Main } from "./styles";
import { usePathname } from "next/navigation";
import { PagePaths } from "@/constants/common";
import { useRouter } from "next/navigation";
import { ROUTES } from "@/constants/routes";
import { useEffect, useState } from "react";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();

  const pathName = usePathname();

  const pageUrlText = PagePaths[pathName] ?? "";

  const isTopPage = pathName === ROUTES.TOP;

  return (
    <>
      <Header />
      <BodyWrapper>
        <LeftMenu />
        <RightFrameWrapper>
          <SubHeader>
            {!isTopPage && (
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  router.back();
                }}
              >
                <span></span>
                戻る
              </a>
            )}
            <span>{pageUrlText}</span>
          </SubHeader>
          <Main>{children}</Main>
        </RightFrameWrapper>
      </BodyWrapper>
    </>
  );
}
