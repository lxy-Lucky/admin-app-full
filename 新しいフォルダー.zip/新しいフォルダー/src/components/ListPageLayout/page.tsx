"use client";

import { ReactNode, useEffect, useRef, useState } from "react";
import { StickyContainerContext } from "@/components/Table/StickyContainerContext";
import { ActionBar, ContentWrapper, FixedArea, ListArea } from "./styles";

interface ListPageLayoutProps {
  /** 新規登録ボタンや検索条件など、一覧の上に並べる操作エリア */
  actions?: ReactNode;
  errorMessage?: string;
  /** APIレスポンスのmsg_level=WARN相当の注意メッセージ（一覧の直前に警告色で表示する）。
   *  エラーではないが利用者に対応を促したい場合（例：集計が未実行）に使う */
  warnMessage?: string;
  children: ReactNode;
}

/** 一覧画面共通のレイアウト。サイト全体がbody{overflow:hidden}前提のため、
 *  一覧(children)はこのコンポーネントが持つListArea内だけでスクロールする。
 *  children側の<CustomTable stickyHeader />はrefを渡さなくても、
 *  このコンポーネントがContext経由で渡すListAreaに自動で追従する */
export default function ListPageLayout({
  actions,
  errorMessage,
  warnMessage,
  children,
}: ListPageLayoutProps) {
  const listAreaRef = useRef<HTMLDivElement>(null);
  const [container, setContainer] = useState<HTMLDivElement | null>(null);

  useEffect(() => {
    setContainer(listAreaRef.current);
  }, []);

  return (
    <ContentWrapper>
      <FixedArea>
        {actions && <ActionBar>{actions}</ActionBar>}

        {errorMessage && (
          <div className="err-msg-div">
            <span className="mess-error">{errorMessage}</span>
          </div>
        )}

        {warnMessage && (
          <div className="err-msg-div">
            <span className="mess-warn">{warnMessage}</span>
          </div>
        )}
      </FixedArea>

      <ListArea ref={listAreaRef}>
        <StickyContainerContext.Provider value={container}>
          {children}
        </StickyContainerContext.Provider>
      </ListArea>
    </ContentWrapper>
  );
}
