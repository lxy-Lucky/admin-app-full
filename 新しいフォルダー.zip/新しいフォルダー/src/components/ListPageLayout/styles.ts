import styled from "styled-components";

/** サイト全体がbody{overflow:hidden}(ウィンドウ自体はスクロールしない)前提のため、
 *  一覧画面はビューポート内に高さを収め、一覧部分(ListArea)だけで内部スクロールさせる */
export const ContentWrapper = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  height: calc(100vh - 60px - 40px - 20px);
  overflow: hidden;
  padding: 0 24px;

  @media (max-width: 768px) {
    padding: 0 12px;
  }
`;

/** 新規登録ボタンや検索条件・エラーメッセージ等、スクロール対象外の固定エリア
 *  一覧との間の余白はスクロール領域の外側であるここで確保する。
 *  ListArea側に余白を置くとstickyヘッダーの上に透明な隙間ができ、行が透けて見えてしまう
 *
 *  検索条件が多い画面などでウィンドウが低くなると、ここの内容だけで高さを使い切り、
 *  下のListArea(一覧)が0になってスクロールすらできなくなることがあるため、
 *  flex-shrinkを許可してここ自体が縮んだ場合は内部スクロールするようにしている */
export const FixedArea = styled.div`
  flex-shrink: 1;
  min-height: 0;
  overflow-y: auto;
  padding: 20px 0 10px;

  @media (max-width: 768px) {
    padding: 12px 0;
  }
`;

/** 新規登録ボタンや検索条件など、一覧の上に並べる操作エリア */
export const ActionBar = styled.div`
  margin-bottom: 8px;
`;

/** 残り領域いっぱいに広がり、右端にスクロールバーが出る一覧エリア。
 *  FixedAreaが伸びて押し出されても、一覧側が完全に0にならないよう最低限の高さを確保する
 *
 *  一覧(CustomTable stickyHeader)は表の内部ではスクロールせず、このエリアのスクロールに任せる。
 *  bodyもoverflow:hiddenのため、ここでスクロールさせないと範囲外の行を確認できなくなる */
export const ListArea = styled.div`
  flex: 1;
  min-height: 160px;
  overflow-y: auto;
  /* 横スクロールしても画面内に残す要素(ページネーションバー)の幅を、cqwでこの表示幅に合わせる */
  container-type: inline-size;
`;
