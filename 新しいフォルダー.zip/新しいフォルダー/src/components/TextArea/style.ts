import styled from "styled-components";
import { Input, Select } from "antd";

export const CustomInput = styled(Input)`
  ${(props) => `
    border: none;
    width:100%
    border-bottom: 1px solid ${props.theme.colors.light_gray4};
    border-radius: 0;
    font-size: ${props.theme.fontSizes.semi_base};
    padding-left: 4px;
        .ant-input {
        border: none;
    }
  `}
`;
