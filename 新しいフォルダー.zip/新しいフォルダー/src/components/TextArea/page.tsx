import { Control, Controller, FieldPath, FieldValues, RegisterOptions } from "react-hook-form";
import { CustomInput } from "./style";

export interface IProps<T extends FieldValues> {
  value: string;
  name: FieldPath<T>;
  control: Control<T>;
  placeholder?: string;
  rules?: RegisterOptions<T>;
  errorMessage?: string;
  note?: string;
  disabled?: boolean;
  maxLength?: number;
  style?: React.CSSProperties;
  onChange?: (event: React.ChangeEvent<HTMLTextAreaElement>) => void;
}

const TextAreaCustom = <T extends FieldValues>({
  value,
  name,
  control,
  placeholder,
  rules = {},
  errorMessage = "",
  note = "",
  disabled,
  maxLength,
  style,
}: IProps<T>) => {
  return (
    <Controller
      name={name}
      control={control}
      rules={rules}
      render={({ field }) => (
        <CustomInput.TextArea
          {...field}
          maxLength={maxLength}
          disabled={disabled}
          rows={4}
          placeholder={placeholder}
          style={style}
          className="textarea-field-custom__scroll_bar"
        />
      )}
    />
  );
};

export default TextAreaCustom;
