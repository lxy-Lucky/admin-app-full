#!/bin/bash

set -e

# ########## 変数定義 ####################################################
readonly git_user="pull-only"
readonly git_pass="paradigm"
readonly git_host="192.168.1.212:8080"
readonly git_url="http://${git_user}:${git_pass}@${git_host}"
readonly repo_nm="yce-zinkou-suikei-fe"
readonly git_repo_url="${git_url}/pdm/${repo_nm}.git"
readonly git_branch="ver-0.1"

# #######################################################################

#Gitリポジトリが存在していればブランチの判断
if [ -e "./.git" ] ; then

    check_remote_branch=$(git ls-remote  "$git_repo_url"   --exit-code --heads origin "$git_branch")
    echo ${check_remote_branch}
    if [  -z  "${check_remote_branch}"  ] ; then
        echo "ブランチ '$git_branch' はリモートに存在しません。処理を中止します。"
        exit 1
    fi

    # ローカルのブランチとリモートブランチが一致している?
    local_branch=$(git rev-parse --abbrev-ref HEAD)
    echo ${local_branch}

    if [ ${git_branch} = ${local_branch}  ]; then
          echo "================================="
          echo " git pull します"
          echo "================================="
     else
          echo "================================="
          echo "ローカルブランチを切替えます"
          echo "================================="
          git checkout "$git_branch"
     fi

     # git pull実行！
     output=$(git pull ${git_repo_url} ${git_branch} 2>&1 )
     echo "${output}"
else
    echo "git フォルダがないので処理を中断します"
    exit 1
fi



echo "================================="
echo " コンテナ再ビルドします"
echo "================================="

/usr/local/bin/docker-compose down
/usr/local/bin/docker-compose up -d --build
