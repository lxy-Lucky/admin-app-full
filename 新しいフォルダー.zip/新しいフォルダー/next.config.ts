import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* styles.ts  のため */
  compiler: {
    styledComponents: true,
  },

  devIndicators: false,
};

export default nextConfig;
